import 'package:areb/constants/colors.dart';
import 'package:areb/constants/fonts.dart';
import 'package:areb/firebase_options.dart';
import 'package:areb/functions/firebase.dart';
import 'package:areb/functions/size_screen.dart';
import 'package:areb/screens/auth/create_children/cubit/add_child_b_loc_cubit.dart';
import 'package:areb/screens/auth/signin/cubit/signin_bloc_cubit.dart';
import 'package:areb/screens/auth/signup/cubit/sign_up_bloc_cubit.dart';
import 'package:areb/screens/child/bottom_nav_bar/cubit/bottom_nav_bar_child_cubit.dart';
import 'package:areb/screens/child/dialogs/take_photo_currency/cubit/take_photo_for_currency_cubit.dart';
import 'package:areb/screens/child/financial%20_portfolio/cubit/financial_portfolio_cubit.dart';
import 'package:areb/screens/child/home/calculator/cubit/calculator_cubit.dart';
import 'package:areb/screens/child/home/home/cubit/home_child_pr_cubit.dart';
import 'package:areb/screens/child/home/gools/cubit/gools_child_bloc_cubit.dart';
import 'package:areb/screens/child/home/records/cubit/record_child_cubit.dart';

import 'package:areb/screens/child/home/smart_Assistant/cubit/smart_assesstant_cubit.dart';
import 'package:areb/screens/child/tasks_child/cubit/task_child_cubit.dart';

import 'package:areb/screens/father/bottom_nav_bar/cubit/bottom_nav_bar_father_cubit.dart';

import 'package:areb/screens/father/children/add_children/cubit/add_children_into_app_cubit.dart';
import 'package:areb/screens/father/children/add_money_to_chlidren/cubit/add_money_father_cubit.dart';
import 'package:areb/screens/father/children/view_children/cubit/get_children_father_cubit.dart';
import 'package:areb/screens/father/home/cubit/home_father_bloc_cubit.dart';
import 'package:areb/screens/father/personal_account_father/cubit/father_account_cubit.dart';
import 'package:areb/screens/father/personal_account_father/loan_applications/cubit/loan_father_cubit.dart';
import 'package:areb/screens/father/personal_account_father/edit_account/cubit/edit_acconunt_cubit.dart';
import 'package:areb/screens/father/tasks/addTasks/cubit/add_tasks_cubit.dart';
import 'package:areb/screens/father/tasks/view_tasks/cubit/view_task_parent_cubit.dart';
import 'package:areb/screens/father/tasks/editTasks/cubit/edit_tasks_cubit.dart';
import 'package:areb/screens/splash/splash.dart';

import 'package:areb/shared/dio/dio.dart';
import 'package:areb/shared/shared_preferences/shared_p.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'screens/child/personal_account_child/cubit/child_account_cubit.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Dioc.init();
  await Sharedc.init();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);

  await permisionNotifiation();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    sizeScreen = MediaQuery.of(context).size;
    // Sharedc.resetShared();

    return MediaQuery(
      data: MediaQuery.of(context).copyWith(
        // Increase the text scale factor to 1.5
        textScaler: TextScaler.linear(
          sizeScreen.width < 392
              ? 0.64
              : sizeScreen.width > 450
                  ? 1.0
                  : 0.75,
        ),
      ),
      child: MultiBlocProvider(
        providers: [
          BlocProvider<SignUpBlocCubit>(
            create: (context) => SignUpBlocCubit(),
          ),
          BlocProvider<SigninBlocCubit>(
            create: (context) => SigninBlocCubit(),
          ),
          BlocProvider<AddChildBLocCubit>(
            create: (context) => AddChildBLocCubit(),
          ),
          BlocProvider<GoolsChildBlocCubit>(
            create: (context) => GoolsChildBlocCubit(),
          ),
          BlocProvider<HomeFatherBlocCubit>(
            create: (context) => HomeFatherBlocCubit(),
          ),
          BlocProvider<BottomNavBarFatherCubit>(
            create: (context) => BottomNavBarFatherCubit(),
          ),
          BlocProvider<BottomNavBarChildCubit>(
            create: (context) => BottomNavBarChildCubit(),
          ),
          BlocProvider<FatherAccountCubit>(
            create: (context) => FatherAccountCubit(),
          ),
          BlocProvider<AddChildrenIntoAppCubit>(
            create: (context) => AddChildrenIntoAppCubit(),
          ),
          BlocProvider<GetChildrenFatherCubit>(
            create: (context) => GetChildrenFatherCubit(),
          ),
          BlocProvider<AddMoneyFatherCubit>(
            create: (context) => AddMoneyFatherCubit(),
          ),
          BlocProvider<LoanFatherCubit>(
            create: (context) => LoanFatherCubit(),
          ),
          BlocProvider<EditAcconuntCubit>(
            create: (context) => EditAcconuntCubit(),
          ),
          BlocProvider<HomeChildPrCubit>(
            create: (context) => HomeChildPrCubit(),
          ),
          BlocProvider<ChildAccountCubit>(
            create: (context) => ChildAccountCubit(),
          ),
          BlocProvider<AddTasksCubit>(
            create: (context) => AddTasksCubit(),
          ),
          BlocProvider<FinancialPortfolioCubit>(
            create: (context) => FinancialPortfolioCubit(),
          ),
          BlocProvider<TakePhotoForCurrencyCubit>(
            create: (context) => TakePhotoForCurrencyCubit(),
          ),
          BlocProvider<EditTasksCubit>(
            create: (context) => EditTasksCubit(),
          ),
          BlocProvider<ViewTaskParentCubit>(
            create: (context) => ViewTaskParentCubit(),
          ),
          BlocProvider<TaskChildCubit>(
            create: (context) => TaskChildCubit(),
          ),
          BlocProvider<SmartAssesstantCubit>(
            create: (context) => SmartAssesstantCubit(),
          ),
          BlocProvider<CalculatorCubit>(
            create: (context) => CalculatorCubit(),
          ),
          BlocProvider<RecordChildCubit>(
            create: (context) => RecordChildCubit(),
          ),
        ],
        child: MaterialApp(
          title: 'areb',
          theme: ThemeData(
            colorScheme: ColorScheme.fromSeed(seedColor: Colorc.cyan),
            scaffoldBackgroundColor: Colorc.lightCyan,
            useMaterial3: true,
            fontFamily: Fontc.marheySmallTitle,
          ),
          debugShowCheckedModeBanner: false,
          themeMode: ThemeMode.light,
          localizationsDelegates: const [
            GlobalCupertinoLocalizations.delegate,
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
          ],
          supportedLocales: const [
            Locale("ar", "SY"),
            Locale("en", "UK"),
          ],
          home: const Splash(),
          locale: const Locale("ar", "SY"),
        ),
      ),
    );
  }
}
