class Goals {
  int id;
  String name;
  String goal;
  String price;
  String imageUrl;
  Goals({
    required this.id,
    required this.name,
    required this.goal,
    required this.price,
    required this.imageUrl,
  });

  factory Goals.fromMap(json) {
    return Goals(
      id: json['id'] ?? 0,
      name: json['user']['name'] ?? '',
      goal: json['name'] ?? '',
      price: json['price'].toString(),
      imageUrl: json['image'] ?? '',
    );
  }
}
