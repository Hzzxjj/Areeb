import 'package:areb/constants/colors.dart';
import 'package:flutter/material.dart';

class HomeModel {
  String title;
  String disc;
  Color color;
  IconData icon;
  HomeModel({
    required this.title,
    required this.disc,
    required this.color,
    required this.icon,
  });
}

List<HomeModel> homeModels = [
  HomeModel(
    title: 'بياناتي المالية',
    disc: 'اعرف اكثر حول المدفوعات والمدخرات والمساعدات المالية والجوائز',
    color: Colorc.lightPurple,
    icon: Icons.poll_outlined,
  ),
  HomeModel(
    title: 'أهدافي',
    disc: 'سجل أهدافك وتابع التقدم',
    color: Colorc.pink,
    icon: Icons.golf_course_sharp,
  ),
  HomeModel(
    title: 'حاسبتي',
    disc: 'احسب المدة لتحقيق الهدف',
    color: Colorc.yellow,
    icon: Icons.calculate_outlined,
  ),
  HomeModel(
    title: 'محفظتي',
    disc: 'اعرف رصيدك واطلب المساعدة',
    color: Colorc.mediumGreen,
    icon: Icons.monetization_on,
  ),
];
