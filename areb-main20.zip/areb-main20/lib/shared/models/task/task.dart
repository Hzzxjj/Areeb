class TaskModel {
  int id;
  String childName;
  double reward;
  String task;
  String date;
  String note;
  TaskModel({
    required this.id,
    required this.childName,
    required this.reward,
    required this.task,
    required this.date,
    required this.note,
  });

  factory TaskModel.fromMap(Map<String, dynamic> map) {
    return TaskModel(
      id: map['id']?.toInt() ?? 0,
      childName: map['child_name'] ?? '',
      reward: map['reward']?.toDouble() ?? 0.0,
      task: map['task_name'] ?? '',
      date: map['date'] ?? '',
      note: map['note'] ?? '',
    );
  }
}
