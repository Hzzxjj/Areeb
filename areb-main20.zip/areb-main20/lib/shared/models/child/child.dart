import 'package:areb/shared/models/user/user.dart';

class Child extends User {
  Child({
    required super.id,
    required super.name,
    required super.email,
    required super.date,
    required super.role,
    required this.image,
    required this.money,
  });

  String image;
  double money;

  factory Child.fromMap(Map<String, dynamic> map) {
    return Child(
      id: map['id'] ?? 0,
      name: map['name'] ?? '',
      date: map['date'] ?? '',
      email: map['email'] ?? '',
      role: map['role'] ?? '',
      image: map['image'] ?? '',
      money: double.parse(map['score'].toString()),
    );
  }
}
