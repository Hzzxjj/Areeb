class DateDayRecord {
  int index;
  String ar;
  String en;
  DateDayRecord({
    required this.index,
    required this.ar,
    required this.en,
  });
}
