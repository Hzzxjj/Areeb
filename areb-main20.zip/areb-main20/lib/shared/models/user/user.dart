class User {
  int id;
  String name;
  String email;
  String role;
  String date;
  User({
    required this.id,
    required this.name,
    required this.email,
    required this.role,
    required this.date,
  });

  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      id: map['id'] ?? 0,
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      role: map['role'] ?? '',
      date: map['date'] ?? '',
    );
  }
}
