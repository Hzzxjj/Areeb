import 'package:areb/shared/models/child/child.dart';

class Loan {
  int id;
  String title;
  double lona;
  String status;
  DateTime date;

  Loan({
    required this.id,
    required this.title,
    required this.lona,
    required this.status,
    required this.date,
  });

  factory Loan.fromMap(Map<String, dynamic> map) {
    return Loan(
      id: map['id']?.toInt() ?? 0,
      title: map['cause'] ?? '',
      status: fillStatus(map['status'] ?? ""),
      date: DateTime.parse(map['created_at'].toString()),
      lona: map['value']?.toDouble() ?? 0.0,
    );
  }
}

String fillStatus(String value) {
  switch (value) {
    case 'refused':
      return 'مرفوض';

    case 'accepted':
      return 'مقبول';
    case 'pending':
      return 'قيد الإنتظار';

    default:
      return 'قيد الإنتظار';
  }
}

class LoanWithChild extends Loan {
  Child child;
  LoanWithChild({
    required super.id,
    required super.title,
    required super.status,
    required super.date,
    required super.lona,
    required this.child,
  });

  factory LoanWithChild.fromMap(Map<String, dynamic> map) {
    return LoanWithChild(
      id: map['id']?.toInt() ?? 0,
      title: map['cause'] ?? '',
      status: fillStatus(map['status'] ?? ""),
      date: DateTime.parse(map['created_at'].toString()),
      lona: map['value']?.toDouble() ?? 0.0,
      child: Child.fromMap(map['user']),
    );
  }
}
//

//refused

//accepted

//