import 'package:shared_preferences/shared_preferences.dart';

class Sharedc {
  // final SharedPreferences prefs = await SharedPreferences.getInstance()
  static late SharedPreferences pref;

  static Future init() async {
    pref = await SharedPreferences.getInstance();
  }

//for store shared preferences:
  static void storeString(String key, String value) {
    pref.setString(key, value);
  }

  //for store List Strign:
  static void storeListString(String key, List<String> value) {
    pref.setStringList(key, value);
  }

  static List<String>? getListString(String key) {
    return pref.getStringList(key) ?? [];
  }

  static String getString(String key) {
    return pref.getString(key) ?? '';
  }

  static resetShared() {
    pref.clear();
  }
}
