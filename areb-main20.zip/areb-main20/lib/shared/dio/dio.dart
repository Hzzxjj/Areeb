import 'dart:convert';
import 'dart:io';

import 'package:areb/functions/add_image.dart';
import 'package:areb/shared/shared_preferences/shared_p.dart';
import 'package:dio/dio.dart';

class Dioc {
  static late Dio dio;
  static const String url = 'https://areeb.fun';
  // static const String url = 'http://192.168.1.14:8000';
 //static const String url =
   //   'https://dodgerblue-dolphin-654749.hostingersite.com';

  static const String imageUrl = url;
  static const String baseUrl = '$url/api/';

  static init() {
    dio = Dio(
      BaseOptions(
        receiveDataWhenStatusError: true,
        baseUrl: baseUrl,
        headers: {'Accept': 'application/json'},
      ),
    );
  }

  //post  sign in  :
  static Future<Response> signin({
    required String name,
    required String password,
  }) async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: baseUrl,
    );
    final getversion = await dio.post(
      // 'login',
      'login',
      data: {
        "name": name,
        "password": password,
      },
      options: Options(listFormat: ListFormat.multi),
    );

    // print(getversion.data);
    return getversion;
  }

  //post  Rigister  :
  static Future<Response> signup({
    required String name,
    required String password,
    required String email,
    required String date,
  }) async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: baseUrl,
    );
    final getversion = await dio.post(
      // 'login',
      'register',
      data: {
        "name": name,
        "password": password,
        "email": email,
        "date": date,
      },
      options: Options(listFormat: ListFormat.multi),
    );

    // print(getversion.data);
    return getversion;
  }

  //post  Rigister  :
  static Future<Response> editUsers({
    required String name,
    required String password,
    required String email,
    required String date,
  }) async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: baseUrl,
      headers: {
        "Accept": "application/json",
        "Authorization": "Bearer ${Sharedc.getString('token')}",
      },
    );
    final getversion = await dio.post(
      // 'login',
      'users',
      data: {
        "name": name,
        "email": email,
        "date": date,
        "password": password,
        "passwordConfirmation": password,
        "_method": "patch"
      },
      options: Options(listFormat: ListFormat.multi),
    );

    return getversion;
  }

  //post  Rigister  :
  static Future<Response> editChildimage({
    required String name,
    required String password,
    required String email,
    required String date,
    required File image,
  }) async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: baseUrl,
      headers: {
        "Accept": "application/json",
        "Authorization": "Bearer ${Sharedc.getString('token')}",
      },
    );

    dynamic imagee = await MultipartFile.fromFile(image.path,
        filename: image.path.split('/').last);

    FormData data = FormData.fromMap({
      "name": name,
      "email": email,
      "date": date,
      "image": imagee,
      "password": password,
      "passwordConfirmation": password,
      "_method": "patch"
    }, ListFormat.multiCompatible);

    final getversion = await dio.post(
      // 'login',
      'users',
      data: data,
      options: Options(listFormat: ListFormat.multi),
    );

    return getversion;
  }

  //post  children :
  static Future<Response> postChildren({
    required String name,
    required String password,
    required String date,
  }) async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: baseUrl,
      headers: {
        "Accept": "application/json",
        "Authorization": "Bearer ${Sharedc.getString('token')}",
      },
    );
    final getversion = await dio.post(
      // 'login',
      'children',
      data: {
        "name": name,
        "password": password,
        "date": date,
      },
      options: Options(listFormat: ListFormat.multi),
    );

    return getversion;
  }

  //get  goals  :
  static Future<Response> getGoals() async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: baseUrl,
      headers: {
        "Accept": "application/json",
        "Authorization": "Bearer ${Sharedc.getString('token')}",
      },
    );
    final getversion = await dio.get(
      // 'login',
      'goals',

      options: Options(listFormat: ListFormat.multi),
    );

    // print(getversion.data);
    return getversion;
  }

  //check goals
  static Future<Response> doneGoals({
    required int id,
  }) async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: baseUrl,
      headers: {
        "Accept": "application/json",
        "Authorization": "Bearer ${Sharedc.getString('token')}",
      },
    );

    final getversion = await dio.get(
      // 'task',
      'goals/$id/check',

      options: Options(listFormat: ListFormat.multi),
    );

    return getversion;
  }

  //get  tasks  :
  static Future<Response> getTasks() async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: baseUrl,
      headers: {
        "Accept": "application/json",
        "Authorization": "Bearer ${Sharedc.getString('token')}",
      },
    );
    final getversion = await dio.get(
      // 'login',
      'tasks',

      options: Options(listFormat: ListFormat.multi),
    );

    // print(getversion.data);
    return getversion;
  }

  //get  goals  :
  static Future<Response> getLoans() async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: baseUrl,
      headers: {
        "Accept": "application/json",
        "Authorization": "Bearer ${Sharedc.getString('token')}",
      },
    );
    final getversion = await dio.get(
      // 'login',
      'loans',

      options: Options(listFormat: ListFormat.multi),
    );

    // print(getversion.data);
    return getversion;
  }

  //get  user  :
  static Future<Response> getUsersOnly() async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: baseUrl,
      headers: {
        "Accept": "application/json",
        "Authorization": "Bearer ${Sharedc.getString('token')}",
      },
    );
    final getversion = await dio.get(
      // 'login',
      'users',

      options: Options(listFormat: ListFormat.multi),
    );

    // print(getversion.data);
    return getversion;
  }

  //get  goals  :
  static Future<Response> getChildren() async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: baseUrl,
      headers: {
        "Accept": "application/json",
        "Authorization": "Bearer ${Sharedc.getString('token')}",
      },
    );
    final getversion = await dio.get(
      // 'login',
      'children',

      options: Options(listFormat: ListFormat.multi),
    );

    // print(getversion.data);
    return getversion;
  }

  //post  goals  :
  static Future<Response> postGoals({
    required String name,
    required String price,
    required File image,
  }) async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: baseUrl,
      headers: {
        "Accept": "application/json",
        "Authorization": "Bearer ${Sharedc.getString('token')}",
      },
    );

    dynamic imagee = await MultipartFile.fromFile(image.path,
        filename: image.path.split('/').last);

    FormData data = FormData.fromMap({
      "name": name,
      "price": price,
      "image": imagee,
    }, ListFormat.multiCompatible);

    final getversion = await dio.post(
      // 'login',
      'goals',
      data: data,

      options: Options(listFormat: ListFormat.multiCompatible),
    );

    return getversion;
  }

  //get  goals  :
  static Future<Response> deleteGoals({
    required int id,
  }) async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: baseUrl,
      headers: {
        "Accept": "application/json",
        "Authorization": "Bearer ${Sharedc.getString('token')}",
      },
    );
    final getversion = await dio.get(
      // 'login',
      'goals/$id/destroy',

      options: Options(listFormat: ListFormat.multi),
    );

    // print(getversion.data);
    return getversion;
  }

//sent money:
  static Future<Response> sentMoney(
      {required String money,
      required String note,
      required int childId}) async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: baseUrl,
      headers: {
        "Accept": "application/json",
        "Authorization": "Bearer ${Sharedc.getString('token')}",
      },
    );
    final getversion = await dio.post(
      // 'login',
      'users/$childId/add-money',
      data: {
        "score": money,
        "note": note,
      },
      options: Options(listFormat: ListFormat.multi),
    );

    return getversion;
  }

  //accept or reject loan
  static Future<Response> responceOnLoan({
    required String status,
    required int loanId,
  }) async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: baseUrl,
      headers: {
        "Accept": "application/json",
        "Authorization": "Bearer ${Sharedc.getString('token')}",
      },
    );
    final getversion = await dio.post(
      // 'login',
      'loans/$loanId/change-status',
      data: {
        "status": status,
      },
      options: Options(listFormat: ListFormat.multi),
    );

    return getversion;
  }

//sent currency
  static Future<Response> postImageToCurrency(context) async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: 'https://classify.roboflow.com/',
      headers: {"Content-Type": "application/x-www-form-urlencoded"},
    );

    var base = base64Encode(AddImage.imageSelected!.readAsBytesSync());

    final getversion = await dio.post(
      // 'login',
      'currency-riyal/3',
      // 'saudi-currency-detection/1',
      // 'saudi-riyal/1',
      // 'currency-notes-vgw8d/1',
      data: base,
      options: Options(listFormat: ListFormat.multi),

      queryParameters: {"api_key": "PLiLyZjDb79VYf1RRrX6"},
    );

    return getversion;
  }

//requiestALoan
  static Future<Response> requiestALoan({
    required String cause,
    required String ammount,
  }) async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: baseUrl,
      headers: {
        "Accept": "application/json",
        "Authorization": "Bearer ${Sharedc.getString('token')}",
      },
    );
    final getversion = await dio.post(
      // 'login',
      'loans',
      data: {
        "cause": cause,
        "value": ammount,
      },
      options: Options(listFormat: ListFormat.multi),
    );

    return getversion;
  }

  //sent task
  static Future<Response> sentTasak({
    required String title,
    required String reward,
    required int userId,
    required String date,
  }) async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: baseUrl,
      headers: {
        "Accept": "application/json",
        "Authorization": "Bearer ${Sharedc.getString('token')}",
      },
    );

    final getversion = await dio.post(
      // 'task',
      'tasks',
      data: {
        "name": title,
        "reward": reward,
        "userId": userId,
        "date": date,
      },
      options: Options(listFormat: ListFormat.multi),
    );

    return getversion;
  }

  //sent task
  static Future<Response> checkOnTask({
    required int taskId,
  }) async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: baseUrl,
      headers: {
        "Accept": "application/json",
        "Authorization": "Bearer ${Sharedc.getString('token')}",
      },
    );

    final getversion = await dio.get(
      // 'task',
      'tasks/$taskId/check',

      options: Options(listFormat: ListFormat.multi),
    );

    return getversion;
  }

  //get  task  :
  static Future<Response> deleteTask({
    required int id,
  }) async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: baseUrl,
      headers: {
        "Accept": "application/json",
        "Authorization": "Bearer ${Sharedc.getString('token')}",
      },
    );
    final getversion = await dio.post(
      // 'login',
      'tasks/$id/destroy',
      data: {"_method": 'delete'},

      options: Options(listFormat: ListFormat.multi),
    );

    // print(getversion.data);
    return getversion;
  }

  //edit task
  static Future<Response> editTasak({
    required String title,
    required String reward,
    required int id,
    required String date,
  }) async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: baseUrl,
      headers: {
        "Accept": "application/json",
        "Authorization": "Bearer ${Sharedc.getString('token')}",
      },
    );

    final getversion = await dio.post(
      // 'task',
      'tasks/$id/update',
      data: {
        "_method": "patch",
        "name": title,
        "reward": reward,
        "date": date,
      },
      options: Options(listFormat: ListFormat.multi),
    );

    return getversion;
  }

  //get  task  :
  static Future<Response> getQuistionFromAssestant() async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: baseUrl,
      headers: {
        "Accept": "application/json",
        "Authorization": "Bearer ${Sharedc.getString('token')}",
      },
    );
    final getversion = await dio.get(
      // 'login',
      'questions',

      options: Options(listFormat: ListFormat.multi),
    );

    // print(getversion.data);
    return getversion;
  }

  //filtir all rigisters
  static Future<Response> filtiringAllRigisters(String filterType) async {
    dio.options = BaseOptions(
      receiveDataWhenStatusError: true,
      baseUrl: baseUrl,
      headers: {
        "Accept": "application/json",
        "Authorization": "Bearer ${Sharedc.getString('token')}",
      },
    );
    final getversion = await dio.get(
      // 'login',
      'statistics/$filterType',

      options: Options(listFormat: ListFormat.multi),
    );

    // print(getversion.data);
    return getversion;
  }
}
