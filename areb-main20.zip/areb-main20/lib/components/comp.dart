import 'package:areb/constants/colors.dart';
import 'package:areb/constants/fonts.dart';
import 'package:areb/constants/images.dart';
import 'package:areb/constants/radius.dart';
import 'package:areb/constants/shadow.dart';
import 'package:areb/constants/sizes.dart';
import 'package:areb/functions/navigations.dart';
import 'package:areb/functions/size_screen.dart';
import 'package:areb/screens/father/bottom_nav_bar/bottom_nav_bar_father_page.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:areb/shared/models/child/child.dart';
import 'package:areb/shared/models/goals/goals.dart';
import 'package:areb/shared/models/record_date_day/record_date.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:control_style/control_style.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:page_transition/page_transition.dart';
import 'package:zoom_tap_animation/zoom_tap_animation.dart';

abstract class Compc {
  //
  static Widget cardRecords({
    required String title,
    required String money,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(
          Radc.r15,
        ),
        boxShadow: [
          BoxShadow(
            blurRadius: 1,
            offset: const Offset(0, -1.1),
            color: Colorc.darkGrey.withOpacity(0.7),
          ),
        ],
        color: Colorc.white,
      ),
      height: 80,
      margin: const EdgeInsetsDirectional.symmetric(
        horizontal: 25,
        vertical: 10,
      ),
      padding: const EdgeInsetsDirectional.symmetric(
        horizontal: 15,
        vertical: 15,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            title,
            style: TextStyle(
              fontFamily: Fontc.marheySmallTitle,
              color: Colorc.darkGrey,
              fontSize: Sic.s24,
            ),
          ),
          Align(
            alignment: AlignmentDirectional.bottomEnd,
            child: Text(
              money,
              style: TextStyle(
                fontFamily: Fontc.marheySmallTitle,
                color: Colorc.darkGrey.withOpacity(0.7),
                fontSize: Sic.s20,
              ),
            ),
          ),
        ],
      ),
    );
  }

  //form field :
  static Widget formField({
    required TextEditingController controller,
    required String? Function(String?)? validator,
    required TextInputType keyboardType,
    void Function(String)? onFieldSubmitted,
    bool obscureText = false,
    void Function()? onEditingComplete,
    String lable = '',
    String hintText = '',
    required TextInputAction textInputAction,
    Widget? icon,
    Widget? iconButton,
    void Function(String)? onchanged,
    bool? enableInteractiveSelection,
    void Function()? onTap,
    bool readOnly = false,
    TextDirection? textDirection,
    int? maxLength,
    List<TextInputFormatter>? inputFormatters,
    TextStyle? hintStyle,
    BoxShadow? shadow,
    double? horizontalPadding = 20,
  }) {
    TextStyle? hintStylee = hintStyle ??
        TextStyle(
          fontSize: Sic.s15,
          color: Colorc.darkGrey.withOpacity(0.8),
          // fontFamily: Fontc.jana,
        );

    // BoxShadow shadowf = shadow ?? Shadc.smoth(color: Colorc.pink);
    BoxShadow shadowf = shadow ??
        BoxShadow(
          blurRadius: 1,
          offset: const Offset(0, -1.1),
          color: Colorc.darkGrey.withOpacity(0.7),
        );

    return Container(
      // height: 70,
      padding: EdgeInsets.symmetric(horizontal: horizontalPadding!),
      child: TextFormField(
        inputFormatters: inputFormatters,
        maxLength: maxLength,
        textDirection: textDirection,
        style: TextStyle(
          color: Colorc.darkGrey,
          fontSize: Sic.s15,
          // fontFamily: Fontc.jana,
        ),
        onTapOutside: (v) {
          // FocusManager.instance.primaryFocus?.unfocus();
        },
        readOnly: readOnly,
        enableInteractiveSelection: enableInteractiveSelection,
        onChanged: onchanged,
        onTap: onTap,
        textInputAction: textInputAction,
        controller: controller,
        validator: validator,
        keyboardType: keyboardType,
        obscureText: obscureText,
        onFieldSubmitted: onFieldSubmitted,
        onEditingComplete: onEditingComplete,
        cursorRadius: const Radius.circular(30),
        cursorColor: Colorc.deepCyan,
        decoration: InputDecoration(
          contentPadding:
              const EdgeInsets.symmetric(vertical: 16, horizontal: 10),
          counter: const Offstage(),
          floatingLabelBehavior: FloatingLabelBehavior.always,
          hintText: hintText,
          //hint style:
          hintStyle: hintStylee,
          enabledBorder: DecoratedInputBorder(
            shadow: [shadowf],
            child: OutlineInputBorder(
              borderSide: BorderSide(
                color: Colorc.trans,
              ),
              borderRadius: BorderRadius.circular(Radc.r36),
            ),
          ),
          suffixIcon: iconButton,
          prefixIcon: icon,
          floatingLabelStyle: TextStyle(
            color: Colorc.white,
            fontSize: Sic.s20,
            // fontFamily: Fontc.primary,
          ),
          label: Text(
            lable,
            style: TextStyle(
              fontSize: Sic.s15,
              color: Colorc.white,
              // fontFamily: Fontc.jana,
            ),
          ),
          border: DecoratedInputBorder(
            shadow: [shadowf],
            child: OutlineInputBorder(
              borderSide: BorderSide(color: Colorc.trans, width: 1),
              borderRadius: BorderRadius.circular(Radc.r36),
            ),
          ),

          //error text style:
          errorStyle: TextStyle(
            color: Colorc.trans,
            overflow: TextOverflow.ellipsis,
            // fontFamily: Fontc.bah,
            fontSize: Sic.s12,
          ),
          focusColor: Colors.transparent,
          fillColor: Colorc.white,
          hoverColor: Colorc.white,
          focusedBorder: DecoratedInputBorder(
            shadow: [shadowf],
            child: OutlineInputBorder(
              borderSide: BorderSide(color: Colorc.trans, width: 1.0),
              borderRadius: BorderRadius.circular(Radc.r36),
            ),
          ),
          filled: true,
        ),
      ),
    );
  }
//form Field Calculator :

  static Widget formFieldCalculator({
    required TextEditingController controller,
    required String? Function(String?)? validator,
    required TextInputType keyboardType,
    void Function(String)? onFieldSubmitted,
    bool obscureText = false,
    void Function()? onEditingComplete,
    String lable = '',
    String hintText = '',
    required TextInputAction textInputAction,
    Widget? icon,
    Widget? iconButton,
    void Function(String)? onchanged,
    bool? enableInteractiveSelection,
    void Function()? onTap,
    bool readOnly = false,
    TextDirection? textDirection,
    int? maxLength,
    List<TextInputFormatter>? inputFormatters,
    TextStyle? hintStyle,
    BoxShadow? shadow,
  }) {
    TextStyle? hintStylee = hintStyle ??
        TextStyle(
          fontSize: Sic.s20,
          color: Colorc.darkGrey.withOpacity(0.8),
          // fontFamily: Fontc.jana,
        );

    // BoxShadow shadowf = shadow ?? Shadc.smoth(color: Colorc.pink);

    return Container(
      // height: 70,
      width: 250,
      alignment: Alignment.center,
      child: TextFormField(
        inputFormatters: inputFormatters,
        maxLength: maxLength,
        textDirection: textDirection,
        style: TextStyle(
          color: Colorc.darkGrey,
          fontSize: Sic.s20,
          // fontFamily: Fontc.jana,
        ),
        onTapOutside: (v) {
          // FocusManager.instance.primaryFocus?.unfocus();
        },
        readOnly: readOnly,
        enableInteractiveSelection: enableInteractiveSelection,
        onChanged: onchanged,
        onTap: onTap,
        textInputAction: textInputAction,
        controller: controller,
        validator: validator,
        keyboardType: keyboardType,
        obscureText: obscureText,
        onFieldSubmitted: onFieldSubmitted,
        onEditingComplete: onEditingComplete,
        cursorRadius: const Radius.circular(5),
        cursorColor: Colorc.deepCyan,
        decoration: InputDecoration(
          contentPadding: const EdgeInsets.symmetric(
            vertical: 16,
            horizontal: 10,
          ),
          counter: const Offstage(),
          floatingLabelBehavior: FloatingLabelBehavior.always,
          hintText: hintText,
          //hint style:
          hintStyle: hintStylee,
          enabledBorder: DecoratedInputBorder(
            // shadow: [shadowf],
            child: OutlineInputBorder(
              borderSide: BorderSide(
                color: Colorc.trans,
              ),
              borderRadius: BorderRadius.circular(Radc.r10),
            ),
          ),
          suffixIcon: iconButton,
          prefixIcon: icon,
          floatingLabelStyle: TextStyle(
            color: Colorc.white,
            fontSize: Sic.s20,
            // fontFamily: Fontc.primary,
          ),
          label: Text(
            lable,
            style: TextStyle(
              fontSize: Sic.s15,
              color: Colorc.white,
              // fontFamily: Fontc.jana,
            ),
          ),
          border: DecoratedInputBorder(
            child: OutlineInputBorder(
              borderSide: BorderSide(color: Colorc.trans, width: 1),
              borderRadius: BorderRadius.circular(Radc.r10),
            ),
          ),

          //error text style:
          errorStyle: TextStyle(
            color: Colorc.trans,
            overflow: TextOverflow.ellipsis,
            // fontFamily: Fontc.bah,
            fontSize: Sic.s12,
          ),
          focusColor: Colors.transparent,
          fillColor: Colorc.white,
          hoverColor: Colorc.white,
          focusedBorder: DecoratedInputBorder(
            // shadow: [shadowf],
            child: OutlineInputBorder(
              borderSide: BorderSide(color: Colorc.trans, width: 1.0),
              borderRadius: BorderRadius.circular(Radc.r10),
            ),
          ),
          filled: true,
        ),
      ),
    );
  }

//tap animation
  static Widget tapAnimation({
    double scalLimit = 0.90,
    required void Function()? onTap,
    void Function(TapUpDetails)? onTapUp,
    void Function(TapDownDetails)? onTapDown,
    required Widget child,
  }) {
    return ZoomTapAnimation(
      begin: 1,
      end: scalLimit,
      child: GestureDetector(
        behavior: HitTestBehavior.translucent,
        // overlayColor: MaterialStatePropertyAll(
        //   Colorc.trans,
        // ),
        onTap: onTap,
        onTapDown: onTapDown,
        onTapUp: onTapUp,
        child: child,
      ),
    );
  }

//
  static Widget buttonCalculator({
    required void Function() onTap,
    required String text,
  }) {
    return ZoomTapAnimation(
      begin: 1,
      end: 0.90,
      child: InkWell(
        onTap: onTap,
        overlayColor: WidgetStatePropertyAll(Colorc.trans),
        child: Container(
          width: 180,
          padding: const EdgeInsets.symmetric(vertical: 02),
          decoration: BoxDecoration(
            color: Colorc.purple,
            borderRadius: BorderRadius.circular(Radc.r24),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              //text :
              Text(
                text,
                style: TextStyle(
                  color: Colorc.black,
                  fontSize: Sic.s40,
                  fontFamily: Fontc.hayahBigTitle,
                  fontWeight: FontWeight.w500,
                ),
              ),
              //spacing :
              const SizedBox(
                width: 20,
              ),
            ],
          ),
        ),
      ),
    );
  }

//dropdownButton
  static Widget dropdownButton(
      {required List<Child> children,
      required void Function(int?) onChanged,
      required int? childSelected}) {
    return Container(
      margin: const EdgeInsetsDirectional.symmetric(
        horizontal: 50,
        vertical: 15,
      ),
      decoration: BoxDecoration(
        border: Border.all(
          color: Colorc.darkGrey.withOpacity(0.3),
        ),
        borderRadius: BorderRadius.circular(
          Radc.r36,
        ),
        boxShadow: [
          BoxShadow(
            blurRadius: 1,
            offset: const Offset(0, -1.1),
            color: Colorc.darkGrey.withOpacity(1),
          )
        ],
        color: Colorc.white,
      ),
      child: DropdownButton(
        value: childSelected,
        items: children
            .map((e) => DropdownMenuItem(
                  value: e.id,
                  child: Text(e.name),
                ))
            .toList(),
        hint: Text(
          'الطفل',
          style: TextStyle(
            fontFamily: Fontc.marheySmallTitle,
            color: Colorc.darkGrey.withOpacity(0.8),
            fontSize: Sic.s15,
          ),
        ),
        style: TextStyle(
          fontFamily: Fontc.marheySmallTitle,
          color: Colorc.darkGrey.withOpacity(0.8),
          fontSize: Sic.s15,
        ),
        borderRadius: BorderRadius.circular(
          Radc.r36,
        ),
        padding: const EdgeInsetsDirectional.symmetric(
          horizontal: 10,
          vertical: 2.5,
        ),
        dropdownColor: Colorc.white,
        isExpanded: true,
        onChanged: onChanged,
        underline: const SizedBox(),
        iconEnabledColor: Colorc.darkGrey.withOpacity(0.8),
      ),
    );
  }

//dropdownButton calculator
  static Widget dropdownButtonCalculator({
    required List<Goals> goals,
    required int? goalsSelected,
    required void Function(Object?)? onChanged,
  }) {
    return Container(
      width: 250,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(
          Radc.r10,
        ),
        color: Colorc.white,
      ),
      child: DropdownButton(
        value: goalsSelected,
        items: goals
            .map(
              (e) => DropdownMenuItem(
                value: e.id,
                child: Text(
                  e.goal,
                  style: TextStyle(fontSize: Sic.s20),
                ),
              ),
            )
            .toList(),
        hint: Text(
          'الهدف',
          style: TextStyle(
            fontFamily: Fontc.marheySmallTitle,
            color: Colorc.darkGrey.withOpacity(0.8),
            fontSize: Sic.s20,
          ),
        ),
        style: TextStyle(
          fontFamily: Fontc.marheySmallTitle,
          color: Colorc.darkGrey.withOpacity(0.8),
          fontSize: Sic.s24,
        ),
        borderRadius: BorderRadius.circular(
          Radc.r24,
        ),
        padding: const EdgeInsetsDirectional.symmetric(
          horizontal: 10,
          vertical: 4,
        ),
        dropdownColor: Colorc.white,
        isExpanded: true,
        onChanged: onChanged,
        underline: const SizedBox(),
        iconEnabledColor: Colorc.darkGrey.withOpacity(0.8),
      ),
    );
  }

//drop down Button Home Child
  static Widget dropdownButtonHomeChild({
    required List<DateDayRecord> dateday,
    required int? selected,
    required void Function(Object?)? onChanged,
  }) {
    return Container(
      margin: const EdgeInsetsDirectional.symmetric(
        horizontal: 25,
        vertical: 15,
      ),
      padding: const EdgeInsetsDirectional.symmetric(
        horizontal: 25,
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(
          Radc.r10,
        ),
        color: Colorc.white,
      ),
      child: DropdownButton(
        value: selected,
        items: dateday
            .map((e) => DropdownMenuItem(
                  value: e.index,
                  child: Text(
                    e.ar,
                    style: TextStyle(
                      fontSize: Sic.s18 - 1,
                    ),
                  ),
                ))
            .toList(),
        hint: Text(
          'حدد الفلترة',
          style: TextStyle(
            fontFamily: Fontc.marheySmallTitle,
            color: Colorc.darkGrey.withOpacity(0.8),
            fontSize: Sic.s15 + 1,
          ),
        ),
        style: TextStyle(
          fontFamily: Fontc.marheySmallTitle,
          color: Colorc.darkGrey.withOpacity(0.8),
          fontSize: Sic.s15 + 1,
        ),
        borderRadius: BorderRadius.circular(
          Radc.r24,
        ),
        padding: const EdgeInsetsDirectional.symmetric(
          horizontal: 10,
          vertical: 4,
        ),
        dropdownColor: Colorc.white,
        isExpanded: true,
        onChanged: onChanged,
        underline: const SizedBox(),
        iconEnabledColor: Colorc.darkGrey.withOpacity(0.8),
      ),
    );
  }

//form Field Edit Tasks :
  static Widget formEditTasks({
    required TextEditingController controller,
    required String? Function(String?)? validator,
    required TextInputType keyboardType,
    void Function(String)? onFieldSubmitted,
    bool obscureText = false,
    void Function()? onEditingComplete,
    String lable = '',
    String hintText = '',
    required TextInputAction textInputAction,
    Widget? icon,
    Widget? iconButton,
    void Function(String)? onchanged,
    bool? enableInteractiveSelection,
    void Function()? onTap,
    bool readOnly = false,
    TextDirection? textDirection,
    int? maxLength,
    List<TextInputFormatter>? inputFormatters,
    TextStyle? hintStyle,
    BoxShadow? shadow,
    double? horizontalPadding = 25,
    double vertical = 5,
    double? width,
  }) {
    TextStyle? hintStylee = hintStyle ??
        TextStyle(
            fontSize: Sic.s20,
            color: Colorc.darkGrey.withOpacity(0.8),
            fontFamily: Fontc.hayahBigTitle
            // fontFamily: Fontc.jana,
            );

    return Container(
      // height: 70,

      padding: const EdgeInsetsDirectional.only(
        bottom: 20,
        end: 25,
        start: 25,
        top: 0,
      ),
      child: TextFormField(
        inputFormatters: inputFormatters,
        maxLength: maxLength,
        textDirection: textDirection,
        style: TextStyle(
          color: Colorc.darkGrey,
          fontSize: Sic.s15,
          // fontFamily: Fontc.jana,
        ),
        onTapOutside: (v) {
          // FocusManager.instance.primaryFocus?.unfocus();
        },
        readOnly: readOnly,
        enableInteractiveSelection: enableInteractiveSelection,
        onChanged: onchanged,
        onTap: onTap,
        textInputAction: textInputAction,
        controller: controller,
        validator: validator,
        keyboardType: keyboardType,
        obscureText: obscureText,
        onFieldSubmitted: onFieldSubmitted,
        onEditingComplete: onEditingComplete,
        cursorRadius: const Radius.circular(30),
        cursorColor: Colorc.deepCyan,
        decoration: InputDecoration(
          contentPadding:
              const EdgeInsets.symmetric(vertical: 16, horizontal: 10),
          counter: const Offstage(),
          floatingLabelBehavior: FloatingLabelBehavior.always,
          hintText: "    $hintText",
          //hint style:
          hintStyle: hintStylee,
          enabledBorder: DecoratedInputBorder(
            // shadow: [shadowf],
            child: OutlineInputBorder(
              borderSide: const BorderSide(
                color: Colorc.black,
                width: 1.5,
              ),
              borderRadius: BorderRadius.circular(Radc.r24),
            ),
          ),
          suffixIcon: iconButton,
          prefixIcon: icon,
          floatingLabelStyle: TextStyle(
            color: Colorc.white,
            fontSize: Sic.s20,
            // fontFamily: Fontc.primary,
          ),
          label: Text(
            lable,
            style: TextStyle(
              fontSize: Sic.s15,
              color: Colorc.white,
              // fontFamily: Fontc.jana,
            ),
          ),
          border: DecoratedInputBorder(
            // shadow: [shadowf],
            child: OutlineInputBorder(
              borderSide: const BorderSide(
                color: Colorc.black,
                width: 1.5,
              ),
              borderRadius: BorderRadius.circular(Radc.r24),
            ),
          ),

          //error text style:
          errorStyle: TextStyle(
            color: Colorc.trans,
            overflow: TextOverflow.ellipsis,
            // fontFamily: Fontc.bah,
            fontSize: Sic.s12,
          ),
          focusColor: Colors.transparent,
          fillColor: Colorc.white,
          hoverColor: Colorc.white,
          focusedBorder: DecoratedInputBorder(
            // shadow: [shadowf],

            child: OutlineInputBorder(
              borderSide: const BorderSide(
                color: Colorc.black,
                width: 1.5,
              ),
              borderRadius: BorderRadius.circular(Radc.r24),
            ),
          ),
          filled: true,
        ),
      ),
    );
  }

//form Field Add Money Children :
  static Widget formFieldAddMoneyChildren({
    required TextEditingController controller,
    required String? Function(String?)? validator,
    required TextInputType keyboardType,
    void Function(String)? onFieldSubmitted,
    bool obscureText = false,
    void Function()? onEditingComplete,
    String lable = '',
    String hintText = '',
    required TextInputAction textInputAction,
    Widget? icon,
    Widget? iconButton,
    void Function(String)? onchanged,
    bool? enableInteractiveSelection,
    void Function()? onTap,
    bool readOnly = false,
    TextDirection? textDirection,
    int? maxLength,
    List<TextInputFormatter>? inputFormatters,
    TextStyle? hintStyle,
    BoxShadow? shadow,
    double? horizontalPadding = 50,
    double vertical = 15,
    double? width,
  }) {
    TextStyle? hintStylee = hintStyle ??
        TextStyle(
          fontSize: Sic.s15,
          color: Colorc.darkGrey.withOpacity(0.8),
          // fontFamily: Fontc.jana,
        );

    // BoxShadow shadowf = shadow ?? Shadc.smoth(color: Colorc.pink);
    BoxShadow shadowf = shadow ??
        BoxShadow(
          blurRadius: 1,
          offset: const Offset(0, -1.1),
          color: Colorc.darkGrey.withOpacity(0.7),
        );

    return Container(
      // height: 70,
      // width: width,
      padding: EdgeInsets.symmetric(
          horizontal: horizontalPadding!, vertical: vertical),
      child: TextFormField(
        inputFormatters: inputFormatters,
        maxLength: maxLength,
        textDirection: textDirection,
        style: TextStyle(
          color: Colorc.darkGrey,
          fontSize: Sic.s15,
          // fontFamily: Fontc.jana,
        ),
        onTapOutside: (v) {
          // FocusManager.instance.primaryFocus?.unfocus();
        },
        readOnly: readOnly,
        enableInteractiveSelection: enableInteractiveSelection,
        onChanged: onchanged,
        onTap: onTap,
        textInputAction: textInputAction,
        controller: controller,
        validator: validator,
        keyboardType: keyboardType,
        obscureText: obscureText,
        onFieldSubmitted: onFieldSubmitted,
        onEditingComplete: onEditingComplete,
        cursorRadius: const Radius.circular(30),
        cursorColor: Colorc.deepCyan,
        decoration: InputDecoration(
          contentPadding:
              const EdgeInsets.symmetric(vertical: 16, horizontal: 10),
          counter: const Offstage(),
          floatingLabelBehavior: FloatingLabelBehavior.always,
          hintText: hintText,
          //hint style:
          hintStyle: hintStylee,
          enabledBorder: DecoratedInputBorder(
            shadow: [shadowf],
            child: OutlineInputBorder(
              borderSide: BorderSide(
                color: Colorc.trans,
              ),
              borderRadius: BorderRadius.circular(Radc.r24),
            ),
          ),
          suffixIcon: iconButton,
          prefixIcon: icon,
          floatingLabelStyle: TextStyle(
            color: Colorc.white,
            fontSize: Sic.s20,
            // fontFamily: Fontc.primary,
          ),
          label: Text(
            lable,
            style: TextStyle(
              fontSize: Sic.s15,
              color: Colorc.white,
              // fontFamily: Fontc.jana,
            ),
          ),
          border: DecoratedInputBorder(
            shadow: [shadowf],
            child: OutlineInputBorder(
              borderSide: BorderSide(color: Colorc.trans, width: 1),
              borderRadius: BorderRadius.circular(Radc.r24),
            ),
          ),

          //error text style:
          errorStyle: TextStyle(
            color: Colorc.trans,
            overflow: TextOverflow.ellipsis,
            // fontFamily: Fontc.bah,
            fontSize: Sic.s12,
          ),
          focusColor: Colors.transparent,
          fillColor: Colorc.white,
          hoverColor: Colorc.white,
          focusedBorder: DecoratedInputBorder(
            shadow: [shadowf],
            child: OutlineInputBorder(
              borderSide: BorderSide(color: Colorc.trans, width: 1.0),
              borderRadius: BorderRadius.circular(Radc.r24),
            ),
          ),
          filled: true,
        ),
      ),
    );
  }

  //button for auth pages:
  static Widget buttonAuth({
    required String text,
    required void Function()? onTap,
  }) {
    return ZoomTapAnimation(
      begin: 1,
      end: 0.90,
      child: InkWell(
        overlayColor: WidgetStatePropertyAll(Colorc.trans),
        onTap: onTap,
        child: Container(
          width: double.infinity,
          height: 50,
          margin: const EdgeInsets.symmetric(horizontal: 20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(Radc.r36),
            boxShadow: [
              Shadc.button,
            ],
            color: Colorc.cyan,
          ),
          child: Center(
            child: Text(
              text,
              style: TextStyle(
                color: Colorc.white,
                fontSize: Sic.s22,
              ),
            ),
          ),
        ),
      ),
    );
  }

  //app bar
  static Widget appbar(
    context, {
    required String title,
    bool withBackArrow = false,
    bool withDivider = true,
    double fontsize = 110,
    double width = 10,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 0.0, vertical: 10),
      child: Column(
        children: [
          //data:
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Row(
              children: [
                //image :
                const Image(
                  fit: BoxFit.cover,
                  width: 120,
                  image: AssetImage(Imagec.logoWithoutText),
                ),
                //spacing :
                SizedBox(
                  width: width,
                ),
                // AREB text:
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    scrollDirection: Axis.horizontal,
                    child: Text(
                      title,
                      style: TextStyle(
                        color: Colorc.darkGrey,
                        fontSize: fontsize,
                        fontFamily: Fontc.hayahBigTitle,
                        fontWeight: FontWeight.w500,
                      ),
                      textAlign: TextAlign.center,
                      maxLines: 1,
                    ),
                  ),
                ),
                // //spacer:
                // const Spacer(),
                //back arrow :
                if (withBackArrow == true) ...[
                  Padding(
                    padding: const EdgeInsets.only(top: 6.0),
                    child: IconButton(
                      onPressed: () {
                        Navc.pop(context: context);
                      },
                      icon: Icon(
                        Icons.arrow_forward_ios_rounded,
                        color: Colorc.darkGrey,
                        size: Sic.s30,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
          //divider:
          if (withDivider == true) ...[
            Divider(
              color: Colorc.grey,
              thickness: 1.5,
              height: 2,
            ),
          ],
        ],
      ),
    );
  }

//bottom nav bar icon :
  static Widget bottomNavBarIcon({
    required IconData icon,
    required void Function()? onTap,
    required bool isSelected,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 5),
      decoration: BoxDecoration(
        color: Colorc.darkGrey.withOpacity(isSelected == true ? 0.3 : 0),
        borderRadius: BorderRadius.circular(
          Radc.r20,
        ),
      ),
      child: IconButton(
        onPressed: onTap,
        icon: Icon(
          icon,
          size: Sic.s28,
          color: Colorc.white,
        ),
      ),
    );
  }

//button with icon medium size:
  static Widget buttonWithIcon({
    required void Function()? onTap,
    required IconData icon,
    required text,
    width = 150.0,
  }) {
    return ZoomTapAnimation(
      begin: 1,
      end: 0.90,
      child: InkWell(
        overlayColor: WidgetStatePropertyAll(
          Colorc.trans,
        ),
        onTap: onTap,
        child: Container(
          width: width,
          // height: 50,
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colorc.purple,
            borderRadius: BorderRadius.circular(
              Radc.r15,
            ),
            border: Border.all(color: Colorc.white),
            boxShadow: [
              Shadc.button,
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              //add goole
              Text(
                text,
                style: TextStyle(
                  fontSize: Sic.s20,
                  color: Colorc.white,

                  // fontFamily: Fontc.hayahBigTitle,
                ),
                textAlign: TextAlign.center,
                maxLines: 2,
              ),
              //icon:
              Icon(
                icon,
                color: Colorc.white,
              )
            ],
          ),
        ),
      ),
    );
  }

//image Account
  static Widget imageAccount({
    bool point = true,
    required String imagename,
  }) {
    return Column(
      children: [
        //account image :
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(100),
            color: Colorc.grey,
          ),
          height: 150,
          width: 150,
          child: Image(
            image: AssetImage(imagename),
          ),
        ),
        //Edit image :
        point
            ? Transform.translate(
                offset: const Offset(45, -40),
                child: Container(
                  width: 25,
                  height: 25,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(
                      Radc.r50,
                    ),
                    color: Colorc.purple,
                  ),
                  child: Icon(Icons.edit_note_outlined,
                      color: Colorc.lightCyan, size: 20),
                ),
              )
            : const SizedBox(),
      ],
    );
  }

//card Chat smart Assistant
  static Widget cardChat({
    required String text,
    bool smartAssistant = false,
    void Function()? onTap,
  }) {
    return tapAnimation(
      onTap: onTap,
      child: Align(
        alignment: smartAssistant
            ? AlignmentDirectional.topEnd
            : AlignmentDirectional.topStart,
        child: Container(
          margin: EdgeInsetsDirectional.only(
            start: smartAssistant ? 100 : 10,
            end: smartAssistant ? 10 : 100,
            bottom: 8,
            top: 8,
          ),
          padding: const EdgeInsetsDirectional.symmetric(
            horizontal: 20,
            vertical: 10,
          ),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(Radc.r28),
            color: smartAssistant
                ? Colorc.grey.withOpacity(
                    0.4,
                  )
                : Colorc.mediumpurple,
          ),
          child: Text(
            text,
            style: TextStyle(
              fontFamily: Fontc.marheySmallTitle,
              color: Colorc.black.withOpacity(0.8),
              fontSize: Sic.s18 - 1,
            ),
          ),
        ),
      ),
    );
  }

  static Widget assetantLoading({
    bool smartAssistant = true,
  }) {
    return Align(
      alignment: smartAssistant
          ? AlignmentDirectional.topEnd
          : AlignmentDirectional.topStart,
      child: Container(
        width: 80,
        padding: const EdgeInsetsDirectional.symmetric(
          horizontal: 5,
          vertical: 5,
        ),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(Radc.r28),
          color: smartAssistant
              ? Colorc.grey.withOpacity(
                  0.2,
                )
              : Colorc.mediumpurple,
        ),
        child: Center(
          child: LoadingAnimationWidget.staggeredDotsWave(
              color: Colorc.darkGrey, size: 25),
        ),
      ),
    );
  }

//button with icon medium size:
  static Widget buttonWithIconinAccount({
    required void Function()? onTap,
    required IconData icon,
    required text,
    double width = 225.0,
    double? height,
    fontFamily = Fontc.marheySmallTitle,
    double fontSize = 18,
    Color coloricon = Colors.white,
    bool point = true,
    bool icons = true,
    double sizeicon = 30,
    FontWeight fontWeight = FontWeight.normal,
    MainAxisAlignment mainAxisAlignment = MainAxisAlignment.spaceEvenly,
  }) {
    return ZoomTapAnimation(
      begin: 1,
      end: 0.90,
      child: InkWell(
        overlayColor: WidgetStatePropertyAll(
          Colorc.trans,
        ),
        onTap: onTap,
        child: Column(
          children: [
            Container(
              width: width,
              height: height,
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colorc.mediumpurple,
                borderRadius: BorderRadius.circular(
                  Radc.r20,
                ),
                border: BorderDirectional(
                  top: BorderSide(
                    color:
                        const Color.fromARGB(255, 40, 40, 40).withOpacity(0.2),
                    width: 4,
                  ),
                ),
                boxShadow: [
                  Shadc.button,
                ],
              ),
              child: Row(
                mainAxisAlignment: mainAxisAlignment,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  //add goole
                  Text(
                    text,
                    style: TextStyle(
                      fontSize: fontSize,
                      color: Colorc.black,
                      fontFamily: fontFamily,
                      fontWeight: fontWeight,
                    ),
                    textAlign: TextAlign.center,
                    maxLines: 2,
                  ),
                  //icon:
                  icons
                      ? Icon(
                          icon,
                          size: sizeicon,
                          color: coloricon,
                        )
                      : const SizedBox(
                          height: 0,
                          width: 0,
                        ),
                ],
              ),
            ),
            point
                ? Transform.translate(
                    offset: const Offset(-110, -60),
                    child: Container(
                      width: 25,
                      height: 25,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(
                          Radc.r50,
                        ),
                        border: Border.all(
                          color: Colorc.black.withOpacity(0.5),
                          width: 2,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colorc.darkGrey.withOpacity(0.5),
                            offset: const Offset(0, 1),
                            blurRadius: 1,
                          )
                        ],
                        color: const Color.fromARGB(255, 216, 41, 29),
                      ),
                    ),
                  )
                : const SizedBox(),
          ],
        ),
      ),
    );
  }

//
  static Widget tasksCardChild(
      {required String tasksTitle,
      required String money,
      required String note,
      required void Function()? onTapNoti}) {
    return Container(
      padding: const EdgeInsetsDirectional.symmetric(
        vertical: 5,
        horizontal: 15,
      ),
      margin: const EdgeInsetsDirectional.symmetric(
        horizontal: 30,
        vertical: 10,
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(
          Radc.r10,
        ),
        color: Colorc.white,
        border: Border.all(
          color: Colorc.grey.withOpacity(0.5),
          width: 2,
        ),
        boxShadow: [
          Shadc.button,
        ],
      ),
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Text(
            tasksTitle,
            style: TextStyle(
              fontSize: Sic.s24,
              fontFamily: Fontc.hayahBigTitle,
              color: Colorc.black,
            ),
          ),
          Row(
            children: [
              Text(
                'الجائزة: $money ر.س',
                style: TextStyle(
                  fontSize: Sic.s24,
                  fontFamily: Fontc.hayahBigTitle,
                  color: Colorc.black,
                ),
              ),
              const Spacer(),
              note.isEmpty
                  ? Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(
                          25,
                        ),
                        color: Colorc.darkGrey,
                      ),
                      height: 30,
                      width: 30,
                      child: const Icon(
                        Icons.access_time_filled_rounded,
                        color: Colorc.white,
                        size: 25,
                      ),
                    )
                  : ZoomTapAnimation(
                      onTap: onTapNoti,
                      child: Column(
                        children: [
                          //notification icon

                          Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(
                                25,
                              ),
                              color: Colorc.deepCyan,
                            ),
                            height: 28,
                            width: 28,
                            child: const Icon(
                              Icons.notifications_active,
                              color: Colorc.white,
                              size: 20,
                            ),
                          ),
                          //spacing :
                          const SizedBox(
                            height: 5,
                          ),
                          //check icon
                          Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(
                                25,
                              ),
                              color: Colorc.green,
                            ),
                            height: 28,
                            width: 28,
                            child: const Icon(
                              Icons.check,
                              color: Colorc.white,
                              size: 20,
                            ),
                          ),
                        ],
                      ),
                    ),
            ],
          ),
          const SizedBox(
            height: 10,
          )
        ],
      ),
    );
  }

//
  static Widget tasksCard({
    required String tasksTitle,
    required String tasksName,
    required String money,
    required void Function() onTapRight,
    required void Function() onTapEdite,
  }) {
    return Container(
      margin: const EdgeInsetsDirectional.symmetric(
        horizontal: 30,
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(
          Radc.r20,
        ),
        color: Colorc.white,
        border: Border.all(
          color: Colorc.grey.withOpacity(0.5),
          width: 2,
        ),
        boxShadow: [
          Shadc.button,
        ],
      ),
      height: 210,
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          const SizedBox(
            height: 20,
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const SizedBox(
                width: 20,
              ),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(
                    1,
                  ),
                  color: Colorc.black.withOpacity(0.5),
                ),
                height: 5,
                width: 5,
              ),
              const SizedBox(
                width: 10,
              ),
              Text(
                // 'مهام عمر',
                tasksTitle,
                style: TextStyle(
                  fontSize: Sic.s28,
                  fontFamily: Fontc.hayahBigTitle,
                  fontWeight: FontWeight.bold,
                  color: Colorc.black.withOpacity(0.5),
                ),
              ),
              const SizedBox(
                height: 25,
              ),
            ],
          ),
          const SizedBox(
            height: 5,
          ),
          Container(
            height: 3,
            color: Colorc.grey.withOpacity(0.4),
            width: double.infinity,
          ),
          const SizedBox(
            height: 10,
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      const SizedBox(
                        width: 20,
                      ),
                      Text(
                        // 'سقي نباتات حديقة المنزل',
                        tasksName,
                        style: TextStyle(
                          fontSize: Sic.s24 + 1,
                          fontFamily: Fontc.hayahBigTitle,
                          overflow: TextOverflow.ellipsis,
                          // fontWeight: FontWeight.w700,
                          color: Colorc.black.withOpacity(0.8),
                        ),
                        maxLines: 4,
                      ),
                      const SizedBox(
                        height: 25,
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      const SizedBox(
                        width: 20,
                      ),
                      Text(
                        "الجائز المستحقة : $money ر.س",
                        style: TextStyle(
                          fontSize: Sic.s24 + 1,
                          fontFamily: Fontc.hayahBigTitle,
                          // fontWeight: FontWeight.w700,
                          color: Colorc.black.withOpacity(0.8),
                        ),
                      ),
                      const SizedBox(
                        height: 25,
                      ),
                    ],
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsetsDirectional.only(
                  end: 15,
                  top: 5,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    ZoomTapAnimation(
                      begin: 1,
                      end: 0.90,
                      child: InkWell(
                        overlayColor: WidgetStatePropertyAll(
                          Colorc.trans,
                        ),
                        onTap: onTapEdite,
                        child: Container(
                          height: 45,
                          width: 40,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(
                              15,
                            ),
                            color: Colorc.red,
                            boxShadow: [
                              Shadc.button,
                            ],
                          ),
                          child: const Icon(
                            Icons.edit_note,
                            color: Colorc.white,
                            size: 30,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    ZoomTapAnimation(
                      begin: 1,
                      end: 0.90,
                      child: InkWell(
                        overlayColor: WidgetStatePropertyAll(
                          Colorc.trans,
                        ),
                        onTap: onTapRight,
                        child: Container(
                          height: 40,
                          width: 40,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(
                              50,
                            ),
                            color: Colorc.green,
                            boxShadow: [
                              Shadc.button,
                            ],
                          ),
                          child: const Icon(
                            Icons.task_alt_rounded,
                            color: Colorc.white,
                            size: 30,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

//button Edit Tasks:
  static Widget buttonEditeTasks({
    required void Function()? onTap,
    required text,
    double? width,
    Color? backColor,
    Color? textColor,
  }) {
    Color backColorr = backColor ?? Colorc.mediumpurple;
    Color textColorr = textColor ?? Colorc.black;
    return ZoomTapAnimation(
      begin: 1,
      end: 0.90,
      child: InkWell(
        overlayColor: WidgetStatePropertyAll(
          Colorc.trans,
        ),
        onTap: onTap,
        child: Column(
          children: [
            Container(
              width: width,
              // height: 50,
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: backColorr,
                borderRadius: BorderRadius.circular(
                  Radc.r20,
                ),
                boxShadow: [
                  Shadc.button,
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  //add goole
                  Text(
                    text,
                    style: TextStyle(
                      fontSize: Sic.s20,
                      color: textColorr,
                      fontFamily: Fontc.hayahBigTitle,
                      fontWeight: FontWeight.w500,
                    ),
                    textAlign: TextAlign.center,
                    maxLines: 2,
                  ),
                  //icon:
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

//button with icon medium size:
  static Widget buttonAddMoney({
    required void Function()? onTap,
    required text,
    width = 160.0,
    Color? backColor,
    Color? textColor,
  }) {
    Color backColorr = backColor ?? Colorc.mediumpurple;
    Color textColorr = textColor ?? Colorc.white;
    return ZoomTapAnimation(
      begin: 1,
      end: 0.90,
      child: InkWell(
        overlayColor: WidgetStatePropertyAll(
          Colorc.trans,
        ),
        onTap: onTap,
        child: Column(
          children: [
            Container(
              width: width,
              // height: 50,
              padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 12),
              decoration: BoxDecoration(
                color: backColorr,
                borderRadius: BorderRadius.circular(
                  Radc.r10,
                ),
                boxShadow: [
                  Shadc.button,
                ],
              ),
              child: //add goole
                  Text(
                text,
                style: TextStyle(
                  fontSize: Sic.s18 - 1,
                  color: textColorr,

                  // fontFamily: Fontc.hayahBigTitle,
                ),
                textAlign: TextAlign.center,
                maxLines: 2,
              ),
            ),
          ],
        ),
      ),
    );
  }

//button Add Loan Card
  static Widget buttonAddLoanCard({
    required void Function()? onTap,
    required text,
    width = 50.0,
    required Color backColor,
  }) {
    return ZoomTapAnimation(
      begin: 1,
      end: 0.90,
      child: InkWell(
        overlayColor: WidgetStatePropertyAll(
          Colorc.trans,
        ),
        onTap: onTap,
        child: Container(
          width: width,
          // height: 50,
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: backColor,
            borderRadius: BorderRadius.circular(
              Radc.r10,
            ),
            boxShadow: [
              Shadc.button,
            ],
          ),
          child: Text(
            text,
            style: TextStyle(
              fontSize: Sic.s15,
              color: Colorc.white,

              // fontFamily: Fontc.hayahBigTitle,
            ),
            textAlign: TextAlign.center,
            maxLines: 2,
          ),
        ),
      ),
    );
  }

//child Card
  static Widget childCard({
    required String name,
    required String money,
    required String image,
    required void Function()? onTap,
  }) {
    return Container(
      margin:
          const EdgeInsetsDirectional.symmetric(vertical: 12, horizontal: 35),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(Radc.r20),
        boxShadow: [
          Shadc.button,
        ],
        border: Border.all(
          color: Colorc.grey.withOpacity(
            0.5,
          ),
          width: 2,
        ),
        color: Colorc.white,
      ),
      height: 200,
      width: double.infinity,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          //image
          Expanded(
            flex: 1,
            child: Padding(
              padding: const EdgeInsetsDirectional.symmetric(
                vertical: 5,
                horizontal: 10,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    clipBehavior: Clip.antiAlias,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(100),
                      color: Colorc.lightCyan,
                    ),
                    height: 80,
                    width: 80,
                    child: image.isEmpty
                        ? const Padding(
                            padding: EdgeInsets.symmetric(vertical: 5.0),
                            child: Image(image: AssetImage(Imagec.child)),
                          )
                        : networkImage(
                            imageUrl: Dioc.imageUrl + image,
                          ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Text(
                    name,
                    style: TextStyle(
                      fontSize: Sic.s20,
                      // fontFamily: Fontc.aGASmallTitle,
                      // fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
          //divider:
          Container(
            height: double.infinity,
            width: 2,
            color: Colorc.grey.withOpacity(0.5),
          ),
          //details:
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  ' الرصيد الحالي:',
                  style: TextStyle(
                    fontSize: Sic.s28,
                    fontFamily: Fontc.hayahBigTitle,
                    // fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      money,
                      style: TextStyle(
                        fontSize: Sic.s18,
                        fontFamily: Fontc.marheySmallTitle,
                      ),
                      // textAlign: TextAlign.center,
                    ),
                    const Icon(
                      Icons.monetization_on,
                      color: Colors.amber,
                      size: 20,
                    )
                  ],
                ),
                const SizedBox(
                  height: 30,
                ),
                Compc.buttonAddMoney(
                  text: 'إضافة المال',
                  onTap: onTap,
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

//loan Card
  static Widget loanCard({
    required String name,
    required String currentMoney,
    required String reasonForRequest,
    required String moneyRequired,
    required String image,
    required void Function() onTapYes,
    required void Function() onTapNo,
  }) {
    return Container(
      // padding: EdgeInsets.only(
      //   top: 10,
      // ),
      margin:
          const EdgeInsetsDirectional.symmetric(vertical: 15, horizontal: 30),

      padding:
          const EdgeInsetsDirectional.symmetric(vertical: 15, horizontal: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(Radc.r20),
        boxShadow: [
          Shadc.button,
        ],
        border: Border.all(
          color: Colorc.grey.withOpacity(
            0.5,
          ),
          width: 2,
        ),
        color: Colorc.white,
      ),
      width: sizeScreen.width,

      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          //image with title:
          Padding(
            padding: const EdgeInsetsDirectional.symmetric(
              horizontal: 10,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100),
                    color: Colorc.lightCyan,
                  ),
                  height: 80,
                  width: 80,
                  child: image.isEmpty
                      ? const Padding(
                          padding: EdgeInsets.symmetric(vertical: 5.0),
                          child: Image(image: AssetImage(Imagec.child)),
                        )
                      : networkImage(
                          imageUrl: Dioc.imageUrl + image,
                          height: 80,
                          width: 80,
                        ),
                ),
                const SizedBox(
                  height: 15,
                ),
                Text(
                  name,
                  style: TextStyle(
                    fontSize: Sic.s20,
                    fontFamily: Fontc.marheySmallTitle,
                    // fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),

          // //divider:

          Container(
            height: 200,
            width: 2,
            margin: const EdgeInsets.symmetric(vertical: 2),
            color: Colorc.grey.withOpacity(0.5),
          ),
          //details
          SizedBox(
            width: sizeScreen.width - 210,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  //current balance
                  Text(
                    " الرصيد الحالي : $currentMoney",
                    style: TextStyle(
                      fontSize: Sic.s22,
                      fontFamily: Fontc.hayahBigTitle,
                    ),
                    maxLines: 2,
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(
                    height: 6,
                  ),
                  //cuse of loan
                  Align(
                    alignment: AlignmentDirectional.center,
                    child: Text(
                      "سبب الطلب : $reasonForRequest",
                      style: TextStyle(
                        fontSize: Sic.s22,
                        fontFamily: Fontc.hayahBigTitle,
                        overflow: TextOverflow.ellipsis,
                      ),
                      textAlign: TextAlign.center,
                      maxLines: 6,
                    ),
                  ),
                  //spacign :

                  const SizedBox(
                    height: 8,
                  ),
                  //ammount of loans
                  Text(
                    "كميةالمساعدة المالية : $moneyRequired",
                    style: TextStyle(
                      fontSize: Sic.s24,
                      fontFamily: Fontc.hayahBigTitle,
                    ),
                    textAlign: TextAlign.center,
                    maxLines: 2,
                  ),
                  //spacign :
                  const SizedBox(
                    height: 15,
                  ),
                  //buttons :
                  SizedBox(
                    height: 35,
                    child: SizedBox.expand(
                      // width: sizeScreen.width - 210,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Expanded(
                            child: Compc.buttonAddLoanCard(
                              backColor: Colorc.green,
                              text: 'موافقة',
                              onTap: onTapYes,
                            ),
                          ),
                          //spacing :
                          const SizedBox(
                            width: 7,
                          ),
                          Expanded(
                            child: Compc.buttonAddLoanCard(
                              backColor: Colorc.red,
                              text: 'رفض',
                              onTap: onTapNo,
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

//done button:
  static Widget doneButton({
    Color? backColor,
    Color? textColor,
    required context,
    // required void Function()? onTap,
  }) {
    Color backColorr = backColor ?? Colorc.cyan;
    Color textColorr = textColor ?? Colorc.white;
    return ZoomTapAnimation(
      begin: 1,
      end: 0.90,
      child: InkWell(
        onTap: () {
          Navc.pushReplacment(
            context: context,
            screenToPush: const BottomNavBarFatherPage(
              indexBottomNav: 1,
            ),
            alignment: Alignment.center,
            type: PageTransitionType.scale,
          );
        },
        overlayColor: WidgetStatePropertyAll(Colorc.trans),
        child: Container(
          width: 200,
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: backColorr,
            borderRadius: BorderRadius.circular(
              Radc.r10,
            ),
            boxShadow: [
              Shadc.button,
            ],
          ),
          child: Center(
            child: Text(
              'تم',
              style: TextStyle(
                color: textColorr,
                fontSize: Sic.s18,
                // fontFamily: Fontc.hayahBigTitle,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ),
      ),
    );
  }

//loading widget :
  static Widget loading({
    Color? color,
  }) {
    Color colorc = color ?? Colorc.cyan;
    return Center(
      child: LoadingAnimationWidget.fourRotatingDots(
        size: 45,
        color: colorc,
      ),
    );
  }

//goals card for child :
  static Widget goalsChild({
    required String goalName,
    required String money,
    required String imageUrl,
    void Function()? onTapDelete,
    void Function()? onTapDone,
  }) {
    return Container(
      height: 180,
      width: double.infinity,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(
          Radc.r18,
        ),
        gradient: LinearGradient(
          begin: AlignmentDirectional.topCenter,
          end: AlignmentDirectional.bottomCenter,
          stops: const [0.3, 1],
          colors: [
            Colorc.cyan,
            const Color.fromARGB(255, 84, 124, 169),
          ],
        ),
        boxShadow: [
          Shadc.button,
          BoxShadow(
            blurRadius: 3,
            color: Colorc.darkGrey.withOpacity(0.8),
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: Column(
        children: [
          //image with title and disc:
          Expanded(
            child: Row(
              children: [
                Expanded(
                  flex: 3,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      //title :
                      Text(
                        'الهدف : $goalName',
                        style: TextStyle(
                          fontSize: Sic.s24,
                          // fontFamily: Fontc.hayahBigTitle,
                        ),
                      ),
                      //spacing :
                      const SizedBox(height: 5),
                      //disc :
                      Text(
                        'الرصيد الحالي $money ر.س',
                        style: TextStyle(
                          fontSize: Sic.s28,
                          fontFamily: Fontc.hayahBigTitle,
                        ),
                      ),
                    ],
                  ),
                ),
                //spacing :
                const SizedBox(
                  width: 10,
                ),
                //image :
                Expanded(
                  child: Center(
                    child: ClipRRect(
                      clipBehavior: Clip.antiAlias,
                      borderRadius: BorderRadius.circular(
                        Radc.r10,
                      ),
                      child: networkImage(
                        padding: 0,
                        handlColor: Colorc.white,
                        imageUrl: imageUrl,
                        fit: BoxFit.cover,
                        height: 90,
                        width: 90,
                        // width: 150,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          //spacing :
          const SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              //done goals
              Align(
                alignment: AlignmentDirectional.centerEnd,
                child: ZoomTapAnimation(
                  begin: 1,
                  end: 0.90,
                  child: InkWell(
                    overlayColor: WidgetStatePropertyAll(
                      Colorc.trans,
                    ),
                    onTap: onTapDone,
                    child: Container(
                      width: 130,
                      padding: const EdgeInsets.all(5),
                      decoration: BoxDecoration(
                        color: Colorc.cyan,
                        borderRadius: BorderRadius.circular(
                          Radc.r15,
                        ),
                      ),
                      child: Center(
                        child: Text(
                          'تم انجاز الهدف',
                          style: TextStyle(
                            fontSize: Sic.s18 - 1,
                            // fontFamily: Fontc.hayahBigTitle,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              //delete gols
              Align(
                alignment: AlignmentDirectional.centerEnd,
                child: ZoomTapAnimation(
                  begin: 1,
                  end: 0.90,
                  child: InkWell(
                    overlayColor: WidgetStatePropertyAll(
                      Colorc.trans,
                    ),
                    onTap: onTapDelete,
                    child: Container(
                      width: 130,
                      padding: const EdgeInsets.all(5),
                      decoration: BoxDecoration(
                        color: Colorc.grey,
                        borderRadius: BorderRadius.circular(
                          Radc.r15,
                        ),
                      ),
                      child: Center(
                        child: Text(
                          'حذف الهدف',
                          style: TextStyle(
                            fontSize: Sic.s18 - 1,
                            // fontFamily: Fontc.hayahBigTitle,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          )

          //delete goole button :
        ],
      ),
    );
  }

//goals card for father :
  static Widget goalsFather({
    required String goalName,
    required String name,
    required String money,
    required String imageUrl,
    void Function()? onTapgiveHelp,
  }) {
    return Container(
      height: 210,
      width: double.infinity,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(
          Radc.r18,
        ),
        gradient: LinearGradient(
          begin: AlignmentDirectional.topCenter,
          end: AlignmentDirectional.bottomCenter,
          stops: const [0.3, 1],
          colors: [
            Colorc.cyan,
            const Color.fromARGB(255, 84, 124, 169),
          ],
        ),
        boxShadow: [
          Shadc.button,
          BoxShadow(
            blurRadius: 3,
            color: Colorc.darkGrey.withOpacity(0.8),
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: Column(
        children: [
          //image with title and disc:
          Expanded(
            child: Row(
              children: [
                Expanded(
                  flex: 3,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      //name :
                      Text(
                        name,
                        style: TextStyle(
                          fontSize: Sic.s36,
                          fontFamily: Fontc.hayahBigTitle,
                        ),
                      ),
                      //spacing :
                      const SizedBox(height: 0),
                      //title :
                      Text(
                        'الهدف : $goalName',
                        style: TextStyle(
                            fontSize: Sic.s22,
                            // fontFamily: Fontc.hayahBigTitle,
                            overflow: TextOverflow.ellipsis),
                        maxLines: 3,
                      ),
                      //spacing :
                      const SizedBox(height: 5),
                      //disc :
                      Text(
                        'الرصيد الحالي $money ر.س',
                        style: TextStyle(
                          fontSize: Sic.s24,
                          fontFamily: Fontc.hayahBigTitle,
                        ),
                      ),
                    ],
                  ),
                ),

                //spacing :
                const SizedBox(
                  width: 10,
                ),
                //image :
                Expanded(
                  child: Center(
                    child: ClipRRect(
                      clipBehavior: Clip.antiAlias,
                      borderRadius: BorderRadius.circular(
                        Radc.r10,
                      ),
                      child: networkImage(
                        padding: 0,
                        handlColor: Colorc.white,
                        imageUrl: imageUrl,
                        fit: BoxFit.cover,
                        height: 90,
                        width: 90,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          //spacing :
          const SizedBox(
            height: 10,
          ),
          //delete goole button :
          Align(
            alignment: AlignmentDirectional.centerEnd,
            child: ZoomTapAnimation(
              begin: 1,
              end: 0.90,
              child: InkWell(
                overlayColor: WidgetStatePropertyAll(
                  Colorc.trans,
                ),
                onTap: onTapgiveHelp,
                child: Container(
                  width: 120,
                  padding: const EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    color: Colorc.cyan,
                    borderRadius: BorderRadius.circular(
                      Radc.r15,
                    ),
                  ),
                  child: Center(
                    child: Text(
                      'تقديم المساعدة',
                      style: TextStyle(
                        fontSize: Sic.s15,
                        // fontFamily: Fontc.hayahBigTitle,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

//dont have  widget :
  static Widget dontHave(String text, [String? image]) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        //text:
        Center(
          child: Text(
            text,
            style: TextStyle(
              color: Colorc.red,
              fontSize: Sic.s40,
              // fontFamily: Fontc.hayahBigTitle,
              fontWeight: FontWeight.w500,
            ),
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ),
        //spacing :
        const SizedBox(
          height: 15,
        ),
        //image child crying:
        Image(
          width: 97,
          fit: BoxFit.cover,
          image: AssetImage(
            image ?? Imagec.childCry,
          ),
        ),
      ],
    );
  }

//network cach image :
  static Widget networkImage({
    required String imageUrl,
    double dotsSize = 30,
    Color? handlColor,
    double padding = 20,
    BoxFit fit = BoxFit.cover,
    double? width,
    double? height,
  }) {
    Color color = handlColor ?? Colorc.cyan;
    return CachedNetworkImage(
      height: height,
      width: width,
      imageUrl: imageUrl,
      fit: fit,
      placeholder: (context, url) => Center(
        child: SizedBox(height: 75, width: 75, child: loading(color: color)),
      ),
      errorWidget: (context, url, error) => Padding(
        padding: EdgeInsets.symmetric(
          vertical: padding,
          horizontal: padding,
        ),
        child: const Image(
          image: AssetImage(
            Imagec.logoWithBack,
          ),
          fit: BoxFit.cover,
          height: 100,
        ),
      ),
    );
  }

//this for empty :
  static Widget empty({
    String title = ' هذه الصفحة فارغة !',
  }) {
    return SizedBox(
      // height: double.infinity,
      // width: double.infinity,
      child: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisSize: MainAxisSize.max,
            children: [
              //icon :
              Icon(
                Icons.shape_line,
                color: Colorc.darkGrey.withOpacity(0.7),
                size: 35,
              ),
              //spacing :
              const SizedBox(
                height: 20,
              ),
              //text
              Text(
                title,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colorc.darkGrey.withOpacity(0.7),
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

//no internet widget :
  static Widget noInternet(
    void Function()? onTap,
  ) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisSize: MainAxisSize.max,
        children: [
          //text
          Text(
            'حصل خطأ ما \n تأكد من الإتصال بالإنترنت',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w600,
              color: Colorc.darkGrey.withOpacity(0.7),
            ),
            textAlign: TextAlign.center,
          ),
          //spacing :
          const SizedBox(
            height: 15,
          ),
          //onTap recconnect :
          buttonWithIcon(
            text: 'إعادة الإتصال',
            onTap: onTap,
            icon: Icons.rotate_left_sharp,
            width: 180.0,
          )
        ],
      ),
    );
  }

  static Widget buttonWithIconBlacktext(
      {required void Function() onTap,
      required String text,
      required IconData icon}) {
    return ZoomTapAnimation(
      begin: 1,
      end: 0.90,
      child: InkWell(
        onTap: onTap,
        overlayColor: WidgetStatePropertyAll(Colorc.trans),
        child: Container(
          width: 190,
          padding: const EdgeInsets.symmetric(vertical: 5),
          decoration: BoxDecoration(
            color: Colorc.purple,
            borderRadius: BorderRadius.circular(Radc.r28),
            boxShadow: [
              Shadc.button,
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              //text :
              Text(
                text,
                style: TextStyle(
                  color: Colorc.black,
                  fontSize: Sic.s30,
                  fontFamily: Fontc.hayahBigTitle,
                  fontWeight: FontWeight.w500,
                ),
              ),
              //spacing :
              const SizedBox(
                width: 20,
              ),
              //icon:
              Icon(
                icon,
                color: Colorc.black,
                size: Sic.s24,
              ),
            ],
          ),
        ),
      ),
    );
  }

  static Widget loanChildCard(
      {required DateTime date,
      required double money,
      required String status,
      required String title}) {
    return Container(
      width: double.infinity,
      height: 170,
      margin: const EdgeInsets.symmetric(horizontal: 25),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        // color: Colorc.lightGreen,
        boxShadow: [
          BoxShadow(
            color: Colorc.black.withOpacity(0.3),
            offset: const Offset(0, 1),
            blurRadius: 2,
          )
        ],
        borderRadius: BorderRadius.circular(Radc.r15),
        gradient: LinearGradient(
          begin: AlignmentDirectional.topCenter,
          end: AlignmentDirectional.bottomCenter,
          stops: const [0.3, 1],
          colors: [
            Colorc.cyan,
            const Color.fromARGB(255, 84, 124, 169),
          ],
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          //date and ammount of loan:
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              //date
              Text(
                '${date.year}/${date.month}/${date.day}',
                style: TextStyle(fontSize: Sic.s18),
              ),
              //money
              Text(
                '$money ر.س',
                style: TextStyle(fontSize: Sic.s18),
              ),
            ],
          ),
          //spacing :

          const SizedBox(
            height: 10,
          ),
          //status of loan
          Text(
            'حالة الطلب : $status',
            style: TextStyle(
              fontSize: Sic.s18,
              color: status == 'مرفوض'
                  ? const Color.fromARGB(255, 255, 41, 41)
                  : status == 'مقبول'
                      ? const Color.fromARGB(255, 0, 155, 8)
                      : Colorc.white,
              shadows: [
                Shadow(
                  color: Colorc.white.withOpacity(0.4),
                  offset: const Offset(0, 1),
                  blurRadius: 4,
                ),
              ],
            ),
          ),
          //spacing :

          const SizedBox(
            height: 10,
          ),
          //title :
          Text(
            title,
            style: TextStyle(
              fontSize: Sic.s18,
              overflow: TextOverflow.ellipsis,
            ),
            maxLines: 4,
          ),
        ],
      ),
    );
  }

  static Widget recordSumAllRigister({
    required Color color,
    required String title,
    required String money,
    required String discription,
  }) {
    return Container(
      padding: const EdgeInsetsDirectional.symmetric(
        horizontal: 15,
        vertical: 10,
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(Radc.r10),
        color: Colorc.white,
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              //title
              Text(
                title,
                style: TextStyle(
                  fontFamily: Fontc.marheySmallTitle,
                  color: color,
                  fontSize: Sic.s18 + 2,
                ),
              ),
              //spacer
              const SizedBox(
                width: 5,
              ),
              //point
              Container(
                height: 10,
                width: 10,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(
                    Radc.r30,
                  ),
                  color: color,
                ),
              ),
            ],
          ),
          //spacer
          const SizedBox(
            height: 15,
          ),
          //money
          Text(
            '$money ر.س',
            style: TextStyle(
              fontFamily: Fontc.marheySmallTitle,
              color: Colorc.darkGrey.withOpacity(0.9),
              fontSize: Sic.s18,
            ),
          ),
          //spacer
          const SizedBox(
            height: 5,
          ),
          //sup title
          Text(
            discription,
            style: TextStyle(
              fontFamily: Fontc.marheySmallTitle,
              height: 1.7,
              color: Colorc.darkGrey.withOpacity(0.6),
              fontSize: Sic.s15,
            ),
          ),
        ],
      ),
    );
  }
}
