part of 'sign_up_bloc_cubit.dart';

@immutable
sealed class SignUpBlocState {}

final class SignUpBlocInitial extends SignUpBlocState {}

final class SignUpSuccess extends SignUpBlocState {
  final String message;

  SignUpSuccess(this.message);
}

final class SignUpLoading extends SignUpBlocState {}

final class SignUpError extends SignUpBlocState {
  final String error;

  SignUpError(this.error);
}
