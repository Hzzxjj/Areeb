import 'package:areb/functions/firebase.dart';
import 'package:areb/functions/message.dart';
import 'package:areb/functions/navigations.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/screens/auth/create_children/children.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:areb/shared/shared_preferences/shared_p.dart';
import 'package:calendar_date_picker2/calendar_date_picker2.dart';
import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:page_transition/page_transition.dart';

part 'sign_up_bloc_state.dart';

class SignUpBlocCubit extends Cubit<SignUpBlocState> {
  static SignUpBlocCubit get(context) => BlocProvider.of(context);

  SignUpBlocCubit() : super(SignUpBlocInitial());

  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController dateController = TextEditingController();

//ontap date field :
  void onTapDateField(context) {
    showCalendarDatePicker2Dialog(
      context: context,
      config: CalendarDatePicker2WithActionButtonsConfig(
        currentDate: DateTime(2000, 1, 1),
        lastDate: DateTime(2018, 12, 31),
        calendarType: CalendarDatePicker2Type.single,
      ),
      dialogSize: const Size(325, 400),
      value: [DateTime(1970, 1, 1)],
      borderRadius: BorderRadius.circular(20),
    ).then(
      (value) => value != null
          ? dateController.text =
              '${value[0]!.year}/${value[0]!.month}/${value[0]!.day}'
          : {},
    );
  }

  //sign up :
  void signup(context) {
    bool isvaildEmail = false;
    isvaildEmail = EmailValidator.validate(emailController.text);
    if (nameController.text.length > 2 &&
        isvaildEmail == true &&
        passwordController.text.length > 6 &&
        dateController.text.isNotEmpty) {
      emit(SignUpLoading());
      Dioc.signup(
        name: nameController.text,
        password: passwordController.text,
        email: emailController.text,
        date: dateController.text,
      ).then((value) async {
        if (value.data['message'] == 'successful') {
          Sharedc.storeString('token', value.data['token']);
          Sharedc.storeString('role', value.data['user']['role']);
          Sharedc.storeString('id', value.data['user']['id'].toString());

          await subscribeWithEmailAndUser(value.data['user']['id'].toString(),
              value.data['user']['role'].toString());

          if (value.data['user']['role'] == 'father') {
            //navigate to father ui:
            Navc.pushReplacment(
              context: context,
              screenToPush: const AddChiled(),
              type: PageTransitionType.rightToLeftWithFade,
            );
          }
          emit(SignUpSuccess(value.data['body']));
        } else {
          emit(SignUpError(value.data['body']));
          Messagec.showSnackBar(
            context: context,
            snackbar: Snackc.errorSnackBar(
              'الإسم موجود من قبل الرجاء اختيار اسم اخر ',
            ),
          );
        }
      }).catchError((e) {
        //print error

        emit(SignUpError(e));
      });
    } else {
      Messagec.showSnackBar(
        context: context,
        snackbar: Snackc.errorSnackBar(
          'يجب أن يكون الإسم فوق الحرفين وكلمة المرور فوق 6 أحرف وتعبئة جميع الحقول',
        ),
      );
    }
  }
}
