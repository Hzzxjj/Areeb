import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';
import 'package:areb/constants/fonts.dart';
import 'package:areb/constants/sizes.dart';
import 'package:areb/functions/message.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/screens/auth/signup/cubit/sign_up_bloc_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  late SignUpBlocCubit bloc;

  @override
  void initState() {
    super.initState();
    bloc = SignUpBlocCubit.get(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: BlocConsumer<SignUpBlocCubit, SignUpBlocState>(
        listener: (context, state) {
          state is SignUpError
              ? Messagec.showSnackBar(
                  context: context, snackbar: Snackc.errorSnackBar(state.error))
              : null;
          state is SignUpSuccess
              ? Messagec.showSnackBar(
                  context: context,
                  snackbar: Snackc.talkSnackBar(state.message))
              : null;
        },
        builder: (context, state) {
          return SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                children: [
                  //app bar and text areb and image :
                  Compc.appbar(
                    context,
                    title: 'أريب',
                    withBackArrow: true,
                    withDivider: false,
                  ),
                  //field and button :
                  ConstrainedBox(
                    constraints: BoxConstraints.tight(
                      Size(
                        MediaQuery.sizeOf(context).width - 40,
                        (MediaQuery.sizeOf(context).height) - 170,
                      ),
                    ),
                    child: Column(
                      children: [
                        //signup text :
                        Align(
                          alignment: AlignmentDirectional.centerStart,
                          child: Text(
                            ' تسجيل',
                            style: TextStyle(
                              color: Colorc.green,
                              fontSize: Sic.s28,
                              fontFamily: Fontc.hayahBigTitle,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                        //spacing :
                        const SizedBox(
                          height: 15,
                        ),
                        //fields :
                        Expanded(
                          child: Column(
                            children: [
                              // name text field :
                              Compc.formField(
                                controller: bloc.nameController,
                                validator: null,
                                keyboardType: TextInputType.text,
                                textInputAction: TextInputAction.next,
                                hintText: 'الإسم',
                              ),
                              //spacing :
                              const SizedBox(
                                height: 15,
                              ),
                              //email
                              Compc.formField(
                                controller: bloc.emailController,
                                validator: null,
                                keyboardType: TextInputType.emailAddress,
                                textInputAction: TextInputAction.next,
                                hintText: 'البريد الإلكتروني',
                              ),
                              //spacing :
                              const SizedBox(
                                height: 15,
                              ),
                              //password :
                              Compc.formField(
                                controller: bloc.passwordController,
                                validator: null,
                                keyboardType: TextInputType.text,
                                textInputAction: TextInputAction.next,
                                hintText: 'كلمة المرور',
                              ),
                              //spacing :
                              const SizedBox(
                                height: 15,
                              ),
                              //date:
                              Compc.formField(
                                readOnly: true,
                                onTap: () {
                                  bloc.onTapDateField(context);
                                },
                                controller: bloc.dateController,
                                validator: null,
                                keyboardType: TextInputType.text,
                                textInputAction: TextInputAction.done,
                                hintText: 'تاريخ الميلاد',
                              ),
                              //spacing :
                              const Spacer(),

                              //button:
                              BlocBuilder<SignUpBlocCubit, SignUpBlocState>(
                                builder: (context, state) {
                                  if (state is SignUpLoading) {
                                    return Compc.loading();
                                  } else {
                                    return Compc.buttonAuth(
                                      text: 'تسجيل',
                                      onTap: () {
                                        bloc.signup(context);
                                      },
                                    );
                                  }
                                },
                              ),
                              //spacing :
                              const SizedBox(
                                height: 80,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
