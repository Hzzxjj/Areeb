import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';
import 'package:areb/constants/fonts.dart';
import 'package:areb/constants/images.dart';
import 'package:areb/functions/message.dart';
import 'package:areb/functions/navigations.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/screens/auth/signin/cubit/signin_bloc_cubit.dart';
import 'package:areb/screens/auth/signup/signup.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:page_transition/page_transition.dart';

class Signin extends StatefulWidget {
  const Signin({super.key});

  @override
  State<Signin> createState() => _SigninState();
}

class _SigninState extends State<Signin> {
  late SigninBlocCubit bloc;

  @override
  void initState() {
    super.initState();
    bloc = SigninBlocCubit.get(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: SafeArea(
        child: BlocConsumer<SigninBlocCubit, SigninBlocState>(
          listener: (context, state) {
            state is SigninError
                ? Messagec.showSnackBar(
                    context: context,
                    snackbar: Snackc.errorSnackBar(state.error))
                : null;
            state is SigninSuccess
                ? Messagec.showSnackBar(
                    context: context,
                    snackbar: Snackc.talkSnackBar(state.message))
                : null;
          },
          builder: (context, state) {
            return Column(
              children: [
                //spacer:
                const SizedBox(
                  height: 25,
                ),
                //fields and title and button :
                Expanded(
                  flex: 2,
                  child: Center(
                    // flex: 2,
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      child: Column(
                        children: [
                          // AREB text:
                          Text(
                            'أريب',
                            style: TextStyle(
                              color: Colorc.darkGrey,
                              fontSize: 110,
                              fontFamily: Fontc.hayahBigTitle,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          //spacing :
                          const SizedBox(
                            height: 15,
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 30),
                            child: Column(
                              children: [
                                // name text field :
                                Compc.formField(
                                  controller: bloc.nameController,
                                  validator: null,
                                  keyboardType: TextInputType.text,
                                  textInputAction: TextInputAction.next,
                                  hintText: 'الإسم',
                                  iconButton: Icon(
                                    Icons.person,
                                    color: Colorc.green,
                                  ),
                                ),
                                //spacing :
                                const SizedBox(
                                  height: 15,
                                ),
                                //password text field :
                                Compc.formField(
                                  obscureText: true,
                                  controller: bloc.passwordController,
                                  validator: null,
                                  keyboardType: TextInputType.text,
                                  textInputAction: TextInputAction.done,
                                  hintText: 'كلمة المرور',
                                  iconButton: Icon(
                                    Icons.lock_rounded,
                                    color: Colorc.green,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          //spacing :
                          const SizedBox(
                            height: 15,
                          ),
                          //forget password :
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 30),
                            child: Align(
                              alignment: AlignmentDirectional.centerStart,
                              child: Text(
                                'هل نسيت كلمة المرور ؟',
                                style: TextStyle(
                                  color: Colorc.black,
                                  fontSize: 23,
                                  fontFamily: Fontc.hayahBigTitle,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ),
                          //spacing :
                          const SizedBox(
                            height: 20,
                          ),
                          //button:
                          BlocBuilder<SigninBlocCubit, SigninBlocState>(
                            builder: (context, state) {
                              if (state is SigninLoading) {
                                return Compc.loading();
                              } else {
                                return Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 30.0),
                                  child: Compc.buttonAuth(
                                    text: 'تسجيل الدخول',
                                    onTap: () {
                                      bloc.signin(context);
                                    },
                                  ),
                                );
                              }
                            },
                          ),
                          //spacing :
                          const SizedBox(
                            height: 20,
                          ),
                          //dont have an account :
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 30),
                            child: Align(
                              alignment: AlignmentDirectional.centerStart,
                              child: Row(
                                children: [
                                  //dont have an account :
                                  const Text(
                                    'ليس لديك حساب ؟',
                                    style: TextStyle(
                                      color: Colorc.black,
                                      fontSize: 22,
                                      fontFamily: Fontc.hayahBigTitle,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  //sign up
                                  InkWell(
                                    onTap: () {
                                      Navc.push(
                                        context: context,
                                        screenToPush: const SignUp(),
                                        type: PageTransitionType.leftToRight,
                                      );
                                    },
                                    child: Text(
                                      ' سجل',
                                      style: TextStyle(
                                        color: Colorc.green,
                                        fontSize: 26,
                                        fontFamily: Fontc.hayahBigTitle,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                //image stand child :
                const Expanded(
                  flex: 1,
                  child: Padding(
                    padding:
                        EdgeInsets.symmetric(horizontal: 20.0, vertical: 10),
                    child: Align(
                      alignment: AlignmentDirectional.centerStart,
                      child: Image(
                        fit: BoxFit.cover,
                        image: AssetImage(
                          Imagec.child,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
