import 'package:areb/functions/firebase.dart';
import 'package:areb/functions/message.dart';
import 'package:areb/functions/navigations.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/screens/child/bottom_nav_bar/bottom_nav_bar_child_page.dart';
import 'package:areb/screens/father/bottom_nav_bar/bottom_nav_bar_father_page.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:areb/shared/shared_preferences/shared_p.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

part 'signin_bloc_state.dart';

class SigninBlocCubit extends Cubit<SigninBlocState> {
  static SigninBlocCubit get(context) => BlocProvider.of(context);

  SigninBlocCubit() : super(SigninBlocInitial());

  final TextEditingController nameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  //signin:
  void signin(context) {
    if (nameController.text.isNotEmpty &&
        nameController.text.length > 2 &&
        passwordController.text.isNotEmpty &&
        passwordController.text.length > 6) {
      emit(SigninLoading());

      Dioc.signin(
        name: nameController.text,
        password: passwordController.text,
      ).then(
        (value) async {
          if (value.data['message'] == 'successful') {
            Sharedc.storeString('token', value.data['token']);
            Sharedc.storeString('role', value.data['user']['role']);
            Sharedc.storeString('id', value.data['user']['id'].toString());
            await subscribeWithEmailAndUser(value.data['user']['id'].toString(),
                value.data['user']['role'].toString());

            if (value.data['user']['role'] == 'father') {
              //navigate to father ui:
              Navc.pushReplacment(
                context: context,
                screenToPush: const BottomNavBarFatherPage(),
              );
            } else {
              //navigate to child ui:
              Navc.pushReplacment(
                context: context,
                screenToPush: const BottomNavBarChildPage(),
              );
            }
            emit(SigninSuccess(value.data['body']));
          } else {
            emit(SigninError(value.data['body']));
          }
        },
      ).catchError((e) {
        emit(SigninError(e.toString()));
      });
    } else {
      Messagec.showSnackBar(
        context: context,
        snackbar: Snackc.errorSnackBar(
          ' يجب ان يكون الاسم فوق حرفين وكلمة المرور فوق 6 أحرف على الأقل ',
        ),
      );
    }
  }

  // void Function()? onTapLogin() {
  //   signin();
  //   return null;
  // }
}
