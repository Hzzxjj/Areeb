part of 'signin_bloc_cubit.dart';

@immutable
sealed class SigninBlocState {}

final class SigninBlocInitial extends SigninBlocState {}

final class SigninSuccess extends SigninBlocState {
  final String message;
  SigninSuccess(this.message);
}

final class SigninLoading extends SigninBlocState {}

final class SigninError extends SigninBlocState {
  final String error;

  SigninError(this.error);
}
