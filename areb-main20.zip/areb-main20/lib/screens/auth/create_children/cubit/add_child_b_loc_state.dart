part of 'add_child_b_loc_cubit.dart';

@immutable
sealed class AddChildBLocState {}

final class AddChildBLocInitial extends AddChildBLocState {}

final class AddChildSuccess extends AddChildBLocState {
  final String messgage;
  AddChildSuccess(this.messgage);
}

final class AddChildLoading extends AddChildBLocState {}

final class AddChildError extends AddChildBLocState {
  final String error;
  AddChildError(this.error);
}
