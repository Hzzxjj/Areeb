import 'package:areb/functions/message.dart';
import 'package:areb/functions/navigations.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/screens/father/bottom_nav_bar/bottom_nav_bar_father_page.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:calendar_date_picker2/calendar_date_picker2.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
part 'add_child_b_loc_state.dart';

class AddChildBLocCubit extends Cubit<AddChildBLocState> {
  static AddChildBLocCubit get(context) => BlocProvider.of(context);
  AddChildBLocCubit() : super(AddChildBLocInitial());

  final TextEditingController nameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController dateController = TextEditingController();
  int childCount = 0;

  void onTapDateField(context) {
    showCalendarDatePicker2Dialog(
      context: context,
      config: CalendarDatePicker2WithActionButtonsConfig(
        currentDate: DateTime(2018, 1, 1),
        firstDate: DateTime(2010, 1, 1),
        lastDate: DateTime(DateTime.now().year - 3, 12, 31),
        calendarType: CalendarDatePicker2Type.single,
      ),
      dialogSize: const Size(325, 400),
      value: [DateTime(2018, 1, 1)],
      borderRadius: BorderRadius.circular(20),
    ).then(
      (value) => value != null
          ? dateController.text =
              '${value[0]!.year}/${value[0]!.month}/${value[0]!.day}'
          : {},
    );
  }

  //add child :
  void addChild(context) {
    if (nameController.text.length > 2 &&
        passwordController.text.length > 6 &&
        dateController.text.isNotEmpty) {
      emit(AddChildLoading());
      Dioc.postChildren(
        name: nameController.text,
        password: passwordController.text,
        date: dateController.text,
      ).then((value) {
        if (value.data['message'] == 'successful') {
          childCount++;
          nameController.clear();
          passwordController.clear();
          dateController.clear();
          emit(AddChildSuccess(value.data['body']));
        } else {
          emit(AddChildError(value.data['body']));
        }
      }).catchError((e) {
        emit(AddChildError(e.toString()));
      });
    } else {
      Messagec.showSnackBar(
        context: context,
        snackbar: Snackc.errorSnackBar(
            'يجب أن يكون الإسم فوق الحرفين وكلمة المرور فوق 6 أحرف وتعبئة جميع الحقول'),
      );
    }
  }

//on tap login in add child :
  void onTapLog(context) {
    if (childCount > 0) {
      Navc.pushReplacment(
        context: context,
        screenToPush: const BottomNavBarFatherPage(),
      );
    } else {
      Messagec.showSnackBar(
        context: context,
        snackbar: Snackc.errorSnackBar('يجب إضافة طفل على الأقل'),
      );
    }
  }
}
