import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';
import 'package:areb/constants/fonts.dart';
import 'package:areb/constants/radius.dart';
import 'package:areb/constants/shadow.dart';
import 'package:areb/constants/sizes.dart';
import 'package:areb/functions/message.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/screens/auth/create_children/cubit/add_child_b_loc_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zoom_tap_animation/zoom_tap_animation.dart';

class AddChiled extends StatefulWidget {
  const AddChiled({super.key});

  @override
  State<AddChiled> createState() => _AddChiledState();
}

class _AddChiledState extends State<AddChiled> {
  late AddChildBLocCubit bloc;

  @override
  void initState() {
    bloc = bloc = AddChildBLocCubit.get(context);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: BlocConsumer<AddChildBLocCubit, AddChildBLocState>(
        listener: (context, state) {
          state is AddChildError
              ? Messagec.showSnackBar(
                  context: context, snackbar: Snackc.errorSnackBar(state.error))
              : null;
          state is AddChildSuccess
              ? Messagec.showSnackBar(
                  context: context,
                  snackbar: Snackc.talkSnackBar(state.messgage))
              : null;
        },
        builder: (context, state) {
          return SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                children: [
                  //app bar and text areb and image :
                  Compc.appbar(
                    context,
                    title: 'أريب',
                    withBackArrow: false,
                    withDivider: false,
                  ),

                  //field and button :
                  ConstrainedBox(
                    constraints: BoxConstraints.tight(
                      Size(
                        MediaQuery.sizeOf(context).width - 40,
                        (MediaQuery.sizeOf(context).height) - 170,
                      ),
                    ),
                    child: Column(
                      children: [
                        //rigister child account text:
                        Align(
                          alignment: AlignmentDirectional.centerStart,
                          child: Text(
                            ' تسجيل حساب الطفل',
                            style: TextStyle(
                              color: Colorc.green,
                              fontSize: Sic.s28,
                              fontFamily: Fontc.hayahBigTitle,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                        //spacing :
                        const SizedBox(
                          height: 10,
                        ),
                        //child account text :
                        Align(
                          alignment: AlignmentDirectional.centerStart,
                          child: Container(
                            width: 110,
                            decoration: BoxDecoration(
                              color: Colorc.purple,
                              borderRadius: BorderRadius.circular(Radc.r28),
                            ),
                            child: Center(
                              child: Text(
                                'حساب الطفل',
                                style: TextStyle(
                                  color: Colorc.black,
                                  fontSize: Sic.s28,
                                  fontFamily: Fontc.hayahBigTitle,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ),
                        ),
                        //spacing :
                        const SizedBox(
                          height: 15,
                        ),
                        //fields :
                        Expanded(
                          child: Column(
                            children: [
                              // name text field :
                              Compc.formField(
                                controller: bloc.nameController,
                                validator: null,
                                keyboardType: TextInputType.text,
                                textInputAction: TextInputAction.next,
                                hintText: 'الإسم',
                              ),
                              //spacing :
                              const SizedBox(
                                height: 15,
                              ),

                              //password :
                              Compc.formField(
                                controller: bloc.passwordController,
                                validator: null,
                                keyboardType: TextInputType.text,
                                textInputAction: TextInputAction.next,
                                hintText: 'كلمة المرور',
                              ),
                              //spacing :
                              const SizedBox(
                                height: 15,
                              ),
                              //date:
                              Compc.formField(
                                readOnly: true,
                                onTap: () {
                                  bloc.onTapDateField(context);
                                },
                                controller: bloc.dateController,
                                validator: null,
                                keyboardType: TextInputType.text,
                                textInputAction: TextInputAction.done,
                                hintText: 'تاريخ الميلاد',
                              ),
                              //spacing :
                              const Spacer(),
                              //add more child :
                              BlocBuilder<AddChildBLocCubit, AddChildBLocState>(
                                builder: (context, state) {
                                  if (state is AddChildLoading) {
                                    return Compc.loading(color: Colorc.purple);
                                  } else {
                                    return Align(
                                      alignment:
                                          AlignmentDirectional.centerStart,
                                      child: ZoomTapAnimation(
                                        begin: 1,
                                        end: 0.90,
                                        child: InkWell(
                                          onTap: () {
                                            bloc.addChild(context);
                                          },
                                          overlayColor: WidgetStatePropertyAll(
                                              Colorc.trans),
                                          child: Container(
                                            width: 160,
                                            decoration: BoxDecoration(
                                              color: Colorc.purple,
                                              borderRadius:
                                                  BorderRadius.circular(
                                                      Radc.r28),
                                              boxShadow: [
                                                Shadc.button,
                                              ],
                                            ),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                //text :
                                                Text(
                                                  'إضافة طفل',
                                                  style: TextStyle(
                                                    color: Colorc.black,
                                                    fontSize: Sic.s30,
                                                    fontFamily:
                                                        Fontc.hayahBigTitle,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                ),
                                                //spacing :
                                                const SizedBox(
                                                  width: 20,
                                                ),
                                                //icon:
                                                Icon(
                                                  Icons.plus_one,
                                                  color: Colorc.black,
                                                  size: Sic.s24,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    );
                                  }
                                },
                              ),

                              //spacing :
                              const SizedBox(
                                height: 20,
                              ),
                              //button:
                              Compc.buttonAuth(
                                text: 'تسجيل',
                                onTap: () {
                                  bloc.onTapLog(context);
                                },
                              ),
                              //spacing :
                              const SizedBox(
                                height: 80,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
