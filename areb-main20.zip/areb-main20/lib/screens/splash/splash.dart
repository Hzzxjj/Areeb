import 'package:areb/constants/colors.dart';
import 'package:areb/constants/images.dart';
import 'package:areb/functions/navigations.dart';
import 'package:areb/screens/auth/signin/signin.dart';
import 'package:areb/screens/child/bottom_nav_bar/bottom_nav_bar_child_page.dart';
import 'package:areb/screens/father/bottom_nav_bar/bottom_nav_bar_father_page.dart';
import 'package:areb/shared/shared_preferences/shared_p.dart';
import 'package:flutter/material.dart';

class Splash extends StatefulWidget {
  const Splash({super.key});

  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  void initState() {
    Future.delayed(
      const Duration(
        seconds: 2,
      ),
      () {
        if (Sharedc.getString('token') != '') {
          if (Sharedc.getString('role') == 'father') {
            Navc.pushReplacment(
              context: context,
              screenToPush: const BottomNavBarFatherPage(),
            );
          } else {
            Navc.pushReplacment(
              context: context,
              screenToPush: const BottomNavBarChildPage(),
            );
          }
        } else {
          Navc.pushReplacment(
            context: context,
            screenToPush: const Signin(),
          );
        }
      },
    );
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colorc.white,
      extendBody: true,
      body: SizedBox(
        width: double.infinity,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.max,
          children: [
            //logo:
            const Image(
              image: AssetImage(Imagec.logoWithBack),
              fit: BoxFit.cover,
              width: 300,
            ),
            //spacing :
            const SizedBox(
              height: 5,
            ),
            //text:
            Text(
              'أريب صديق رحلتك الحالية',
              style: TextStyle(
                color: Colorc.deepCyan,
                fontSize: 22,
              ),
            )
          ],
        ),
      ),
    );
  }
}
