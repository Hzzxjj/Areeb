part of 'add_children_into_app_cubit.dart';

@immutable
sealed class AddChildrenIntoAppState {}

final class AddChildrenIntoAppInitial extends AddChildrenIntoAppState {}

final class AddChildSuccess extends AddChildrenIntoAppState {}

final class AddChildLoading extends AddChildrenIntoAppState {}

final class AddChildError extends AddChildrenIntoAppState {
  final String error;
  AddChildError(this.error);
}
