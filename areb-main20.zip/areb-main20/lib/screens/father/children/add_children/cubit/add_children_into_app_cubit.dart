import 'package:areb/functions/message.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:calendar_date_picker2/calendar_date_picker2.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/material.dart';

part 'add_children_into_app_state.dart';

class AddChildrenIntoAppCubit extends Cubit<AddChildrenIntoAppState> {
  static AddChildrenIntoAppCubit get(context) => BlocProvider.of(context);

  final TextEditingController nameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController dateController = TextEditingController();

  AddChildrenIntoAppCubit() : super(AddChildrenIntoAppInitial());

  void onTapDateField(context) {
    showCalendarDatePicker2Dialog(
      context: context,
      config: CalendarDatePicker2WithActionButtonsConfig(
        currentDate: DateTime(2018, 1, 1),
        firstDate: DateTime(2010, 1, 1),
        lastDate: DateTime(DateTime.now().year - 3, 12, 31),
        calendarType: CalendarDatePicker2Type.single,
      ),
      dialogSize: const Size(325, 400),
      value: [DateTime(2018, 1, 1)],
      borderRadius: BorderRadius.circular(20),
    ).then(
      (value) => value != null
          ? dateController.text =
              '${value[0]!.year}/${value[0]!.month}/${value[0]!.day}'
          : {},
    );
  }

  void onTapAddChild(context) {
    if (nameController.text.length > 2 &&
        passwordController.text.length > 6 &&
        dateController.text.isNotEmpty) {
      emit(AddChildLoading());
      Dioc.postChildren(
        name: nameController.text,
        password: passwordController.text,
        date: dateController.text,
      ).then((value) {
        if (value.data['message'] == 'successful') {
          Messagec.showSnackBar(
            context: context,
            snackbar: Snackc.talkSnackBar('تم إضافة الطفل بنجاح'),
          );
          nameController.clear();
          passwordController.clear();
          dateController.clear();
          emit(AddChildSuccess());
        } else {
          emit(AddChildError(value.data['body']));
          Messagec.showSnackBar(
            context: context,
            snackbar: Snackc.errorSnackBar(
              'الإسم موجود من قبل الرجاء اختيار اسم اخر ',
            ),
          );
        }
      }).catchError((e) {
        emit(AddChildError(e.toString()));
      });
    } else {
      Messagec.showSnackBar(
        context: context,
        snackbar: Snackc.errorSnackBar(
          'يجب أن يكون الإسم فوق الحرفين وكلمة المرور فوق 6 أحرف وتعبئة جميع الحقول',
        ),
      );
    }
  }
}
