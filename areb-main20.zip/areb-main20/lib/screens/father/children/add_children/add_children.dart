import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';
import 'package:areb/constants/fonts.dart';

import 'package:areb/constants/sizes.dart';

import 'package:areb/screens/father/children/add_children/cubit/add_children_into_app_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class AddChildren extends StatefulWidget {
  const AddChildren({super.key});

  @override
  State<AddChildren> createState() => _AddChildrenState();
}

class _AddChildrenState extends State<AddChildren> {
  late AddChildrenIntoAppCubit bloc;
  @override
  void initState() {
    bloc = AddChildrenIntoAppCubit.get(context);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            children: [
              //app bar and text areb and image :
              Compc.appbar(
                context,
                title: 'إضافة طفل',
                fontsize: 50,
                withBackArrow: true,
                withDivider: false,
              ),

              //field and button :
              ConstrainedBox(
                constraints: BoxConstraints.tight(
                  Size(
                    MediaQuery.sizeOf(context).width - 40,
                    (MediaQuery.sizeOf(context).height) - 170,
                  ),
                ),
                child: Column(
                  children: [
                    //rigister child account text:
                    Align(
                      alignment: AlignmentDirectional.centerStart,
                      child: Text(
                        ' إضافة حساب طفل',
                        style: TextStyle(
                          color: Colorc.green,
                          fontSize: Sic.s28,
                          fontFamily: Fontc.hayahBigTitle,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    //spacing :
                    const SizedBox(
                      height: 10,
                    ),

                    //spacing :
                    const SizedBox(
                      height: 15,
                    ),
                    //fields :
                    Expanded(
                      child: Column(
                        children: [
                          // name text field :
                          Compc.formField(
                            controller: bloc.nameController,
                            validator: null,
                            keyboardType: TextInputType.text,
                            textInputAction: TextInputAction.next,
                            hintText: 'الإسم',
                          ),
                          //spacing :
                          const SizedBox(
                            height: 15,
                          ),

                          //password :
                          Compc.formField(
                            controller: bloc.passwordController,
                            validator: null,
                            keyboardType: TextInputType.text,
                            textInputAction: TextInputAction.next,
                            hintText: 'كلمة المرور',
                          ),
                          //spacing :
                          const SizedBox(
                            height: 15,
                          ),
                          //date:
                          Compc.formField(
                            readOnly: true,
                            onTap: () {
                              bloc.onTapDateField(context);
                            },
                            controller: bloc.dateController,
                            validator: null,
                            keyboardType: TextInputType.text,
                            textInputAction: TextInputAction.done,
                            hintText: 'تاريخ الميلاد',
                          ),
                          //spacing :
                          const Spacer(),
                          //add more child :
                          BlocBuilder<AddChildrenIntoAppCubit,
                              AddChildrenIntoAppState>(
                            builder: (context, state) {
                              if (state is AddChildLoading) {
                                return Compc.loading(color: Colorc.purple);
                              } else {
                                return Compc.buttonWithIconBlacktext(
                                  onTap: () {
                                    bloc.onTapAddChild(context);
                                  },
                                  text: 'تسجيل الطفل',
                                  icon: Icons.check,
                                );
                              }
                            },
                          ),

                          //spacing :
                          const SizedBox(
                            height: 80,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
