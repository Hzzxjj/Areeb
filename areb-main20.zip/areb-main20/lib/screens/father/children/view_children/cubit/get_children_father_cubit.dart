import 'package:areb/functions/navigations.dart';
import 'package:areb/screens/father/children/add_children/add_children.dart';
import 'package:areb/screens/father/children/add_money_to_chlidren/add_money_to_chlidren.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:areb/shared/models/child/child.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/material.dart';

part 'get_children_father_state.dart';

class GetChildrenFatherCubit extends Cubit<GetChildrenFatherState> {
  static GetChildrenFatherCubit get(context) => BlocProvider.of(context);
  GetChildrenFatherCubit() : super(GetChildrenFatherInitial());
  List<Child> children = [];
  bool getDataonce = false;
  void getChildren(context) {
    emit(GetChildrenFatherLoading());
    Dioc.getChildren().then(
      (value) {
        if (value.data['message'] == 'successful') {
          children = List<Child>.from(
              value.data['children'].map((e) => Child.fromMap(e)));
          getDataonce = true;

          emit(GetChildrenFatherSuccess(value.data['body']));
        } else {
          emit(GetChildrenFatherError(value.data['body']));
        }
      },
    ).catchError((e) {
      emit(GetChildrenFatherError(e.toString()));
    });
  }

  void onTapAddChildren(context) {
    Navc.push(
      context: context,
      screenToPush: const AddChildren(),
    );
  }

  void onTapAddMoneyforChild(int index, context) {
    Navc.push(
        context: context,
        screenToPush: AddMoneyTOChildren(
          child: children[index],
        ));
  }
}
