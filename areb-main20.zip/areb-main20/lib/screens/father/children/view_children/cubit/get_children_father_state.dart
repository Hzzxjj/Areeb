part of 'get_children_father_cubit.dart';

@immutable
sealed class GetChildrenFatherState {}

final class GetChildrenFatherInitial extends GetChildrenFatherState {}

final class GetChildrenFatherLoading extends GetChildrenFatherState {}

final class GetChildrenFatherSuccess extends GetChildrenFatherState {
  final String message;

  GetChildrenFatherSuccess(this.message);
}

final class GetChildrenFatherError extends GetChildrenFatherState {
  final String error;

  GetChildrenFatherError(this.error);
}
