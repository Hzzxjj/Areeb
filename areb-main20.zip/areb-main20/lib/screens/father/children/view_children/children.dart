import 'package:areb/components/comp.dart';

import 'package:areb/constants/sizes.dart';
import 'package:areb/functions/message.dart';
import 'package:areb/functions/size_screen.dart';
import 'package:areb/functions/snackbar.dart';

import 'package:areb/screens/father/children/view_children/cubit/get_children_father_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class Children extends StatefulWidget {
  const Children({super.key});

  @override
  State<Children> createState() => _ChildrenState();
}

class _ChildrenState extends State<Children> {
  late GetChildrenFatherCubit bloc;
  @override
  void initState() {
    super.initState();
    bloc = GetChildrenFatherCubit.get(context);
    if (bloc.getDataonce == false) {
      bloc.getChildren(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: BlocConsumer<GetChildrenFatherCubit, GetChildrenFatherState>(
        listener: (context, state) {
          state is GetChildrenFatherError
              ? Messagec.showSnackBar(
                  context: context, snackbar: Snackc.errorSnackBar(state.error))
              : null;
        },
        builder: (context, state) {
          return SafeArea(
            child: state is GetChildrenFatherLoading
                ? Compc.loading()
                : state is GetChildrenFatherError
                    ? Compc.noInternet(() {
                        bloc.getChildren(context);
                      })
                    : RefreshIndicator(
                        onRefresh: () async {
                          bloc.getChildren(context);
                        },
                        child: SizedBox(
                          height: sizeScreen.height,
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              //view children
                              SingleChildScrollView(
                                physics: const BouncingScrollPhysics(
                                  parent: AlwaysScrollableScrollPhysics(),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.max,
                                  children: [
                                    //app bar
                                    Compc.appbar(
                                      context,
                                      title: 'أطفالي',
                                      fontsize: Sic.s40,
                                      withBackArrow: false,
                                      width: 50,
                                      withDivider: true,
                                    ),
                                    //account image :
                                    ListView.builder(
                                      itemCount: bloc.children.length,
                                      physics:
                                          const NeverScrollableScrollPhysics(),
                                      scrollDirection: Axis.vertical,
                                      shrinkWrap: true,
                                      itemBuilder: (context, index) {
                                        return Compc.childCard(
                                          onTap: () {
                                            bloc.onTapAddMoneyforChild(
                                                index, context);
                                          },
                                          name: bloc.children[index].name,
                                          money:
                                              '${bloc.children[index].money} ر.س',
                                          image: bloc.children[index].image,
                                        );
                                      },
                                    ),

                                    //spacing :
                                    const SizedBox(
                                      height: 70,
                                    ),
                                  ],
                                ),
                              ),
                              //add child button :
                              Positioned(
                                bottom: 10,
                                left: (sizeScreen.width - 250) / 2,
                                child: Compc.buttonWithIconinAccount(
                                  width: 250,
                                  onTap: () {
                                    bloc.onTapAddChildren(context);
                                  },
                                  icon: Icons.add_circle_outline,
                                  text: 'إضافة الطفل',
                                  point: false,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
          );
        },
      ),
    );
  }
}
