part of 'add_money_father_cubit.dart';

@immutable
sealed class AddMoneyFatherState {}

final class AddMoneyFatherInitial extends AddMoneyFatherState {}

final class SentMoneyLoading extends AddMoneyFatherState {}

final class SentMoneySuccess extends AddMoneyFatherState {
  final String message;
  SentMoneySuccess(this.message);
}

final class SentMoneyError extends AddMoneyFatherState {
  final String error;
  SentMoneyError(this.error);
}
