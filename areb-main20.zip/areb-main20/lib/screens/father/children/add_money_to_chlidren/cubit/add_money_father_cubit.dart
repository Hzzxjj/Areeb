import 'package:areb/functions/message.dart';
import 'package:areb/functions/messaging.dart';
import 'package:areb/functions/run_dialog.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/material.dart';

part 'add_money_father_state.dart';

class AddMoneyFatherCubit extends Cubit<AddMoneyFatherState> {
  final TextEditingController amountPaidController = TextEditingController();

  final TextEditingController noteController = TextEditingController();

  static AddMoneyFatherCubit get(context) => BlocProvider.of(context);
  AddMoneyFatherCubit() : super(AddMoneyFatherInitial());

  void onTapAddMoney(context, int childId) {
    if (amountPaidController.text.isEmpty) {
      Messagec.showSnackBar(
        context: context,
        snackbar: Snackc.errorSnackBar(
          'يرجى إدخال المبلغ المراد إرساله',
        ),
      );
    } else {
      addMoney(context, childId);
    }
  }

  void addMoney(context, int childId) {
    emit(SentMoneyLoading());
    Dioc.sentMoney(
      money: amountPaidController.text,
      note: noteController.text,
      childId: childId,
    ).then((value) {
      if (value.data['message'] == 'successful') {
        amountPaidController.clear();
        noteController.clear();
        RunDialogc.animationDialog(
            child: Dialogc.addMoney(context), context: context);
        emit(SentMoneySuccess(value.data['body']));
      } else {
        emit(SentMoneyError(value.data['body']));
      }
    }).catchError((e) {
      emit(SentMoneyError(e.toString()));
    });
  }
}
