import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';
import 'package:areb/constants/fonts.dart';
import 'package:areb/constants/images.dart';
import 'package:areb/constants/sizes.dart';
import 'package:areb/functions/message.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/screens/father/children/add_money_to_chlidren/cubit/add_money_father_cubit.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:areb/shared/models/child/child.dart';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class AddMoneyTOChildren extends StatefulWidget {
  final Child child;

  const AddMoneyTOChildren({super.key, required this.child});

  @override
  State<AddMoneyTOChildren> createState() => _AddMoneyTOChildrenState();
}

class _AddMoneyTOChildrenState extends State<AddMoneyTOChildren> {
  late AddMoneyFatherCubit bloc;
  @override
  void initState() {
    super.initState();
    bloc = AddMoneyFatherCubit.get(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: BlocConsumer<AddMoneyFatherCubit, AddMoneyFatherState>(
        listener: (context, state) {
          state is SentMoneyError
              ? Messagec.showSnackBar(
                  context: context, snackbar: Snackc.errorSnackBar(state.error))
              : null;
        },
        builder: (context, state) {
          return SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.max,
                children: [
                  //app bar
                  Compc.appbar(
                    context,
                    title: 'إضافة المال',
                    fontsize: Sic.s40,
                    withBackArrow: true,
                    width: 50,
                    withDivider: false,
                  ),
                  //account image :
                  Container(
                    margin: const EdgeInsetsDirectional.only(
                      top: 3,
                      bottom: 20,
                    ),
                    height: 2,
                    color: Colorc.grey,
                    width: double.infinity,
                  ),
                  Text(
                    widget.child.name,
                    style: TextStyle(
                      fontSize: Sic.s36,
                      fontFamily: Fontc.hayahBigTitle,
                      // fontWeight: FontWeight.bold,
                      shadows: [
                        BoxShadow(
                          color: Colorc.darkGrey.withOpacity(0.5),
                          offset: const Offset(0, 2),
                          blurRadius: 1,
                        )
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 40,
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Container(
                        clipBehavior: Clip.antiAlias,
                        width: 150,
                        height: 150,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                        ),
                        child: widget.child.image.isEmpty
                            ? const Padding(
                                padding: EdgeInsets.symmetric(vertical: 5.0),
                                child: Image(image: AssetImage(Imagec.child)),
                              )
                            : Compc.networkImage(
                                imageUrl: Dioc.imageUrl + widget.child.image,
                              ),
                      ),
                      Column(
                        children: [
                          Text(
                            'الرصيد الحالي:',
                            style: TextStyle(
                              fontSize: Sic.s28,
                              fontFamily: Fontc.hayahBigTitle,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Row(
                            children: [
                              Text(
                                '${widget.child.money} ر.س',
                                style: TextStyle(
                                  fontSize: Sic.s20,
                                  fontFamily: Fontc.marheySmallTitle,
                                  fontWeight: FontWeight.w500,
                                ),
                                textAlign: TextAlign.center,
                              ),
                              const Icon(
                                Icons.monetization_on_sharp,
                                color: Colors.amber,
                              )
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 50,
                  ),
                  Compc.formFieldAddMoneyChildren(
                    controller: bloc.amountPaidController,
                    validator: null,
                    keyboardType: TextInputType.number,
                    textInputAction: TextInputAction.next,
                    hintText: 'المبلغ المقدم',
                  ),
                  Compc.formFieldAddMoneyChildren(
                    controller: bloc.noteController,
                    validator: null,
                    keyboardType: TextInputType.text,
                    textInputAction: TextInputAction.done,
                    hintText: 'ملاحظات',
                  ),
                  const SizedBox(
                    height: 40,
                  ),
                  state is SentMoneyLoading
                      ? Compc.loading(color: Colorc.purple)
                      : Compc.buttonWithIconinAccount(
                          onTap: () {
                            bloc.onTapAddMoney(context, widget.child.id);
                          },
                          icon: Icons.add_circle_outline,
                          text: 'إضافة المال',
                          point: false,
                        )
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
