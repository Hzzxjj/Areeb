part of 'view_task_parent_cubit.dart';

@immutable
sealed class ViewTaskParentState {}

final class ViewTaskParentInitial extends ViewTaskParentState {}

final class GetTasksLoading extends ViewTaskParentState {}

final class GetTasksSuccess extends ViewTaskParentState {}

final class GetTasksError extends ViewTaskParentState {
  final String error;
  GetTasksError(this.error);
}

final class CheckOnTasksLoading extends ViewTaskParentState {}

final class CheckOnTasksSuccess extends ViewTaskParentState {
  final String message;
  CheckOnTasksSuccess(this.message);
}

final class CheckOnTasksError extends ViewTaskParentState {
  final String error;
  CheckOnTasksError(this.error);
}
