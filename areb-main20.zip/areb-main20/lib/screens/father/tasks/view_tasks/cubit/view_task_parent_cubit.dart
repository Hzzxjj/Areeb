import 'package:areb/functions/message.dart';
import 'package:areb/functions/messaging.dart';
import 'package:areb/functions/navigations.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/screens/father/children/view_children/cubit/get_children_father_cubit.dart';
import 'package:areb/screens/father/tasks/addTasks/add_task.dart';
import 'package:areb/screens/father/tasks/editTasks/edit_tasks.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:areb/shared/models/task/task.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/material.dart';

part 'view_task_parent_state.dart';

class ViewTaskParentCubit extends Cubit<ViewTaskParentState> {
  ViewTaskParentCubit() : super(ViewTaskParentInitial());
  static ViewTaskParentCubit get(context) => BlocProvider.of(context);
  bool getDataOnce = false;
  List<TaskModel> tasks = [];

  void onTapEditTask(context, index) {
    Navc.push(
        context: context,
        screenToPush: EditTasks(
          task: tasks[index],
        ));
  }

  void getTasks() {
    emit(GetTasksLoading());
    Dioc.getTasks().then((value) {
      if (value.data['message'] == 'successful') {
        getDataOnce = true;
        tasks = List<TaskModel>.from(
            value.data['tasks'].map((e) => TaskModel.fromMap(e)));
        emit(GetTasksSuccess());
      } else {
        emit(GetTasksError('error'));
      }
    }).catchError((e) {
      emit(GetTasksError(e.toString()));
    });
  }

  void onTapAddTask(context, GetChildrenFatherCubit childrenBloc) {
    if (childrenBloc.children.isEmpty) {
      Messagec.showSnackBar(
          context: context,
          snackbar:
              Snackc.warningSnackBar('ليس لديك اي طفل لتضيف المهام لهم !'));
    } else {
      Navc.push(
        context: context,
        screenToPush: AddTasks(
          children: childrenBloc.children,
        ),
      );
    }
  }

  void addCheckOnTask(int index, context) {
    Dialogc.loading(context);
    emit(CheckOnTasksLoading());
    Dioc.checkOnTask(taskId: tasks[index].id).then((value) {
      Navc.pop(context: context);
      if (value.data['message'] == 'successful') {
        emit(CheckOnTasksSuccess(value.data['body']));
        getTasks();
      } else {
        emit(CheckOnTasksError(value.data['body']));
      }
    }).catchError((e) {
      Navc.pop(context: context);

      emit(CheckOnTasksError(e.toString()));
    });
  }
}
