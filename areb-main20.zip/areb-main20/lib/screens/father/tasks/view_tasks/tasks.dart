import 'package:areb/components/comp.dart';

import 'package:areb/constants/sizes.dart';
import 'package:areb/functions/message.dart';
import 'package:areb/functions/size_screen.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/screens/father/children/view_children/cubit/get_children_father_cubit.dart';
import 'package:areb/screens/father/tasks/view_tasks/cubit/view_task_parent_cubit.dart';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class Tasks extends StatefulWidget {
  const Tasks({super.key});

  @override
  State<Tasks> createState() => _TasksState();
}

class _TasksState extends State<Tasks> {
  late ViewTaskParentCubit bloc;
  late GetChildrenFatherCubit childrenBloc;
  @override
  void initState() {
    bloc = BlocProvider.of(context);
    if (bloc.getDataOnce == false) {
      bloc.getTasks();
    }
    childrenBloc = GetChildrenFatherCubit.get(context);
    if (childrenBloc.state is! GetChildrenFatherSuccess) {
      childrenBloc.getChildren(context);
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: SafeArea(
        child: BlocConsumer<ViewTaskParentCubit, ViewTaskParentState>(
          listener: (context, state) {
            state is CheckOnTasksSuccess
                ? Messagec.showSnackBar(
                    context: context,
                    snackbar: Snackc.talkSnackBar(state.message))
                : null;
          },
          builder: (context, state) {
            return state is GetTasksLoading
                ? SizedBox(
                    child: Compc.loading(),
                  )
                : state is GetTasksError
                    ? Compc.noInternet(() {
                        bloc.getTasks();
                      })
                    : RefreshIndicator(
                        onRefresh: () async {
                          bloc.getTasks();
                        },
                        child: SizedBox(
                          height: sizeScreen.height,
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              //view tasks
                              SingleChildScrollView(
                                physics: const BouncingScrollPhysics(
                                  parent: AlwaysScrollableScrollPhysics(),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.max,
                                  children: [
                                    //app bar
                                    Compc.appbar(
                                      context,
                                      title: 'اعطاء مهام',
                                      fontsize: Sic.s40,
                                      withBackArrow: false,
                                      withDivider: true,
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    bloc.tasks.isEmpty
                                        ? SizedBox(
                                            height: sizeScreen.height - 180,
                                            child: Compc.dontHave(
                                                'لا يوجد أي مهام !'),
                                          )
                                        : ListView.separated(
                                            itemCount: bloc.tasks.length,
                                            physics:
                                                const NeverScrollableScrollPhysics(),
                                            scrollDirection: Axis.vertical,
                                            shrinkWrap: true,
                                            padding: const EdgeInsets.symmetric(
                                                vertical: 10),
                                            separatorBuilder:
                                                (context, index) =>
                                                    const SizedBox(
                                              height: 20,
                                            ),
                                            itemBuilder: (context, index) {
                                              return Compc.tasksCard(
                                                tasksTitle:
                                                    'مهمة ل ${bloc.tasks[index].childName}',
                                                tasksName:
                                                    bloc.tasks[index].task,
                                                money: bloc.tasks[index].reward
                                                    .toString(),
                                                onTapRight: () {
                                                  bloc.addCheckOnTask(
                                                      index, context);
                                                },
                                                onTapEdite: () {
                                                  bloc.onTapEditTask(
                                                      context, index);
                                                },
                                              );
                                            },
                                          ),
                                    // const SizedBox(
                                    //   height: 50,
                                    // ),

                                    const SizedBox(
                                      height: 70,
                                    ),
                                  ],
                                ),
                              ),
                              //add task button
                              Positioned(
                                bottom: 10,
                                left: (sizeScreen.width - 250) / 2,
                                child: Compc.buttonWithIconinAccount(
                                  onTap: () {
                                    bloc.onTapAddTask(context, childrenBloc);
                                  },
                                  icon: Icons.add_circle_outline,
                                  text: 'إضافة مهمة',
                                  point: false,
                                  width: 250,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
          },
        ),
      ),
    );
  }
}
