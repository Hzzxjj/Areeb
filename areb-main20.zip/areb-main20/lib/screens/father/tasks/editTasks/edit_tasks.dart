import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';
import 'package:areb/constants/fonts.dart';
import 'package:areb/constants/radius.dart';
import 'package:areb/constants/sizes.dart';
import 'package:areb/functions/message.dart';
import 'package:areb/functions/navigations.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/screens/father/tasks/editTasks/cubit/edit_tasks_cubit.dart';
import 'package:areb/shared/models/task/task.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class EditTasks extends StatefulWidget {
  final TaskModel task;
  const EditTasks({
    super.key,
    required this.task,
  });

  @override
  State<EditTasks> createState() => _EditTasksState();
}

class _EditTasksState extends State<EditTasks> {
  late EditTasksCubit bloc;
  @override
  void initState() {
    super.initState();
    bloc = EditTasksCubit.get(context);
    bloc.init(widget.task);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: BlocConsumer<EditTasksCubit, EditTasksState>(
        listener: (context, state) {
          state is EditTasksError
              ? Messagec.showSnackBar(
                  context: context, snackbar: Snackc.errorSnackBar(state.error))
              : null;
          state is DeleteTasksError
              ? Messagec.showSnackBar(
                  context: context, snackbar: Snackc.errorSnackBar(state.error))
              : null;
          state is DeleteTasksSuccess
              ? {
                  Messagec.showSnackBar(
                      context: context,
                      snackbar: Snackc.talkSnackBar(state.message)),
                  Navc.pop(context: context),
                }
              : null;
        },
        builder: (context, state) {
          return SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.max,
                children: [
                  //app bar
                  Compc.appbar(
                    context,
                    title: 'تعديل مهمة',
                    fontsize: Sic.s40,
                    withBackArrow: true,
                    width: 50,
                    withDivider: true,
                  ),
                  //Spacer
                  const SizedBox(
                    height: 40,
                  ),
                  //Card
                  Container(
                    margin: const EdgeInsetsDirectional.symmetric(
                      horizontal: 40,
                    ),
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colorc.white,
                      borderRadius: BorderRadius.circular(
                        Radc.r10,
                      ),
                      border: Border.all(
                        width: 1.1,
                        color: Colorc.darkGrey.withOpacity(0.3),
                      ),
                      boxShadow: [
                        BoxShadow(
                          blurRadius: 1,
                          offset: const Offset(0, 2),
                          color: Colorc.darkGrey.withOpacity(0.7),
                        )
                      ],
                    ),
                    child:
                        //content

                        Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        //title

                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            //Spaser

                            const SizedBox(
                              width: 10,
                            ),
                            //point
                            Container(
                              height: 5,
                              width: 5,
                              decoration: BoxDecoration(
                                color: Colorc.darkGrey,
                                borderRadius: BorderRadius.circular(
                                  Radc.r02,
                                ),
                              ),
                            ),
                            //Spaser
                            const SizedBox(
                              width: 10,
                            ),
                            //name
                            Text(
                              'مهام ${widget.task.childName}',
                              style: TextStyle(
                                fontFamily: Fontc.hayahBigTitle,
                                color: Colorc.darkGrey,
                                fontSize: 30,
                              ),
                            )
                          ],
                        ),
                        //Spaser
                        const SizedBox(
                          height: 10,
                        ),
                        //line
                        Container(
                          height: 1.8,
                          width: double.infinity,
                          color: Colorc.darkGrey.withOpacity(
                            0.3,
                          ),
                        ),
                        //Spacer
                        const SizedBox(
                          height: 20,
                        ),
                        //tasks name
                        Text(
                          'المهمة : ${widget.task.task}',
                          maxLines: 2,
                          style: const TextStyle(
                            fontFamily: Fontc.hayahBigTitle,
                            color: Colorc.black,
                            fontSize: 20,
                          ),
                        ),
                        //Edit tasks name
                        Compc.formEditTasks(
                          controller: bloc.nameTasks,
                          validator: null,
                          keyboardType: TextInputType.name,
                          textInputAction: TextInputAction.next,
                          hintText: 'ادخل الاسم الجديد',
                        ),
                        //tasks value
                        Text(
                          'الجائزة : ${widget.task.reward} ر.س',
                          maxLines: 2,
                          style: const TextStyle(
                            fontFamily: Fontc.hayahBigTitle,
                            color: Colorc.black,
                            fontSize: 20,
                          ),
                        ),
                        //Edit tasks value
                        Compc.formEditTasks(
                          controller: bloc.rewardTasksController,
                          validator: null,
                          keyboardType: TextInputType.number,
                          textInputAction: TextInputAction.next,
                          hintText: 'تغيير الجائزة',
                        ),
                        //tasks date time
                        const Text(
                          ' تاريخ لانهاء المهمة؟',
                          maxLines: 2,
                          style: TextStyle(
                            fontFamily: Fontc.hayahBigTitle,
                            color: Colorc.black,
                            fontSize: 20,
                          ),
                        ),
                        //add tasks date time
                        Compc.formEditTasks(
                          controller: bloc.dateController,
                          validator: null,
                          readOnly: true,
                          onTap: () {
                            bloc.onTapDateField(context);
                          },
                          keyboardType: TextInputType.datetime,
                          textInputAction: TextInputAction.next,
                          hintText: 'اختياري',
                        ),
                        //Buttons

                        Padding(
                          padding: const EdgeInsetsDirectional.symmetric(
                            horizontal: 25,
                          ),
                          //

                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              //Button close

                              Expanded(
                                flex: 2,
                                child: Compc.buttonEditeTasks(
                                  onTap: () {
                                    bloc.onTapCancle(context);
                                  },
                                  text: 'الغاء',
                                  // width: 80,
                                ),
                              ),
                              //spacing :
                              const SizedBox(
                                width: 8,
                              ),

                              //Button save
                              Expanded(
                                flex: 3,
                                child: state is EditTasksLoading
                                    ? Center(
                                        child: Compc.loading(
                                          color: Colorc.purple,
                                        ),
                                      )
                                    : Compc.buttonEditeTasks(
                                        onTap: () {
                                          bloc.onTapEditButton(
                                              context, widget.task.id);
                                        },
                                        text: 'حفظ التعديلات',
                                        // width: 150,
                                      ),
                              ),
                            ],
                          ),
                        ),
                        //Spacer

                        const SizedBox(
                          height: 25,
                        ),
                        //Button Delete

                        Compc.buttonEditeTasks(
                          onTap: () {
                            bloc.onTapDelete(context, widget.task.id);
                          },
                          text: 'حذف',
                          width: 125,
                          backColor: Colorc.red,
                        ),

                        //Spacer

                        const SizedBox(
                          height: 15,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
