part of 'edit_tasks_cubit.dart';

@immutable
sealed class EditTasksState {}

final class EditTasksInitial extends EditTasksState {}

final class DateSelectedState extends EditTasksState {}

final class DeleteTasksLoading extends EditTasksState {}

final class DeleteTasksSuccess extends EditTasksState {
  final String message;
  DeleteTasksSuccess(this.message);
}

final class DeleteTasksError extends EditTasksState {
  final String error;
  DeleteTasksError(this.error);
}

final class EditTasksLoading extends EditTasksState {}

final class EditTasksSuccess extends EditTasksState {
  final String message;
  EditTasksSuccess(this.message);
}

final class EditTasksError extends EditTasksState {
  final String error;
  EditTasksError(this.error);
}
