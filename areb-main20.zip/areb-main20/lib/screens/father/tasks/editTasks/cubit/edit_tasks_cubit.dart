import 'package:areb/functions/message.dart';
import 'package:areb/functions/messaging.dart';
import 'package:areb/functions/navigations.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/screens/father/tasks/view_tasks/cubit/view_task_parent_cubit.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:areb/shared/models/task/task.dart';
import 'package:calendar_date_picker2/calendar_date_picker2.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

part 'edit_tasks_state.dart';

class EditTasksCubit extends Cubit<EditTasksState> {
  final TextEditingController rewardTasksController = TextEditingController();
  final TextEditingController nameTasks = TextEditingController();
  final TextEditingController dateController = TextEditingController();
  static EditTasksCubit get(context) => BlocProvider.of(context);
  EditTasksCubit() : super(EditTasksInitial());

  init(TaskModel task) {
    nameTasks.text = task.task;
    rewardTasksController.text = task.reward.toString();
    dateController.text = task.date.replaceAll(RegExp(r'-'), '/');
  }

  bool getDataOnce = false;

  void onTapCancle(context) {
    Navc.pop(context: context);
  }

  void onTapDateField(context) {
    showCalendarDatePicker2Dialog(
      context: context,
      config: CalendarDatePicker2WithActionButtonsConfig(
        currentDate: DateTime.now(),
        firstDate: DateTime.now(),
        lastDate: DateTime(DateTime.now().year + 1, 12, 31),
        calendarType: CalendarDatePicker2Type.single,
      ),
      dialogSize: const Size(325, 400),
      value: [
        dateController.text.isEmpty
            ? DateTime.now()
            : DateTime.parse(dateController.text.replaceAll(RegExp(r'/'), '-'))
      ],
      borderRadius: BorderRadius.circular(20),
    ).then(
      (value) => value != null
          ? {
              dateController.text =
                  '${value[0]!.year}/${value[0]!.month}/${value[0]!.day}',
              emit(DateSelectedState()),
            }
          : {
              emit(DateSelectedState()),
            },
    );
  }

  void onTapDelete(context, int id) {
    Dialogc.loading(context);
    emit(DeleteTasksLoading());
    Dioc.deleteTask(id: id).then((value) {
      Navc.pop(context: context);
      if (value.data['message'] == 'successful') {
        emit(DeleteTasksSuccess(value.data['body']));
        ViewTaskParentCubit.get(context).getTasks();
      } else {
        emit(DeleteTasksError(value.data['body']));
      }
    }).catchError((e) {
      Navc.pop(context: context);

      emit(DeleteTasksError(e.toString()));
    });
  }

  void onTapEditButton(context, int idTask) {
    if (nameTasks.text.isEmpty || rewardTasksController.text.isEmpty) {
      Messagec.showSnackBar(
          context: context,
          snackbar: Snackc.errorSnackBar('الرجاء ملئ الحقول لإرسال الطلب'));
    } else {
      emit(EditTasksLoading());
      Dioc.editTasak(
              date: dateController.text,
              reward: rewardTasksController.text,
              title: nameTasks.text,
              id: idTask)
          .then((value) {
        if (value.data['message'] == 'successful') {
          emit(EditTasksSuccess(value.data['body']));
          ViewTaskParentCubit.get(context).getTasks();
          Navc.pop(context: context);
        } else {
          emit(EditTasksError(value.data['body']));
        }
      }).catchError((e) {
        emit(EditTasksError(e.toString()));
      });
    }
  }
}
