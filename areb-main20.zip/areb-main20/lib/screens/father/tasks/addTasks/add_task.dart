import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';

import 'package:areb/constants/sizes.dart';
import 'package:areb/functions/message.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/screens/father/tasks/addTasks/cubit/add_tasks_cubit.dart';
import 'package:areb/shared/models/child/child.dart';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class AddTasks extends StatefulWidget {
  final List<Child> children;
  const AddTasks({super.key, required this.children});

  @override
  State<AddTasks> createState() => _AddTasksState();
}

class _AddTasksState extends State<AddTasks> {
  late AddTasksCubit bloc;
  @override
  void initState() {
    super.initState();
    bloc = AddTasksCubit.get(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: BlocConsumer<AddTasksCubit, AddTasksState>(
        listener: (context, state) {
          state is SentTasksError
              ? Messagec.showSnackBar(
                  context: context, snackbar: Snackc.errorSnackBar(state.error))
              : null;

          state is SentTasksSuccess
              ? Messagec.showSnackBar(
                  context: context,
                  snackbar: Snackc.talkSnackBar(state.message))
              : null;
        },
        builder: (context, state) {
          return SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.max,
                children: [
                  //app bar
                  Compc.appbar(
                    context,
                    title: 'إضافة مهمة',
                    fontsize: Sic.s40,
                    withBackArrow: true,
                    width: 50,
                    withDivider: false,
                  ),
                  const SizedBox(
                    height: 40,
                  ),

                  Compc.formFieldAddMoneyChildren(
                    controller: bloc.titleTasksController,
                    validator: null,
                    keyboardType: TextInputType.name,
                    textInputAction: TextInputAction.next,
                    hintText: 'عنوان المهمة',
                  ),
                  Compc.formFieldAddMoneyChildren(
                    controller: bloc.rewardController,
                    validator: null,
                    keyboardType: TextInputType.number,
                    textInputAction: TextInputAction.next,
                    hintText: 'مبلغ الجائزة',
                  ),
                  Compc.formFieldAddMoneyChildren(
                    readOnly: true,
                    onTap: () {
                      bloc.onTapDateField(context);
                    },
                    iconButton: IconButton(
                      onPressed: () {
                        bloc.onTapclearDateField(context);
                      },
                      icon: Icon(
                        Icons.close,
                        color: Colorc.red,
                        size: bloc.dateController.text.isEmpty ? 0 : Sic.s24,
                      ),
                    ),
                    controller: bloc.dateController,
                    validator: null,
                    keyboardType: TextInputType.text,
                    textInputAction: TextInputAction.done,
                    hintText: 'تاريخ الإنتهاء (اختياري)',
                  ),
                  BlocBuilder<AddTasksCubit, AddTasksState>(
                    builder: (context, state) {
                      return Compc.dropdownButton(
                          childSelected: bloc.childSelected,
                          children: widget.children,
                          onChanged: (value) {
                            bloc.onTapSelectDropDown(value);
                          });
                    },
                  ),
                  const SizedBox(
                    height: 200,
                  ),
                  state is SentTasksLoading
                      ? Compc.loading(color: Colorc.purple)
                      : Compc.buttonWithIconBlacktext(
                          onTap: () {
                            bloc.onTapSentTask(context);
                          },
                          icon: Icons.add_circle_outline,
                          text: 'تسجيل المهمة',
                        )
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
