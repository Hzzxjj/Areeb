part of 'add_tasks_cubit.dart';

@immutable
sealed class AddTasksState {}

final class AddTasksInitial extends AddTasksState {}

final class ChangeCHildSelected extends AddTasksState {}

final class DateSelectedState extends AddTasksState {}

final class SentTasksLoading extends AddTasksState {}

final class SentTasksSuccess extends AddTasksState {
  final String message;
  SentTasksSuccess(this.message);
}

final class SentTasksError extends AddTasksState {
  final String error;
  SentTasksError(this.error);
}
