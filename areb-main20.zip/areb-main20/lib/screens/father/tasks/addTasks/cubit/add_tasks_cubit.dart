import 'package:areb/functions/message.dart';
import 'package:areb/functions/navigations.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/screens/father/tasks/view_tasks/cubit/view_task_parent_cubit.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:calendar_date_picker2/calendar_date_picker2.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
part 'add_tasks_state.dart';

class AddTasksCubit extends Cubit<AddTasksState> {
  final TextEditingController titleTasksController = TextEditingController();
  final TextEditingController rewardController = TextEditingController();
  final TextEditingController dateController = TextEditingController();

  int? childSelected;

  static AddTasksCubit get(context) => BlocProvider.of(context);

  AddTasksCubit() : super(AddTasksInitial());

  void onTapSelectDropDown(idSelected) {
    childSelected = idSelected;
    emit(ChangeCHildSelected());
  }

  void onTapDateField(context) {
    showCalendarDatePicker2Dialog(
      context: context,
      config: CalendarDatePicker2WithActionButtonsConfig(
        currentDate: DateTime.now(),
        firstDate: DateTime.now(),
        lastDate: DateTime(DateTime.now().year + 1, 12, 31),
        calendarType: CalendarDatePicker2Type.single,
      ),
      dialogSize: const Size(325, 400),
      value: [DateTime.now()],
      borderRadius: BorderRadius.circular(20),
    ).then(
      (value) => value != null
          ? {
              dateController.text =
                  '${value[0]!.year}/${value[0]!.month}/${value[0]!.day}',
              emit(DateSelectedState()),
            }
          : {
              emit(DateSelectedState()),
            },
    );
  }

  void onTapclearDateField(context) {
    dateController.clear();
    emit(DateSelectedState());
  }

  void onTapSentTask(context) {
    if (childSelected == null ||
        titleTasksController.text.isEmpty ||
        rewardController.text.isEmpty) {
      Messagec.showSnackBar(
          context: context,
          snackbar: Snackc.errorSnackBar('الرجاء ملئ الحقول لإرسال الطلب'));
    } else {
      emit(SentTasksLoading());
      Dioc.sentTasak(
              date: dateController.text,
              reward: rewardController.text,
              title: titleTasksController.text,
              userId: childSelected!)
          .then((value) {
        if (value.data['message'] == 'successful') {
          emit(SentTasksSuccess(value.data['body']));
          ViewTaskParentCubit.get(context).getTasks();
          Navc.pop(context: context);

          clearData();
        } else {
          emit(SentTasksError(value.data['body']));
        }
      }).catchError((e) {
        emit(SentTasksError(e.toString()));
      });
    }
  }

  void clearData() {
    dateController.clear();
    rewardController.clear();
    titleTasksController.clear();
    childSelected = null;
  }
}
