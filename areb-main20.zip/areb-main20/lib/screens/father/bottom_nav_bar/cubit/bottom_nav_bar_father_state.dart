part of 'bottom_nav_bar_father_cubit.dart';

@immutable
sealed class BottomNavBarFatherState {}

final class BottomNavBarFatherInitial extends BottomNavBarFatherState {}

final class ChangeScreen extends BottomNavBarFatherState {}

final class NoInternet extends BottomNavBarFatherState {}

final class Internet extends BottomNavBarFatherState {}
