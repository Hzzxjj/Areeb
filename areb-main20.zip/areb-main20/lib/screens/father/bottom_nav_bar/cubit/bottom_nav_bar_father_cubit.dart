import 'package:areb/screens/father/children/view_children/children.dart';
import 'package:areb/screens/father/personal_account_father/personal_account_father.dart';
import 'package:areb/screens/father/tasks/view_tasks/tasks.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../home/home.dart';
part 'bottom_nav_bar_father_state.dart';

class BottomNavBarFatherCubit extends Cubit<BottomNavBarFatherState> {
  static BottomNavBarFatherCubit get(context) => BlocProvider.of(context);
  final PageController? pageController = PageController(initialPage: 3);

  List<Widget> pages = const [
    PersonalAccountFather(),
    Children(),
    Tasks(),
    FatherGools(),
  ];

  int bottomNavIndex = 3;

  BottomNavBarFatherCubit() : super(BottomNavBarFatherInitial());

  void onPageChange(int v) {
    bottomNavIndex = v;
    emit(
      ChangeScreen(),
    );
  }

  void onTapBottomNavBarIcon(int index) {
    pageController!.animateToPage(
      index,
      duration: const Duration(milliseconds: 400),
      curve: Curves.fastOutSlowIn,
    );
  }
}
