import 'package:areb/constants/colors.dart';
import 'package:areb/functions/firebase.dart';
import 'package:areb/screens/father/bottom_nav_bar/bottom_nav_bar_father.dart';
import 'package:areb/screens/father/bottom_nav_bar/cubit/bottom_nav_bar_father_cubit.dart';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class BottomNavBarFatherPage extends StatefulWidget {
  final int indexBottomNav;
  const BottomNavBarFatherPage({super.key, this.indexBottomNav = 3});

  @override
  State<BottomNavBarFatherPage> createState() => _BottomNavBarFatherPageState();
}

class _BottomNavBarFatherPageState extends State<BottomNavBarFatherPage> {
  late BottomNavBarFatherCubit bloc;

  @override
  void initState() {
    super.initState();
    bloc = BottomNavBarFatherCubit.get(context);
    configureFCMListeners(context);

    bloc.bottomNavIndex = widget.indexBottomNav;
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<BottomNavBarFatherCubit, BottomNavBarFatherState>(
      builder: (context, state) {
        return SafeArea(
          top: false,
          child: Scaffold(
            bottomNavigationBar: const BottomNavBarFather(),
            backgroundColor: Colorc.lightCyan,
            ////////////////////////////////////   body PageView builder ////////////////////////////////////
            body: SizedBox(
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              child: PageView(
                onPageChanged: (index) {
                  bloc.onPageChange(index);
                },
                controller: bloc.pageController,
                physics: const BouncingScrollPhysics(),
                children: List.generate(
                  bloc.pages.length,
                  (index) => Padding(
                    padding: const EdgeInsets.only(top: 0),
                    child: bloc.pages[index],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
