import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';
import 'package:areb/constants/radius.dart';
import 'package:areb/constants/shadow.dart';
import 'package:areb/screens/father/bottom_nav_bar/cubit/bottom_nav_bar_father_cubit.dart';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class BottomNavBarFather extends StatelessWidget {
  const BottomNavBarFather({super.key});

  @override
  Widget build(BuildContext context) {
    BottomNavBarFatherCubit bloc = BottomNavBarFatherCubit.get(context);
    return BlocBuilder<BottomNavBarFatherCubit, BottomNavBarFatherState>(
      builder: (context, state) {
        return Container(
          margin: const EdgeInsetsDirectional.fromSTEB(25, 5, 25, 16),
          height: 60,
          decoration: BoxDecoration(
            color: Colorc.cyan,
            borderRadius: BorderRadius.circular(Radc.r24),
            boxShadow: [
              Shadc.button,
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Account Icon:
              Compc.bottomNavBarIcon(
                icon: Icons.account_circle_rounded,
                onTap: () {
                  bloc.onTapBottomNavBarIcon(0);
                  // Add your onTap logic here
                },
                isSelected: bloc.bottomNavIndex == 0,
              ),

              // Child Icon:
              Compc.bottomNavBarIcon(
                icon: Icons.child_care,
                onTap: () {
                  bloc.onTapBottomNavBarIcon(1);
                  // Add your onTap logic here
                },
                isSelected: bloc.bottomNavIndex == 1,
              ),

              // Task Icon:
              Compc.bottomNavBarIcon(
                icon: Icons.list,
                onTap: () {
                  bloc.onTapBottomNavBarIcon(2);
                  // Add your onTap logic here
                },
                isSelected: bloc.bottomNavIndex == 2,
              ),

              // Golf Course Icon:
              Compc.bottomNavBarIcon(
                icon: Icons.golf_course_sharp,
                onTap: () {
                  bloc.onTapBottomNavBarIcon(3);
                  // Add your onTap logic here
                },
                isSelected: bloc.bottomNavIndex == 3,
              ),
            ],
          ),
        );
      },
    );
  }
}
