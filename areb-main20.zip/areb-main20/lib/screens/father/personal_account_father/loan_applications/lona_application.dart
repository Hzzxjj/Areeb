import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';
import 'package:areb/constants/images.dart';
import 'package:areb/constants/sizes.dart';
import 'package:areb/functions/message.dart';
import 'package:areb/functions/size_screen.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/screens/father/personal_account_father/loan_applications/cubit/loan_father_cubit.dart';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class LoanApplications extends StatefulWidget {
  const LoanApplications({super.key});

  @override
  State<LoanApplications> createState() => _LoanApplicationsState();
}

class _LoanApplicationsState extends State<LoanApplications> {
  late LoanFatherCubit bloc;
  @override
  void initState() {
    super.initState();
    bloc = BlocProvider.of(context);
    if (bloc.getDataOnce == false) {
      bloc.getLoans(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: BlocConsumer<LoanFatherCubit, LoanFatherState>(
        listener: (context, state) {
          state is ResponceLoansFatherError
              ? Messagec.showSnackBar(
                  context: context, snackbar: Snackc.errorSnackBar(state.error))
              : null;
          state is ResponceLoansFatherSuccess
              ? Messagec.showSnackBar(
                  context: context,
                  snackbar: Snackc.warningSnackBar(state.message))
              : null;
        },
        builder: (context, state) {
          return state is GetLoansFatherLoading
              ? Compc.loading()
              : state is GetLoansFatherError
                  ? Compc.noInternet(() {
                      bloc.getLoans(context);
                    })
                  : SafeArea(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          //app bar
                          Compc.appbar(
                            context,
                            title: 'المساعدات المالية',
                            fontsize: Sic.s40,
                            withBackArrow: true,
                            width: 50,
                            withDivider: false,
                          ),
                          //account image :
                          Container(
                            margin: const EdgeInsetsDirectional.only(
                              top: 3,
                              bottom: 20,
                            ),
                            height: 2,
                            color: Colorc.grey,
                            width: double.infinity,
                          ),
                          bloc.loans.isEmpty
                              ? RefreshIndicator(
                                  onRefresh: () async {
                                    bloc.getLoans(context);
                                  },
                                  child: SingleChildScrollView(
                                    physics: const BouncingScrollPhysics(
                                      parent: AlwaysScrollableScrollPhysics(),
                                    ),
                                    child: SizedBox(
                                      height: sizeScreen.height - 200,
                                      child: Center(
                                        child: Compc.dontHave(
                                          'ليس لديك أي طلبات مساعدة مالية',
                                          Imagec.child,
                                        ),
                                      ),
                                    ),
                                  ),
                                )
                              : Expanded(
                                  child: RefreshIndicator(
                                    onRefresh: () async {
                                      bloc.getLoans(context);
                                    },
                                    child: ListView.builder(
                                      itemCount: bloc.loans.length,
                                      physics: const BouncingScrollPhysics(
                                        parent: AlwaysScrollableScrollPhysics(),
                                      ),
                                      scrollDirection: Axis.vertical,
                                      shrinkWrap: true,
                                      itemBuilder: (context, index) {
                                        return Compc.loanCard(
                                          onTapYes: () {
                                            bloc.onTapAcceptLona(
                                                index, context);
                                          },
                                          onTapNo: () {
                                            bloc.onTapRejectLona(
                                                index, context);
                                          },
                                          name: bloc.loans[index].child.name,
                                          currentMoney:
                                              '${bloc.loans[index].child.money} ر.س',
                                          moneyRequired:
                                              '${bloc.loans[index].lona} ر.س',
                                          reasonForRequest:
                                              bloc.loans[index].title,
                                          image: bloc.loans[index].child.image,
                                        );
                                      },
                                    ),
                                  ),
                                ),
                        ],
                      ),
                    );
        },
      ),
    );
  }
}
