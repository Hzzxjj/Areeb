part of 'loan_father_cubit.dart';

@immutable
sealed class LoanFatherState {}

final class LoanFatherInitial extends LoanFatherState {}

final class GetLoansFatherLoading extends LoanFatherState {}

final class GetLoansFatherSuccess extends LoanFatherState {}

final class GetLoansFatherError extends LoanFatherState {
  final String error;
  GetLoansFatherError(this.error);
}

final class ResponceLoansFatherLoading extends LoanFatherState {}

final class ResponceLoansFatherSuccess extends LoanFatherState {
  final String message;
  ResponceLoansFatherSuccess(this.message);
}

final class ResponceLoansFatherError extends LoanFatherState {
  final String error;
  ResponceLoansFatherError(this.error);
}
