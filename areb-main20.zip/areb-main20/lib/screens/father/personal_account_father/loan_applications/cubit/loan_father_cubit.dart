import 'package:areb/functions/messaging.dart';
import 'package:areb/functions/navigations.dart';
import 'package:areb/screens/father/personal_account_father/cubit/father_account_cubit.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:areb/shared/models/loan/loan.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/material.dart';

part 'loan_father_state.dart';

class LoanFatherCubit extends Cubit<LoanFatherState> {
  LoanFatherCubit() : super(LoanFatherInitial());
  static LoanFatherCubit get(context) => BlocProvider.of(context);

  List<LoanWithChild> loans = [];
  bool getDataOnce = false;

  void getLoans(context) async {
    emit(GetLoansFatherLoading());

    await Dioc.getLoans().then(
      (value) {
        if (value.data['message'] == 'successful') {
          loans = List.from(
              value.data['loans'].map((x) => LoanWithChild.fromMap(x)));
          emit(GetLoansFatherSuccess());
        } else {
          emit(GetLoansFatherError(value.data['body']));
        }
      },
    ).catchError((e) {
      emit(GetLoansFatherError(e.toString()));
    });
    FatherAccountCubit.get(context).getUserData(context);
  }

  void onTapRejectLona(int index, context) {
    emit(ResponceLoansFatherLoading());
    showDialogLoading(context);

    Dioc.responceOnLoan(loanId: loans[index].id, status: 'refused').then(
      (value) {
        Navc.pop(context: context);

        if (value.data['message'] == 'successful') {
          getLoans(context);
          emit(ResponceLoansFatherSuccess(value.data['body']));
        } else {
          emit(ResponceLoansFatherError(value.data['body']));
        }
      },
    ).catchError((e) {
      Navc.pop(context: context);

      emit(ResponceLoansFatherError(e.toString()));
    });
  }

  void onTapAcceptLona(int index, context) {
    emit(ResponceLoansFatherLoading());
    showDialogLoading(context);

    Dioc.responceOnLoan(loanId: loans[index].id, status: 'accepted').then(
      (value) {
        Navc.pop(context: context);

        if (value.data['message'] == 'successful') {
          getLoans(context);
          emit(ResponceLoansFatherSuccess(value.data['body']));
        } else {
          emit(ResponceLoansFatherError(value.data['body']));
        }
      },
    ).catchError((e) {
      Navc.pop(context: context);

      emit(ResponceLoansFatherError(e.toString()));
    });
  }

  void showDialogLoading(context) {
    Dialogc.loading(context);
  }
}
