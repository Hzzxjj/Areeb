import 'package:areb/functions/message.dart';
import 'package:areb/functions/navigations.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/screens/father/personal_account_father/cubit/father_account_cubit.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:areb/shared/models/user/user.dart';
import 'package:calendar_date_picker2/calendar_date_picker2.dart';
import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

part 'edit_acconunt_state.dart';

class EditAcconuntCubit extends Cubit<EditAcconuntState> {
  static EditAcconuntCubit get(context) => BlocProvider.of(context);

  EditAcconuntCubit() : super(EditAcconuntInitial());

  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController dateController = TextEditingController();
  //ontap date field :
  void onTapDateField(context) {
    showCalendarDatePicker2Dialog(
      context: context,
      config: CalendarDatePicker2WithActionButtonsConfig(
        currentDate: DateTime(2000, 1, 1),
        lastDate: DateTime(2018, 12, 31),
        calendarType: CalendarDatePicker2Type.single,
      ),
      dialogSize: const Size(325, 400),
      value: [DateTime(1970, 1, 1)],
      borderRadius: BorderRadius.circular(20),
    ).then(
      (value) => value != null
          ? dateController.text =
              '${value[0]!.year}/${value[0]!.month}/${value[0]!.day}'
          : {},
    );
  }

  //sign up :
  void edit(context) {
    bool isvaildEmail = false;
    isvaildEmail = EmailValidator.validate(emailController.text);
    if (nameController.text.length > 2 &&
        isvaildEmail == true &&
        passwordController.text.length > 6 &&
        dateController.text.isNotEmpty) {
      emit(EditAcconuntLoading());
      Dioc.editUsers(
        name: nameController.text,
        password: passwordController.text,
        email: emailController.text,
        date: dateController.text,
      ).then((value) {
        if (value.data['message'] == 'successful') {
          FatherAccountCubit.get(context).user =
              User.fromMap(value.data['user']);

          FatherAccountCubit.get(context)
              .emit(GetUserAccountDetailsFatherSuccess());

          Navc.pop(context: context);
          emit(EditAcconuntSuccess(value.data['body']));
        } else {
          emit(EditAcconuntError(value.data['body']));
        }
      }).catchError((e) {
        //print error

        emit(EditAcconuntError(e.toString()));
      });
    } else {
      Messagec.showSnackBar(
        context: context,
        snackbar: Snackc.errorSnackBar(
          'يجب أن يكون الإسم فوق الحرفين وكلمة المرور فوق 6 أحرف وتعبئة جميع الحقول',
        ),
      );
    }
  }

  void init(String email, String name, String password, String date) {
    DateTime dated = DateTime.parse(date);
    nameController.text = name;
    emailController.text = email;
    passwordController.text = password;
    dateController.text = '${dated.year}/${dated.month}/${dated.day}';
  }
}
