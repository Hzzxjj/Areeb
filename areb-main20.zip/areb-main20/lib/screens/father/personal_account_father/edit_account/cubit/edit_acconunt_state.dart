part of 'edit_acconunt_cubit.dart';

@immutable
sealed class EditAcconuntState {}

final class EditAcconuntInitial extends EditAcconuntState {}

final class EditAcconuntSuccess extends EditAcconuntState {
  final String message;

  EditAcconuntSuccess(this.message);
}

final class EditAcconuntLoading extends EditAcconuntState {}

final class EditAcconuntError extends EditAcconuntState {
  final String error;

  EditAcconuntError(this.error);
}
