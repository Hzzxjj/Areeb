import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';
import 'package:areb/constants/fonts.dart';
import 'package:areb/constants/sizes.dart';
import 'package:areb/functions/message.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/screens/father/personal_account_father/edit_account/cubit/edit_acconunt_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class EditAccount extends StatefulWidget {
  final String name;
  final String email;
  final String password;
  final String date;
  const EditAccount(
      {super.key,
      required this.name,
      required this.email,
      required this.date,
      required this.password});

  @override
  State<EditAccount> createState() => _EditAccountState();
}

class _EditAccountState extends State<EditAccount> {
  late EditAcconuntCubit bloc;

  @override
  void initState() {
    super.initState();
    bloc = EditAcconuntCubit.get(context);
    bloc.init(
      widget.email,
      widget.name,
      widget.password,
      widget.date,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: BlocConsumer<EditAcconuntCubit, EditAcconuntState>(
        listener: (context, state) {
          state is EditAcconuntError
              ? Messagec.showSnackBar(
                  context: context, snackbar: Snackc.errorSnackBar(state.error))
              : null;
          state is EditAcconuntSuccess
              ? Messagec.showSnackBar(
                  context: context,
                  snackbar: Snackc.talkSnackBar(state.message))
              : null;
        },
        builder: (context, state) {
          return SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                children: [
                  //app bar and text areb and image :
                  Compc.appbar(
                    context,
                    title: 'أريب',
                    withBackArrow: true,
                    withDivider: false,
                  ),
                  //field and button :
                  ConstrainedBox(
                    constraints: BoxConstraints.tight(
                      Size(
                        MediaQuery.sizeOf(context).width - 40,
                        (MediaQuery.sizeOf(context).height) - 170,
                      ),
                    ),
                    child: Column(
                      children: [
                        //signup text :
                        Align(
                          alignment: AlignmentDirectional.centerStart,
                          child: Text(
                            'تعديل',
                            style: TextStyle(
                              color: Colorc.green,
                              fontSize: Sic.s28,
                              fontFamily: Fontc.hayahBigTitle,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                        //spacing :
                        const SizedBox(
                          height: 15,
                        ),
                        //fields :
                        Expanded(
                          child: Column(
                            children: [
                              // name text field :
                              Compc.formField(
                                controller: bloc.nameController,
                                validator: null,
                                keyboardType: TextInputType.text,
                                textInputAction: TextInputAction.next,
                                hintText: 'الإسم',
                              ),
                              //spacing :
                              const SizedBox(
                                height: 15,
                              ),
                              //email
                              Compc.formField(
                                controller: bloc.emailController,
                                validator: null,
                                keyboardType: TextInputType.emailAddress,
                                textInputAction: TextInputAction.next,
                                hintText: 'البريد الإلكتروني',
                              ),
                              //spacing :
                              const SizedBox(
                                height: 15,
                              ),
                              //password :
                              Compc.formField(
                                controller: bloc.passwordController,
                                validator: null,
                                keyboardType: TextInputType.text,
                                textInputAction: TextInputAction.next,
                                hintText: 'كلمة المرور',
                              ),
                              //spacing :
                              const SizedBox(
                                height: 15,
                              ),
                              //date:
                              Compc.formField(
                                readOnly: true,
                                onTap: () {
                                  bloc.onTapDateField(context);
                                },
                                controller: bloc.dateController,
                                validator: null,
                                keyboardType: TextInputType.text,
                                textInputAction: TextInputAction.done,
                                hintText: 'تاريخ الميلاد',
                              ),
                              //spacing :
                              const Spacer(),

                              //button:
                              BlocBuilder<EditAcconuntCubit, EditAcconuntState>(
                                builder: (context, state) {
                                  if (state is EditAcconuntLoading) {
                                    return Compc.loading();
                                  } else {
                                    return Compc.buttonAuth(
                                      text: 'تعديل',
                                      onTap: () {
                                        bloc.edit(context);
                                      },
                                    );
                                  }
                                },
                              ),
                              //spacing :
                              const SizedBox(
                                height: 80,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
