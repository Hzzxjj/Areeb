import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';
import 'package:areb/constants/fonts.dart';
import 'package:areb/constants/sizes.dart';
import 'package:areb/functions/size_screen.dart';
import 'package:areb/screens/father/personal_account_father/cubit/father_account_cubit.dart';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class PersonalAccountFather extends StatefulWidget {
  const PersonalAccountFather({super.key});

  @override
  State<PersonalAccountFather> createState() => _PersonalAccountFatherState();
}

class _PersonalAccountFatherState extends State<PersonalAccountFather> {
  late FatherAccountCubit bloc;
  @override
  void initState() {
    super.initState();
    bloc = FatherAccountCubit.get(context);

    if (bloc.getDataonce == false) {
      bloc.getUserData(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // bottomNavigationBar: BottomNavBarFather(),
      extendBody: true,
      body: SafeArea(
        child: BlocConsumer<FatherAccountCubit, FatherAccountState>(
          listener: (context, state) {},
          builder: (context, state) {
            return state is GetUserAccountDetailsFatherLoading
                ? SizedBox(
                    child: Compc.loading(),
                  )
                : state is GetUserAccountDetailsFatherError
                    ? Compc.noInternet(() {
                        bloc.getUserData(context);
                      })
                    : RefreshIndicator(
                        onRefresh: () async {
                          bloc.getUserData(context);
                        },
                        child: SingleChildScrollView(
                          physics: const BouncingScrollPhysics(
                            parent: AlwaysScrollableScrollPhysics(),
                          ),
                          child: SizedBox(
                            height: sizeScreen.height - 100,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.start,
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                //app bar
                                Compc.appbar(
                                  context,
                                  title: 'الحساب الشخصي',
                                  fontsize: Sic.s40,
                                  withBackArrow: false,
                                  withDivider: true,
                                ),

                                Expanded(
                                  child: Align(
                                    alignment: AlignmentDirectional.topCenter,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceAround,
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Column(
                                              children: [
                                                //account image :
                                                Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            100),
                                                    color: Colorc.lightCyan,
                                                  ),
                                                  height: 150,
                                                  width: 150,
                                                  child: const Icon(
                                                    Icons
                                                        .account_circle_rounded,
                                                    color: Colorc.black,
                                                    size: 150,
                                                  ),
                                                ),
                                                //Edit image :
                                              ],
                                            ),

                                            //account Name :
                                            Text(
                                              bloc.user.name,
                                              style: TextStyle(
                                                fontSize: Sic.s36,
                                                fontFamily: Fontc.hayahBigTitle,
                                                // fontWeight: FontWeight.bold,
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                            //Spacer :
                                            const SizedBox(
                                              height: 5,
                                            ),
                                            //account :
                                            Text(
                                              bloc.user.email,
                                              style: TextStyle(
                                                fontSize: Sic.s24,
                                                fontFamily: Fontc.hayahBigTitle,
                                                color: Colorc.darkGrey,
                                                // fontWeight: FontWeight.bold,
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                            //Spacer :
                                            const SizedBox(
                                              height: 15,
                                            ),
                                            //edit data button :
                                            Compc.buttonAddMoney(
                                              onTap: () {
                                                bloc.onTapEditData(context);
                                              },
                                              text: 'تعديل بيانات الحساب',
                                            ),
                                            //Spacer :
                                            const SizedBox(
                                              height: 20,
                                            ),
                                            //sign out button :
                                            Compc.buttonAddMoney(
                                              backColor: Colorc.red,
                                              onTap: () {
                                                bloc.onTapLogout(context);
                                              },
                                              text: 'تسجيل الخروج',
                                            ),
                                          ],
                                        ),
                                        //button :
                                        Compc.buttonWithIconinAccount(
                                          point: bloc.isThereLoans,
                                          text: 'طلبات المساعدة المالية',
                                          onTap: () {
                                            // Dioc.postImageToCurrency(context)
                                            //     .then((value) {
                                            //   print(value.data);
                                            // }).catchError((e) {
                                            //   print(e);
                                            // });
                                            bloc.onTapLoanRequist(context);
                                          },
                                          icon:
                                              Icons.notifications_none_outlined,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
          },
        ),
      ),
    );
  }
}
