import 'package:areb/functions/firebase.dart';
import 'package:areb/functions/navigations.dart';
import 'package:areb/screens/father/personal_account_father/edit_account/edit_account.dart';
import 'package:areb/screens/father/personal_account_father/loan_applications/lona_application.dart';
import 'package:areb/screens/splash/splash.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:areb/shared/models/user/user.dart';
import 'package:areb/shared/shared_preferences/shared_p.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/material.dart';

part 'father_account_state.dart';

class FatherAccountCubit extends Cubit<FatherAccountState> {
  static FatherAccountCubit get(context) => BlocProvider.of(context);
  late User user;
  bool getDataonce = false;
  bool isThereLoans = false;
  FatherAccountCubit() : super(FatherAccountInitial());

  void getUserData(context) {
    emit(GetUserAccountDetailsFatherLoading());
    Dioc.getUsersOnly().then((value) {
      user = User.fromMap(value.data['user']);

      isThereLoans = value.data['exist_loans'] == 1 ? true : false;
      getDataonce = true;
      emit(GetUserAccountDetailsFatherSuccess());
    }).catchError((e) {
      emit(GetUserAccountDetailsFatherError(e));
    });
  }

  void onTapLoanRequist(context) {
    Navc.push(
      context: context,
      screenToPush: const LoanApplications(),
    );
  }

  void onTapEditData(context) {
    Navc.push(
      context: context,
      screenToPush: EditAccount(
        name: user.name,
        email: user.email,
        password: '***************',
        date: user.date,
      ),
    );
  }

  void onTapLogout(context) async {
    await signOutSubsicibtion(
        Sharedc.getString('id'), Sharedc.getString('role'));

    Sharedc.resetShared();
    Navc.pushReplacment(context: context, screenToPush: const Splash());
  }
}
