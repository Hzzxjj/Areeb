part of 'father_account_cubit.dart';

@immutable
sealed class FatherAccountState {}

final class FatherAccountInitial extends FatherAccountState {}

final class GetUserAccountDetailsFatherLoading extends FatherAccountState {}

final class GetUserAccountDetailsFatherError extends FatherAccountState {
  final String error;
  GetUserAccountDetailsFatherError(this.error);
}

final class GetUserAccountDetailsFatherSuccess extends FatherAccountState {}
