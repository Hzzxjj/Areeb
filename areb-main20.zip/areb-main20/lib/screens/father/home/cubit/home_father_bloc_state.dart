part of 'home_father_bloc_cubit.dart';

@immutable
sealed class HomeFatherBlocState {}

final class HomeFatherBlocInitial extends HomeFatherBlocState {}

final class GetGoalsFatherSuccess extends HomeFatherBlocState {}

final class GetGoalsFatherLoading extends HomeFatherBlocState {}

final class GetGoalsFatherError extends HomeFatherBlocState {
  final String error;
  GetGoalsFatherError(this.error);
}
