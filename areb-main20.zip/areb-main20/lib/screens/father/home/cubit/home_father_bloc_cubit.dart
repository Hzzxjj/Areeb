import 'package:areb/screens/father/bottom_nav_bar/cubit/bottom_nav_bar_father_cubit.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:areb/shared/models/goals/goals.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
part 'home_father_bloc_state.dart';

class HomeFatherBlocCubit extends Cubit<HomeFatherBlocState> {
  static HomeFatherBlocCubit get(context) => BlocProvider.of(context);
  bool getDataOnce = false;
  List<Goals> fatherGoals = [];

  HomeFatherBlocCubit() : super(HomeFatherBlocInitial());

  void getGoals() {
    emit(GetGoalsFatherLoading());
    Dioc.getGoals().then((value) {
      if (value.data['message'] == 'successful') {
        fatherGoals =
            List.from(value.data['goals'].map((e) => Goals.fromMap(e)));

        getDataOnce = true;
        emit(GetGoalsFatherSuccess());
      } else {
        emit(GetGoalsFatherError('error'));
      }
    }).catchError((e) {
      emit(GetGoalsFatherError(e.toString()));
    });
  }

  void onTapGiveHelp(context) {
    BottomNavBarFatherCubit.get(context).onTapBottomNavBarIcon(1);
  }
}
