import 'package:areb/components/comp.dart';
import 'package:areb/functions/size_screen.dart';
import 'package:areb/screens/father/home/cubit/home_father_bloc_cubit.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class FatherGools extends StatefulWidget {
  const FatherGools({super.key});

  @override
  State<FatherGools> createState() => _FatherGoolsState();
}

class _FatherGoolsState extends State<FatherGools> {
  late HomeFatherBlocCubit bloc;

  @override
  void initState() {
    super.initState();
    bloc = HomeFatherBlocCubit.get(context);

    if (bloc.getDataOnce == false) {
      bloc.getGoals();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // bottomNavigationBar: BottomNavBarFather(),
      extendBody: true,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () async {
            bloc.getGoals();
          },
          child: SizedBox(
            height: sizeScreen.height,
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(
                  parent: AlwaysScrollableScrollPhysics()),
              child: Column(
                children: [
                  //app bar
                  Compc.appbar(
                    context,
                    title: 'تقدم الأهداف',
                    fontsize: 65,
                    withBackArrow: false,
                    withDivider: true,
                  ),

                  BlocBuilder<HomeFatherBlocCubit, HomeFatherBlocState>(
                    builder: (context, state) {
                      if (state is GetGoalsFatherLoading) {
                        return SizedBox(
                          height: sizeScreen.height - 180,
                          child: Compc.loading(),
                        );
                      } else {
                        if (bloc.fatherGoals.isEmpty) {
                          return SizedBox(
                            height: sizeScreen.height - 180,
                            child: Compc.dontHave('لا يوجد أي هدف لدى أبنائك'),
                          );
                        } else {
                          return ListView.separated(
                            physics: const NeverScrollableScrollPhysics(),
                            padding: const EdgeInsetsDirectional.fromSTEB(
                                25, 10, 25, 35),
                            shrinkWrap: true,
                            itemCount: bloc.fatherGoals.length,
                            separatorBuilder:
                                (BuildContext context, int index) {
                              return const SizedBox(
                                height: 15,
                              );
                            },
                            itemBuilder: (BuildContext context, int index) {
                              return Compc.goalsFather(
                                name: bloc.fatherGoals[index].name,
                                goalName: bloc.fatherGoals[index].goal,
                                imageUrl: Dioc.imageUrl +
                                    bloc.fatherGoals[index].imageUrl,
                                money: bloc.fatherGoals[index].price,
                                onTapgiveHelp: () {
                                  bloc.onTapGiveHelp(context);
                                },
                              );
                            },
                          );
                        }
                      }
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
