import 'package:areb/components/comp.dart';

import 'package:areb/constants/sizes.dart';
import 'package:areb/shared/models/loan/loan.dart';
import 'package:flutter/material.dart';

class ViewLoansChild extends StatelessWidget {
  final List<Loan> loans;
  const ViewLoansChild({super.key, required this.loans});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(
              parent: AlwaysScrollableScrollPhysics()),
          child: Column(
            children: [
              //app bar
              Compc.appbar(
                context,
                title: 'المساعدات المالية',
                fontsize: Sic.s40,
                withBackArrow: true,
                withDivider: true,
              ),

              loans.isEmpty
                  ? Compc.empty(title: 'ليس لديك أي طلبات للمساعدة المالي مسبقة')
                  : ListView.separated(
                      physics: const NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      itemCount: loans.length,
                      separatorBuilder: (BuildContext context, int index) {
                        return const SizedBox(
                          height: 20,
                        );
                      },
                      itemBuilder: (BuildContext context, int index) {
                        return Compc.loanChildCard(
                          date: loans[index].date,
                          money: loans[index].lona,
                          status: loans[index].status,
                          title: loans[index].title,
                        );
                      },
                    ),
            ],
          ),
        ),
      ),
    );
  }
}
