import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';
import 'package:areb/constants/fonts.dart';
import 'package:areb/constants/images.dart';
import 'package:areb/constants/radius.dart';
import 'package:areb/constants/sizes.dart';
import 'package:areb/functions/size_screen.dart';
import 'package:areb/screens/child/dialogs/take_photo_currency/cubit/take_photo_for_currency_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class TakePhotoDialog extends StatefulWidget {
  const TakePhotoDialog({super.key});

  @override
  State<TakePhotoDialog> createState() => _TakePhotoDialogState();
}

class _TakePhotoDialogState extends State<TakePhotoDialog> {
  late TakePhotoForCurrencyCubit bloc;
  @override
  void initState() {
    bloc = BlocProvider.of(context);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      width: sizeScreen.width,
      height: 380,
      decoration: BoxDecoration(
        color: Colorc.lightCyan,
        borderRadius: BorderRadius.circular(Radc.r20),
      ),
      child: Center(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(
              parent: AlwaysScrollableScrollPhysics()),
          child: Column(
            children: [
              //spacing :
              const SizedBox(
                height: 10,
              ),
              //warning :
              Text(
                'تنبيه !',
                style: TextStyle(
                  fontSize: Sic.s40,
                  fontFamily: Fontc.hayahBigTitle,
                  // fontWeight: FontWeight.bold,
                  color: Colorc.red,
                ),
              ),
              //spacing :
              const SizedBox(
                height: 10,
              ),
              //warning text :
              Text(
                'يجب عليك إدخال مالك عبر تصوير قطعة واحدة فقط في كل مرة ...',
                style: TextStyle(
                  fontSize: Sic.s28,
                  fontFamily: Fontc.hayahBigTitle,
                  // fontWeight: FontWeight.bold,
                  color: Colorc.black,
                ),
                textAlign: TextAlign.center,
              ),
              //spacing :
              const SizedBox(
                height: 10,
              ),
              //image currency example :
              ClipRRect(
                borderRadius: BorderRadius.circular(
                  Radc.r10,
                ),
                child: const Image(
                  fit: BoxFit.fitWidth,
                  width: 170,
                  height: 100,
                  image: AssetImage(Imagec.currencyExample),
                ),
              ),

              //spacing :
              const SizedBox(
                height: 25,
              ),

              //takephoto button :
              BlocBuilder<TakePhotoForCurrencyCubit, TakePhotoForCurrencyState>(
                builder: (context, state) {
                  return state is TakePhotoForCurrencyLoading
                      ? Compc.loading(color: Colorc.purple)
                      : Compc.buttonWithIconinAccount(
                          onTap: () {
                            bloc.takePhotoNow(context);
                          },
                          icon: Icons.camera_alt,
                          text: 'التقط صورة الآن',
                          point: false,
                        );
                },
              ),
              //spacing
              const SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
