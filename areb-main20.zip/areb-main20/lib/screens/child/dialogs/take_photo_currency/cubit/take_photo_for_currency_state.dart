part of 'take_photo_for_currency_cubit.dart';

@immutable
sealed class TakePhotoForCurrencyState {}

final class TakePhotoForCurrencyInitial extends TakePhotoForCurrencyState {}

final class TakePhotoForCurrencyLoading extends TakePhotoForCurrencyState {}

final class TakePhotoForCurrencyError extends TakePhotoForCurrencyState {
  final String error;
  TakePhotoForCurrencyError(this.error);
}

final class TakePhotoForCurrencySuccess extends TakePhotoForCurrencyState {}
