import 'package:areb/functions/add_image.dart';
import 'package:areb/functions/message.dart';
import 'package:areb/functions/navigations.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/screens/child/personal_account_child/cubit/child_account_cubit.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/material.dart';

part 'take_photo_for_currency_state.dart';

class TakePhotoForCurrencyCubit extends Cubit<TakePhotoForCurrencyState> {
  TakePhotoForCurrencyCubit() : super(TakePhotoForCurrencyInitial());

  void takePhotoNow(context) async {
    AddImage.imageSelected == null;
    await AddImage.imagePickerFromCamera(context);
    if (AddImage.imageSelected != null) {
      emit(TakePhotoForCurrencyLoading());
      Dioc.postImageToCurrency(context).then(
        (value) {
          // print(value.data);
          // print(value.data['top']);
          // print(value.data['confidence']);

          if (value.data['confidence'] > 0.41) {
            Dioc.sentMoney(
              money: value.data['top'],
              note: '',
              childId: ChildAccountCubit.get(context).user.id,
            ).then((value) {
              // print(value.data);
              if (value.data['message'] == 'successful') {
                AddImage.imageSelected = null;
                Messagec.showSnackBar(
                  context: context,
                  snackbar: Snackc.talkSnackBar('تمت إضافة العملة إلى محفظتك ',
                      millisecendDuration: 2000),
                );
                Navc.pop(context: context);
                ChildAccountCubit.get(context).getUserData(context);

                emit(TakePhotoForCurrencySuccess());
              } else {
                Navc.pop(context: context);

                emit(TakePhotoForCurrencyError(value.data['body']));
              }
            });
          } else {
            Messagec.showSnackBar(
              context: context,
              snackbar: Snackc.errorSnackBar(
                'الصورة غير واضحة الرجاء إعادة تصوير العملة بشكل جيد',
              ),
            );
            Navc.pop(context: context);

            emit(TakePhotoForCurrencyError(value.data['body']));
          }
        },
      ).catchError((e) {
        emit(TakePhotoForCurrencyError(e.toString()));
      });
    }
  }
}
