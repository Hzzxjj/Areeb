import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';
import 'package:areb/constants/radius.dart';
import 'package:areb/constants/sizes.dart';
import 'package:areb/functions/navigations.dart';
import 'package:areb/screens/child/personal_account_child/cubit/child_account_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class EditImageChildDialog extends StatelessWidget {
  const EditImageChildDialog({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ChildAccountCubit, ChildAccountState>(
      builder: (context, state) => Container(
        padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 20),
        height: 150,
        width: 200,
        decoration: BoxDecoration(
          color: Colorc.lightCyan,
          borderRadius: BorderRadius.circular(
            Radc.r10,
          ),
        ),
        child: Column(
          children: [
            //text :
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'تعديل الصورة',
                  style: TextStyle(
                    color: Colorc.black,
                    fontSize: 24,
                  ),
                ),
                IconButton(
                  onPressed: () {
                    Navc.pop(context: context);
                  },
                  icon: Icon(
                    Icons.close,
                    color: Colorc.purple,
                    size: Sic.s28,
                  ),
                ),
              ],
            ),
            //spacing :
            const SizedBox(
              height: 10,
            ),
            state is EditImageChildLoading
                ? Compc.loading(color: Colorc.purple)
                :
                //icon :
                Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      //from gallery:
                      IconButton(
                        onPressed: () {
                          ChildAccountCubit.get(context)
                              .editChildImage(context);
                        },
                        icon: Icon(
                          Icons.image,
                          color: Colorc.purple,
                          size: Sic.s40,
                        ),
                      ),
                    ],
                  ),
          ],
        ),
      ),
    );
  }
}
