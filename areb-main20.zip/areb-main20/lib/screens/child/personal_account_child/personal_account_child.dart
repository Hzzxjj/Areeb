import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';
import 'package:areb/constants/fonts.dart';
import 'package:areb/constants/images.dart';
import 'package:areb/constants/radius.dart';
import 'package:areb/constants/sizes.dart';
import 'package:areb/functions/message.dart';
import 'package:areb/functions/size_screen.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/screens/child/personal_account_child/cubit/child_account_cubit.dart';
import 'package:areb/shared/dio/dio.dart';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class PersonalAccountChild extends StatefulWidget {
  const PersonalAccountChild({super.key});

  @override
  State<PersonalAccountChild> createState() => _PersonalAccountChildState();
}

class _PersonalAccountChildState extends State<PersonalAccountChild> {
  late ChildAccountCubit bloc;

  @override
  void initState() {
    super.initState();
    bloc = BlocProvider.of(context);

    if (bloc.getDataonce == false) {
      bloc.getUserData(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: BlocConsumer<ChildAccountCubit, ChildAccountState>(
        listener: (context, state) {
          state is EditImageChildError
              ? Messagec.showSnackBar(
                  context: context, snackbar: Snackc.errorSnackBar(state.error))
              : null;
        },
        builder: (context, state) {
          return SafeArea(
            child: state is GetUserAccountDetailsChildLoading
                ? SizedBox(
                    child: Compc.loading(),
                  )
                : state is GetUserAccountDetailsChildError
                    ? Compc.noInternet(() {
                        bloc.getUserData(context);
                      })
                    : RefreshIndicator(
                        onRefresh: () async {
                          bloc.getUserData(context);
                        },
                        child: SizedBox(
                          height: sizeScreen.height,
                          child: SingleChildScrollView(
                            physics: const BouncingScrollPhysics(
                              parent: AlwaysScrollableScrollPhysics(),
                            ),
                            child: SizedBox(
                              height: 700,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.start,
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  //app bar
                                  Compc.appbar(
                                    context,
                                    title: 'الحساب الشخصي',
                                    fontsize: Sic.s40,
                                    withBackArrow: false,
                                    withDivider: false,
                                  ),
                                  //account image :
                                  Container(
                                    margin: const EdgeInsetsDirectional.only(
                                      top: 3,
                                      bottom: 20,
                                    ),
                                    height: 2,
                                    color: Colorc.grey,
                                    width: double.infinity,
                                  ),
                                  Align(
                                    alignment: AlignmentDirectional.topCenter,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        //image :
                                        Compc.tapAnimation(
                                          onTap: () {
                                            bloc.editImageDialog(context);
                                          },
                                          child: Container(
                                            clipBehavior: Clip.antiAlias,
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(100),
                                              color: Colorc.lightGreen,
                                            ),
                                            height: 150,
                                            width: 150,
                                            child: bloc.user.image.isEmpty
                                                ? const Padding(
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                            vertical: 5.0),
                                                    child: Image(
                                                        image: AssetImage(
                                                            Imagec.child)),
                                                  )
                                                : Compc.networkImage(
                                                    imageUrl: Dioc.imageUrl +
                                                        bloc.user.image,
                                                  ),
                                          ),
                                        ),
                                        //Edit image :
                                        Transform.translate(
                                          offset: const Offset(45, -30),
                                          child: Container(
                                            width: 30,
                                            height: 30,
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(
                                                Radc.r50,
                                              ),
                                              color: Colorc.purple,
                                            ),
                                            child: Icon(
                                                Icons.edit_note_outlined,
                                                color: Colorc.lightCyan,
                                                size: 20),
                                          ),
                                        ),
                                        //Spacer :
                                        const SizedBox(
                                          height: 0,
                                        ),
                                        Text(
                                          bloc.user.name,
                                          style: TextStyle(
                                            fontSize: Sic.s40 + 5,
                                            fontFamily: Fontc.hayahBigTitle,
                                            fontWeight: FontWeight.bold,
                                            shadows: [
                                              BoxShadow(
                                                color: Colorc.darkGrey
                                                    .withOpacity(0.3),
                                                offset: const Offset(0, 1),
                                                blurRadius: 3,
                                              )
                                            ],
                                          ),
                                        ),
                                        //Spacer :
                                        const SizedBox(
                                          height: 20,
                                        ),
                                        //account Name :
                                        Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceAround,
                                          mainAxisSize: MainAxisSize.max,
                                          children: [
                                            Text(
                                              'العمر:',
                                              style: TextStyle(
                                                fontSize: Sic.s33,
                                                fontFamily: Fontc.hayahBigTitle,
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                            Text(
                                              ((DateTime.now().year) -
                                                      (DateTime.parse(
                                                              bloc.user.date)
                                                          .year))
                                                  .toString(),
                                              style: TextStyle(
                                                fontSize: Sic.s33,
                                                fontFamily: Fontc.hayahBigTitle,
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                          ],
                                        ),
                                        //Spacer :
                                        const SizedBox(
                                          height: 20,
                                        ),
                                        Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceAround,
                                          mainAxisSize: MainAxisSize.max,
                                          children: [
                                            Text(
                                              'المال الحالي:',
                                              style: TextStyle(
                                                fontSize: Sic.s33,
                                                fontFamily: Fontc.hayahBigTitle,
                                                // fontWeight: FontWeight.w600,
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                            Row(
                                              children: [
                                                Text(
                                                  '${bloc.user.money} ر.س',
                                                  style: TextStyle(
                                                    fontSize: Sic.s33,
                                                    fontFamily:
                                                        Fontc.hayahBigTitle,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                                //spacing :
                                                const SizedBox(
                                                  width: 10,
                                                ),
                                                const Icon(
                                                  Icons.monetization_on_sharp,
                                                  color: Colors.amber,
                                                )
                                              ],
                                            )
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),

                                  //spacing :
                                  const SizedBox(
                                    height: 35,
                                  ),
                                  //button :
                                  Compc.buttonWithIcon(
                                    onTap: () {
                                      bloc.onTapLoanButton(context);
                                    },
                                    text: 'سجل طلباتي',
                                    icon: Icons.money,
                                  )
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
          );
        },
      ),
    );
  }
}
