import 'package:areb/functions/add_image.dart';
import 'package:areb/functions/navigations.dart';
import 'package:areb/functions/run_dialog.dart';
import 'package:areb/screens/child/dialogs/edit_image/edit_image_childd.dart';
import 'package:areb/screens/child/view_loans/view_loans.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:areb/shared/models/child/child.dart';
import 'package:areb/shared/models/loan/loan.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/material.dart';

part 'child_account_state.dart';

class ChildAccountCubit extends Cubit<ChildAccountState> {
  static ChildAccountCubit get(context) => BlocProvider.of(context);
  ChildAccountCubit() : super(ChildAccountInitial());
  late Child user;
  List<Loan> loans = [];
  bool getDataonce = false;

  void getUserData(context) {
    emit(GetUserAccountDetailsChildLoading());
    Dioc.getUsersOnly().then((value) {
      user = Child.fromMap(value.data['user']);

      loans = List.from(value.data['loans'].map((e) => Loan.fromMap(e)));

      getDataonce = true;
      emit(GetUserAccountDetailsChildSuccess());
    }).catchError((e) {
      emit(GetUserAccountDetailsChildError(e));
    });
  }

  void editImageDialog(context) {
    RunDialogc.animationDialog(
        context: context, child: const EditImageChildDialog());
  }

  void editChildImage(context) async {
    AddImage.imageSelected = null;
    await AddImage.imagePickerFromGallery(context);

    if (AddImage.imageSelected != null) {
      emit(EditImageChildLoading());
      Dioc.editChildimage(
        date: user.date,
        email: user.email,
        name: user.name,
        password: '***************',
        image: AddImage.imageSelected!,
      ).then((value) {
        if (value.data['message'] == 'successful') {
          emit(EditImageChildSuccess());
          Navc.pop(context: context);
          AddImage.imageSelected = null;
          getUserData(context);
        } else {
          Navc.pop(context: context);

          emit(EditImageChildError(value.data['body']));
        }
      }).catchError((e) {
        Navc.pop(context: context);

        emit(EditImageChildError(e));
      });
    }
  }

  void onTapLoanButton(context) {
    Navc.push(context: context, screenToPush: ViewLoansChild(loans: loans));
  }
}
