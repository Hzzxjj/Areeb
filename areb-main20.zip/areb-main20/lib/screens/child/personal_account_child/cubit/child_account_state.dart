part of 'child_account_cubit.dart';

@immutable
sealed class ChildAccountState {}

final class ChildAccountInitial extends ChildAccountState {}

final class GetUserAccountDetailsChildLoading extends ChildAccountState {}

final class GetUserAccountDetailsChildError extends ChildAccountState {
  final String error;
  GetUserAccountDetailsChildError(this.error);
}

final class GetUserAccountDetailsChildSuccess extends ChildAccountState {}

///for image :

final class EditImageChildLoading extends ChildAccountState {}

final class EditImageChildError extends ChildAccountState {
  final String error;
  EditImageChildError(this.error);
}

final class EditImageChildSuccess extends ChildAccountState {}
