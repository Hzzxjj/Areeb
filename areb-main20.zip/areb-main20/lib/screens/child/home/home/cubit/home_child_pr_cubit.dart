import 'package:areb/functions/navigations.dart';
import 'package:areb/screens/child/bottom_nav_bar/cubit/bottom_nav_bar_child_cubit.dart';
import 'package:areb/screens/child/home/calculator/calculator.dart';
import 'package:areb/screens/child/home/gools/gools.dart';
import 'package:areb/screens/child/home/records/records.dart';
import 'package:areb/screens/child/home/smart_Assistant/smart_assistant.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';

part 'home_child_pr_state.dart';

class HomeChildPrCubit extends Cubit<HomeChildPrState> {
  static HomeChildPrCubit get(context) => BlocProvider.of(context);
  HomeChildPrCubit() : super(HomeChildPrInitial());

  void onTapMainCards(context, int index) {
    index == 1
        ? Navc.push(
            context: context,
            screenToPush: const GoolsChild(),
            type: PageTransitionType.fade,
          )
        : index == 0
            ? Navc.push(
                context: context,
                screenToPush: const Records(),
                type: PageTransitionType.fade,
              )
            : index == 3
                ? BottomNavBarChildCubit.get(context)
                    .pageController!
                    .animateToPage(1,
                        duration: const Duration(microseconds: 800),
                        curve: Curves.fastOutSlowIn)
                : Navc.push(
                    context: context,
                    screenToPush: const Calculator(),
                    type: PageTransitionType.fade,
                  );
  }

  void onTapChatBot(context) {
    //
    Navc.push(
      context: context,
      screenToPush: const SmartAssistant(),
    );
  }
}
