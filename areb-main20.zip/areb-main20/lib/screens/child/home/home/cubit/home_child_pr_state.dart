part of 'home_child_pr_cubit.dart';

@immutable
sealed class HomeChildPrState {}

final class HomeChildPrInitial extends HomeChildPrState {}
