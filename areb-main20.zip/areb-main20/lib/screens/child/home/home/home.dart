import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';
import 'package:areb/constants/fonts.dart';
import 'package:areb/constants/images.dart';
import 'package:areb/constants/radius.dart';
import 'package:areb/constants/shadow.dart';
import 'package:areb/constants/sizes.dart';
import 'package:areb/screens/child/home/home/cubit/home_child_pr_cubit.dart';
import 'package:areb/shared/models/home_medels/home_models.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zoom_tap_animation/zoom_tap_animation.dart';

class HomeChild extends StatefulWidget {
  const HomeChild({super.key});

  @override
  State<HomeChild> createState() => _HomeChildState();
}

class _HomeChildState extends State<HomeChild> {
  late HomeChildPrCubit bloc;
  @override
  void initState() {
    super.initState();
    bloc = BlocProvider.of(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // bottomNavigationBar: BottomNavBarChild(),
      extendBody: true,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            children: [
              //app bar
              Compc.appbar(
                context,
                title: 'أريب',
                withBackArrow: false,
                withDivider: false,
              ),
              //spacing :
              const SizedBox(
                height: 10,
              ),
              //gride view:
              GridView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 30),
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 13,
                  mainAxisSpacing: 15,
                ),
                itemCount: homeModels.length,
                itemBuilder: (BuildContext context, int index) {
                  return ZoomTapAnimation(
                    begin: 1,
                    end: 0.90,
                    child: InkWell(
                      onTap: () {
                        bloc.onTapMainCards(context, index);
                      },
                      overlayColor: WidgetStatePropertyAll(Colorc.trans),
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: homeModels[index].color,
                          borderRadius: BorderRadius.circular(Radc.r18),
                          boxShadow: [
                            Shadc.button,
                          ],
                        ),
                        child: Column(
                          children: [
                            //title :
                            Text(
                              homeModels[index].title,
                              style: TextStyle(
                                fontSize: Sic.s40 + 5,
                                fontFamily: Fontc.hayahBigTitle,
                              ),
                            ),
                            //discription:
                            Text(
                              homeModels[index].disc,
                              style: TextStyle(
                                fontSize: Sic.s18,
                                overflow: TextOverflow.ellipsis,
                                fontFamily: Fontc.hayahBigTitle,
                              ),
                              maxLines: 2,
                              textAlign: TextAlign.center,
                            ),
                            //icon :
                            Expanded(
                              child: Align(
                                alignment: AlignmentDirectional.bottomStart,
                                child: Icon(
                                  homeModels[index].icon,
                                  color: Colorc.black,
                                  size: Sic.s36,
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
              //spacing :
              const SizedBox(
                height: 30,
              ),
              //talk with intellegance assestant text:
              Text(
                'تحدث إلى\n مساعدك الذكي',
                style: TextStyle(
                  fontSize: Sic.s33,
                  fontFamily: Fontc.hayahBigTitle,
                ),
                textAlign: TextAlign.center,
              ),
              //spacing :
              const SizedBox(
                height: 5,
              ),
              //assestant image :
              ZoomTapAnimation(
                begin: 1,
                end: 0.90,
                child: InkWell(
                  onTap: () {
                    bloc.onTapChatBot(context);
                  },
                  overlayColor: WidgetStatePropertyAll(Colorc.trans),
                  child: const Image(
                    width: 115,
                    fit: BoxFit.cover,
                    image: AssetImage(
                      Imagec.assistant,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
