import 'package:areb/constants/colors.dart';
import 'package:areb/constants/radius.dart';
import 'package:areb/constants/shadow.dart';
import 'package:areb/constants/sizes.dart';
import 'package:areb/functions/navigations.dart';
import 'package:areb/screens/child/home/gools/add_new_gool.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:zoom_tap_animation/zoom_tap_animation.dart';

class GoolsFloatingActionButton extends StatelessWidget {
  const GoolsFloatingActionButton({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
        bottom: 40,
      ),
      child: ZoomTapAnimation(
        begin: 1,
        end: 0.90,
        child: InkWell(
          overlayColor: WidgetStatePropertyAll(
            Colorc.trans,
          ),
          onTap: () {
            Navc.push(
              context: context,
              screenToPush: const AddNewGoolsChild(),
              type: PageTransitionType.rightToLeftWithFade,
            );
          },
          child: Container(
            width: 140,
            height: 50,
            decoration: BoxDecoration(
              color: Colorc.purple,
              borderRadius: BorderRadius.circular(
                Radc.r15,
              ),
              border: Border.all(color: Colorc.white),
              boxShadow: [
                Shadc.button,
              ],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                //add goole
                Text(
                  'إضافة هدف',
                  style: TextStyle(
                    fontSize: Sic.s20,
                    color: Colorc.white,
                    // fontFamily: Fontc.hayahBigTitle,
                  ),
                ),
                //icon:
                const Icon(
                  Icons.add_circle_outline,
                  color: Colorc.white,
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
