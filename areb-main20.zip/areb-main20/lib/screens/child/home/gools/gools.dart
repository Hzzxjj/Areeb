import 'package:areb/components/comp.dart';
import 'package:areb/functions/message.dart';
import 'package:areb/functions/size_screen.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/screens/child/home/gools/cubit/gools_child_bloc_cubit.dart';
import 'package:areb/screens/child/home/gools/floating_action_button.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class GoolsChild extends StatefulWidget {
  const GoolsChild({super.key});

  @override
  State<GoolsChild> createState() => _GoolsChildState();
}

class _GoolsChildState extends State<GoolsChild> {
  late GoolsChildBlocCubit bloc;
  @override
  void initState() {
    super.initState();
    bloc = GoolsChildBlocCubit.get(context);
    if (bloc.getDataOnce == false) {
      bloc.getGoals();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: const GoolsFloatingActionButton(),
      extendBody: true,
      body: SafeArea(
        child: BlocListener<GoolsChildBlocCubit, GoolsChildBlocState>(
          listener: (context, state) {
            state is GetGoalsChildError
                ? Messagec.showSnackBar(
                    context: context,
                    snackbar: Snackc.errorSnackBar(state.error))
                : null;
          },
          child: RefreshIndicator(
            onRefresh: () async {
              bloc.getGoals();
            },
            child: SizedBox(
              height: sizeScreen.height,
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(
                  parent: AlwaysScrollableScrollPhysics(),
                ),
                child: Column(
                  children: [
                    //appbar :
                    Compc.appbar(
                      context,
                      title: 'الأهداف',
                      withBackArrow: true,
                      withDivider: true,
                      fontsize: 75,
                    ),
                    //spacing :
                    const SizedBox(
                      height: 0,
                    ),
                    //gools :
                    BlocBuilder<GoolsChildBlocCubit, GoolsChildBlocState>(
                      builder: (context, state) {
                        if (state is GetGoalsChildLoading) {
                          return SizedBox(
                            height: sizeScreen.height - 170,
                            child: Compc.loading(),
                          );
                        } else {
                          if (bloc.childGoals.isEmpty) {
                            return SizedBox(
                                height: sizeScreen.height - 170,
                                child: Compc.dontHave(
                                    'ليس لديك أي اهداف حتى الان'));
                          } else {
                            return ListView.separated(
                              physics: const NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              padding: const EdgeInsetsDirectional.fromSTEB(
                                  30, 15, 30, 35),
                              itemCount: bloc.childGoals.length,
                              separatorBuilder:
                                  (BuildContext context, int index) {
                                return const SizedBox(
                                  height: 20,
                                );
                              },
                              itemBuilder: (BuildContext context, int index) {
                                return Compc.goalsChild(
                                  goalName: bloc.childGoals[index].goal,
                                  money: bloc.childGoals[index].price,
                                  imageUrl: Dioc.imageUrl +
                                      bloc.childGoals[index].imageUrl,
                                  onTapDelete: () {
                                    bloc.deleteGoal(bloc.childGoals[index].id);
                                  },
                                  onTapDone: () {
                                    bloc.onTapDoneGoal(
                                        bloc.childGoals[index].id);
                                  },
                                );
                              },
                            );
                          }
                        }
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
