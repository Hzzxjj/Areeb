import 'package:areb/constants/colors.dart';
import 'package:areb/constants/radius.dart';
import 'package:areb/constants/sizes.dart';
import 'package:areb/functions/add_image.dart';
import 'package:areb/functions/message.dart';

import 'package:areb/functions/snackbar.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:areb/shared/models/goals/goals.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:areb/functions/navigations.dart';

part 'gools_child_bloc_state.dart';

class GoolsChildBlocCubit extends Cubit<GoolsChildBlocState> {
  static GoolsChildBlocCubit get(context) => BlocProvider.of(context);
  GoolsChildBlocCubit() : super(GoolsChildBlocInitial());

  final TextEditingController goolNameController = TextEditingController();
  final TextEditingController goolPriceController = TextEditingController();
  List<Goals> childGoals = [];
  bool getDataOnce = false;

  Future<void> getGoals() async {
    emit(GetGoalsChildLoading());
    await Dioc.getGoals().then((value) {
      if (value.data['message'] == 'successful') {
        childGoals =
            List.from(value.data['goals'].map((e) => Goals.fromMap(e)));
        getDataOnce = true;
        emit(GetGoalsChildSuccess());
      } else {
        emit(GetGoalsChildError('error'));
      }
    }).catchError((e) {
      emit(GetGoalsChildError(e.toString()));
    });
  }

  //delete goal:
  void deleteGoal(id) {
    emit(GetGoalsChildLoading());
    Dioc.deleteGoals(id: id).then((value) {
      getGoals();
    }).catchError((e) {
      emit(GetGoalsChildError(e.toString()));
    });
  }

  //change image state :
  void changeImageState() {
    emit(ChangeImageChild());
  }

  void onTapAddPhoto(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        child: Container(
          height: 90,
          width: 200,
          decoration: BoxDecoration(
            color: Colorc.lightCyan,
            borderRadius: BorderRadius.circular(
              Radc.r10,
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              //from gallery:
              IconButton(
                onPressed: () {
                  AddImage.imagePickerFromGallery(
                    context,
                  ).then((value) {
                    changeImageState();

                    Navc.pop(context: context);
                  });
                },
                icon: Icon(
                  Icons.image,
                  color: Colorc.purple,
                  size: Sic.s40,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  //on tap register goals:
  void registerGoals(context) {
    if (AddImage.imageSelected != null &&
        goolNameController.text.isNotEmpty &&
        goolPriceController.text.isNotEmpty) {
      emit(RegisterGoalsLoading());
      Dioc.postGoals(
        name: goolNameController.text,
        price: goolPriceController.text,
        image: AddImage.imageSelected!,
      ).then((value) {
        getGoals();
        goolNameController.clear();
        goolPriceController.clear();
        AddImage.imageSelected = null;
        Navc.pop(context: context);
        emit(RegisterGoalsSuccess());
      }).catchError((e) {
        emit(
          RegisterGoalsError(
            e.toString(),
          ),
        );
      });
    } else {
      Messagec.showSnackBar(
        context: context,
        snackbar: Snackc.errorSnackBar('يجب ملئ جميع الحقول والصورة'),
      );
    }
  }

  void onTapDoneGoal(int id) {
    emit(GetGoalsChildLoading());
    Dioc.doneGoals(id: id).then((value) {
      if (value.data['message'] == 'successful') {
        getGoals();

        emit(GetGoalsChildSuccess());
      } else {
        emit(GetGoalsChildError(value.data['body']));
      }
    }).catchError((e) {
      emit(GetGoalsChildError(e.toString()));
    });
  }
}
