part of 'gools_child_bloc_cubit.dart';

@immutable
sealed class GoolsChildBlocState {}

final class GoolsChildBlocInitial extends GoolsChildBlocState {}

final class ChangeImageChild extends GoolsChildBlocState {}

/////////////
final class GetGoalsChildSuccess extends GoolsChildBlocState {}

final class GetGoalsChildLoading extends GoolsChildBlocState {}

final class GetGoalsChildError extends GoolsChildBlocState {
  final String error;
  GetGoalsChildError(this.error);
}
/////////////////////

/////////////////////////
final class RegisterGoalsSuccess extends GoolsChildBlocState {}

final class RegisterGoalsLoading extends GoolsChildBlocState {}

final class RegisterGoalsError extends GoolsChildBlocState {
  final String error;
  RegisterGoalsError(this.error);
}
////////////////////////