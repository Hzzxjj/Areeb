import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';
import 'package:areb/constants/fonts.dart';
import 'package:areb/constants/radius.dart';

import 'package:areb/constants/sizes.dart';
import 'package:areb/functions/add_image.dart';

import 'package:areb/screens/child/home/gools/cubit/gools_child_bloc_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class AddNewGoolsChild extends StatefulWidget {
  const AddNewGoolsChild({super.key});

  @override
  State<AddNewGoolsChild> createState() => _AddNewGoolsChildState();
}

class _AddNewGoolsChildState extends State<AddNewGoolsChild> {
  @override
  void initState() {
    AddImage.imageSelected = null;
    AddImage.image = null;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    GoolsChildBlocCubit cubit = GoolsChildBlocCubit.get(context);
    return Scaffold(
      extendBody: true,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            children: [
              //appbar :
              Compc.appbar(
                context,
                title: 'إضافة هدف',
                withBackArrow: true,
                withDivider: true,
                fontsize: 55,
              ),
              //spacing :
              const SizedBox(
                height: 10,
              ),
              BlocBuilder<GoolsChildBlocCubit, GoolsChildBlocState>(
                builder: (context, state) {
                  return ConstrainedBox(
                    constraints: BoxConstraints.tight(
                      Size(
                        MediaQuery.sizeOf(context).width - 40,
                        (MediaQuery.sizeOf(context).height) - 180,
                      ),
                    ),
                    child: Column(
                      children: [
                        //add goal text :
                        Align(
                          alignment: AlignmentDirectional.centerStart,
                          child: Text(
                            ' إضافة هدف',
                            style: TextStyle(
                              color: Colorc.green,
                              fontSize: Sic.s28,
                              fontFamily: Fontc.hayahBigTitle,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                        //spacing :
                        const SizedBox(
                          height: 15,
                        ),
                        // name text field :
                        Compc.formField(
                          controller: cubit.goolNameController,
                          validator: null,
                          keyboardType: TextInputType.text,
                          textInputAction: TextInputAction.next,
                          hintText: 'إسم الهدف',
                        ),
                        //spacing :
                        const SizedBox(
                          height: 15,
                        ),
                        // price text field :
                        Compc.formField(
                          controller: cubit.goolPriceController,
                          validator: null,
                          keyboardType: TextInputType.phone,
                          textInputAction: TextInputAction.done,
                          hintText: 'سعر الهدف',
                        ),
                        //spacing :
                        const SizedBox(
                          height: 15,
                        ),
                        //add photo
                        Expanded(
                          child: Center(
                            child: Compc.buttonWithIcon(
                              onTap: () {
                                cubit.onTapAddPhoto(context);
                              },
                              icon: Icons.photo_camera,
                              text: 'أضف صورة\n للهدف',
                            ),
                          ),
                        ),
                        //show image :
                        if (AddImage.imageSelected != null) ...[
                          //spacing :
                          const SizedBox(
                            height: 15,
                          ),
                          //image :
                          ClipRRect(
                            clipBehavior: Clip.antiAliasWithSaveLayer,
                            borderRadius: BorderRadius.circular(
                              Radc.r24,
                            ),
                            child: Image(
                              image: FileImage(AddImage.imageSelected!),
                              fit: BoxFit.cover,
                              width: 175,
                              height: 175,
                            ),
                          ),
                        ],

                        //spacing :
                        const SizedBox(
                          height: 15,
                        ),
                        //done goole
                        Expanded(
                          child: state is RegisterGoalsLoading
                              ? Compc.loading(color: Colorc.purple)
                              : Center(
                                  child: Compc.buttonWithIcon(
                                    onTap: () {
                                      cubit.registerGoals(context);
                                    },
                                    icon: Icons.arrow_circle_up_rounded,
                                    text: 'تسجيل الهدف',
                                  ),
                                ),
                        ),
                      ],
                    ),
                  );
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
