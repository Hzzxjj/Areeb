part of 'calculator_cubit.dart';

@immutable
sealed class CalculatorState {}

final class CalculatorInitial extends CalculatorState {}

final class SelectedGoalsInCulculator extends CalculatorState {}

final class CalculatorGetGolsLoading extends CalculatorState {}

final class CalculatorGetGolsSuccess extends CalculatorState {}

final class CalculatorGetGolsError extends CalculatorState {}
