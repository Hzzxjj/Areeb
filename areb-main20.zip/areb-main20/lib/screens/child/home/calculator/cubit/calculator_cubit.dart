import 'package:areb/functions/message.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/screens/child/home/gools/cubit/gools_child_bloc_cubit.dart';
import 'package:areb/shared/models/goals/goals.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/material.dart';

part 'calculator_state.dart';

class CalculatorCubit extends Cubit<CalculatorState> {
  CalculatorCubit() : super(CalculatorInitial());

  final TextEditingController moneyController = TextEditingController();
  double result = 0;

  late GoolsChildBlocCubit goalsChildBloc;

  int? goalSelected;

  void initPr(context) {
    goalsChildBloc = GoolsChildBlocCubit.get(context);
    goalSelected = null;
    moneyController.clear();
    result = 0;
  }

  void init(context) async {
    emit(CalculatorGetGolsLoading());
    if (goalsChildBloc.getDataOnce == false) {
      await goalsChildBloc.getGoals();
      emit(CalculatorGetGolsSuccess());
    } else {
      emit(CalculatorGetGolsSuccess());
    }
  }

  void onSelectGoal(value) {
    goalSelected = value;
    emit(SelectedGoalsInCulculator());
  }

  void calculate(context) {
    if (goalSelected == null || moneyController.text.isEmpty) {
      Messagec.showSnackBar(
          context: context,
          snackbar: Snackc.errorSnackBar('الرجاء تعبئة الحقول في الأعلى'));
    } else {
      //calculate
      result = (double.parse(findGoalById().price.toString()) /
          double.parse(moneyController.text));

      emit(SelectedGoalsInCulculator());
    }
  }

  Goals findGoalById() {
    // return
    late Goals x;
    for (Goals goal in goalsChildBloc.childGoals) {
      if (goal.id == goalSelected) {
        x = goal;
        break;
      }
    }
    return x;
  }
}
