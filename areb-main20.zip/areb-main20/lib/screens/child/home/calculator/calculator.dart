import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';
import 'package:areb/constants/fonts.dart';
import 'package:areb/constants/images.dart';
import 'package:areb/constants/radius.dart';
import 'package:areb/constants/sizes.dart';
import 'package:areb/screens/child/home/calculator/cubit/calculator_cubit.dart';
import 'package:areb/screens/child/home/gools/cubit/gools_child_bloc_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class Calculator extends StatefulWidget {
  const Calculator({super.key});

  @override
  State<Calculator> createState() => _CalculatorState();
}

class _CalculatorState extends State<Calculator> {
  late CalculatorCubit bloc;
  late GoolsChildBlocCubit golsChildBloc;

  @override
  void initState() {
    super.initState();
    bloc = BlocProvider.of(context);
    bloc.initPr(context);
    golsChildBloc = GoolsChildBlocCubit.get(context);

    bloc.init(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: SafeArea(
        child: BlocConsumer<CalculatorCubit, CalculatorState>(
          listener: (context, state) {},
          builder: (context, state) {
            return state is CalculatorGetGolsLoading
                ? Compc.loading()
                : SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    child: Column(
                      children: [
                        //appbar :
                        Compc.appbar(
                          context,
                          title: 'الحاسبة',
                          withBackArrow: true,
                          withDivider: true,
                          fontsize: 55,
                        ),
                        //spacing :
                        const SizedBox(
                          height: 10,
                        ),
                        //title:
                        Text(
                          'حساب المدة الزمنية اللازمة لتحقيق الهدف',
                          style: TextStyle(
                            fontFamily: Fontc.marheySmallTitle,
                            color: Colorc.green.withOpacity(0.8),
                            fontSize: Sic.s18,
                          ),
                        ),
                        //spacing :
                        const SizedBox(
                          height: 25,
                        ),
                        //drop down Button Calculator :
                        Compc.dropdownButtonCalculator(
                            goals: golsChildBloc.childGoals,
                            goalsSelected: bloc.goalSelected,
                            onChanged: (value) {
                              bloc.onSelectGoal(value);
                            }),
                        //spacing :
                        const SizedBox(
                          height: 20,
                        ),
                        //form Field Calculator :
                        Compc.formFieldCalculator(
                          controller: bloc.moneyController,
                          validator: null,
                          keyboardType: TextInputType.number,
                          textInputAction: TextInputAction.done,
                          hintText: 'المبلغ المدخر يوميا',

                          //
                        ),
                        //
                        //spacing :
                        const SizedBox(
                          height: 150,
                        ),
                        //result
                        Container(
                          height: 70,
                          margin: const EdgeInsets.symmetric(
                            horizontal: 25,
                          ),
                          // padding: const EdgeInsets.symmetric(
                          //   horizontal: 40,
                          // ),
                          width: double.infinity,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(Radc.r10),
                            color: Colorc.white,
                          ),
                          alignment: Alignment.center,
                          child: SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Text(
                              ' المدة اللازمة لتحقيق الهدف : \n${bloc.result.toStringAsFixed(2)} يوم',
                              style: TextStyle(
                                fontFamily: Fontc.marheySmallTitle,
                                color: Colorc.darkGrey.withOpacity(0.7),
                                height: 1.7,
                                fontSize: Sic.s20,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                        //
                        //spacing :
                        const SizedBox(
                          height: 20,
                        ),
                        Padding(
                          padding: const EdgeInsetsDirectional.only(start: 50),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Image.asset(
                                Imagec.childThink,
                                width: 75,
                              ),
                              Compc.buttonCalculator(
                                onTap: () {
                                  bloc.calculate(context);
                                },
                                text: 'احسب',
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  );
          },
        ),
      ),
    );
  }
}
