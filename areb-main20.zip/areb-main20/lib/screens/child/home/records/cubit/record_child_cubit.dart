import 'package:areb/constants/colors.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:areb/shared/models/record_date_day/record_date.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/material.dart';

part 'record_child_state.dart';

class RecordChildCubit extends Cubit<RecordChildState> {
  RecordChildCubit() : super(RecordChildInitial());
  List<(Color, String, String, double)> recordLi = [];

  List<DateDayRecord> dateDayLi = [
    DateDayRecord(index: 0, ar: 'يومي', en: 'day'),
    DateDayRecord(index: 1, ar: 'شهري', en: 'month'),
    DateDayRecord(index: 2, ar: 'سنوي', en: 'year'),
  ];

  late int selectedFiltiring;

  double sumAllActions = 0;

  void init() {
    selectedFiltiring = 0;
    rigistersFiltired();
  }

  double sum() {
    double x = 0;
    for (int i = 1; i < recordLi.length; i++) {
      x = x + recordLi[i].$4;
    }
    return x;
  }

  void changeSelect(value) {
    selectedFiltiring = value;
    emit(RecordChildChangeSelected());
    rigistersFiltired();
  }

  void rigistersFiltired() {
    emit(GetRigistersFiltiredLoading());
    Dioc.filtiringAllRigisters(dateDayLi[selectedFiltiring].en).then((value) {
      if (value.data['message'] == 'successful') {
        recordLi = [
          (
            Colorc.lightRed,
            'المدفوعات',
            'المال الذي أنفقته',
            value.data['money_paid'].toDouble()
          ),
          (
            Colorc.blue,
            'المدخرات',
            'المال الذي احتفظت به',
            value.data['money_saved'].toDouble()
          ),
          (
            Colorc.cyan,
            'المساعدات المالية',
            'المال الذي طلبته من أحد الأبوين',
            value.data['loan_money'].toDouble()
          ),
          (
            Colorc.lightGreen3,
            'الجوائز',
            'المال الذي ربحته من مهامك المنجزة',
            value.data['prize_money'].toDouble()
          ),
        ];

        sumAllActions = sum() + recordLi[0].$4;
        emit(GetRigistersFiltiredSuccess());
      } else {
        emit(GetRigistersFiltiredError('error'));
      }
    }).catchError((e) {
      emit(GetRigistersFiltiredError(e.toString()));
    });
  }
}

/**
 * 
 {message: successful,
  total: 105, : 0,
   money_saved: 105, loan_money: 0,
    prize_money: 0,
     body: تم الأمر بنجاح}
 */
