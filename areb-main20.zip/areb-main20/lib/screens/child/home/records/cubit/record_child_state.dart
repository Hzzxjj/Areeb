part of 'record_child_cubit.dart';

@immutable
sealed class RecordChildState {}

final class RecordChildInitial extends RecordChildState {}

final class RecordChildChangeSelected extends RecordChildState {}

final class GetRigistersFiltiredLoading extends RecordChildState {}

final class GetRigistersFiltiredSuccess extends RecordChildState {}

final class GetRigistersFiltiredError extends RecordChildState {
  final String error;
  GetRigistersFiltiredError(this.error);
}
