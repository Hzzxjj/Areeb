import 'package:areb/components/comp.dart';
import 'package:flutter/material.dart';

class Payments extends StatelessWidget {
  const Payments({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: SafeArea(
        child: Column(
          children: [
            //appbar :
            Compc.appbar(
              context,
              title: 'المدفوعات',
              withBackArrow: true,
              withDivider: true,
              fontsize: 55,
            ),

            Expanded(
              child: ListView.builder(
                physics: const BouncingScrollPhysics(),
                shrinkWrap: true,
                itemCount: 10,
                itemBuilder: (context, index) {
                  return Compc.cardRecords(
                    title: 'جائزة بسبب تصرفك الجيد',
                    money: '50 ر.س',
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
