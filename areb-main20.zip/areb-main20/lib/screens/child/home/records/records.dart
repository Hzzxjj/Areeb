import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';
import 'package:areb/constants/fonts.dart';
import 'package:areb/constants/sizes.dart';
import 'package:areb/screens/child/home/records/cubit/record_child_cubit.dart';
import 'package:awesome_circular_chart/awesome_circular_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class Records extends StatefulWidget {
  const Records({super.key});

  @override
  State<Records> createState() => _RecordsState();
}

class _RecordsState extends State<Records> {
  late RecordChildCubit bloc;
  @override
  void initState() {
    super.initState();
    bloc = BlocProvider.of(context);
    bloc.init();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: SafeArea(
        child: BlocConsumer<RecordChildCubit, RecordChildState>(
          listener: (context, state) {},
          builder: (context, state) {
            return state is GetRigistersFiltiredLoading
                ? Compc.loading()
                : state is GetRigistersFiltiredError
                    ? Compc.noInternet(
                        () {
                          bloc.rigistersFiltired();
                        },
                      )
                    : SingleChildScrollView(
                        physics: const BouncingScrollPhysics(
                            parent: AlwaysScrollableScrollPhysics()),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            //app bar
                            Compc.appbar(
                              context,
                              title: 'البيانات المالية',
                              fontsize: Sic.s40,
                              withBackArrow: true,
                              withDivider: true,
                            ),
                            //drop down Button Home Child
                            Compc.dropdownButtonHomeChild(
                              dateday: bloc.dateDayLi,
                              onChanged: (value) {
                                bloc.changeSelect(value);
                              },
                              selected: bloc.selectedFiltiring,
                            ),

                            //spacing
                            const SizedBox(
                              height: 10,
                            ),
                            // circle
                            //circular
                            SizedBox(
                              height: 270,
                              width: 270,
                              child: Stack(
                                fit: StackFit.expand,
                                children: [
                                  Align(
                                    alignment: Alignment.center,
                                    child: AnimatedCircularChart(
                                      key: const Key('value'),
                                      size: const Size(300, 300),
                                      initialChartData: [
                                        CircularStackEntry(
                                          [
                                            //protfolio
                                            CircularSegmentEntry(
                                              ((bloc.recordLi[0].$4 /
                                                      bloc.sumAllActions) *
                                                  96),
                                              bloc.recordLi[0].$1,
                                              rankKey: 'protfolio',
                                            ),
                                            //spacer
                                            CircularSegmentEntry(
                                              1,
                                              Colorc.lightCyan,
                                              rankKey: 'spacer',
                                            ),
                                            //pyment
                                            CircularSegmentEntry(
                                              ((bloc.recordLi[1].$4 /
                                                      bloc.sumAllActions) *
                                                  96),
                                              bloc.recordLi[1].$1,
                                              rankKey: 'payment',
                                            ),
                                            //spacer
                                            CircularSegmentEntry(
                                              1,
                                              Colorc.lightCyan,
                                              rankKey: 'spacer',
                                            ),
                                            // loans
                                            CircularSegmentEntry(
                                              ((bloc.recordLi[2].$4 /
                                                      bloc.sumAllActions) *
                                                  96),
                                              bloc.recordLi[2].$1,
                                              rankKey: 'completed',
                                            ),
                                            //spacer
                                            CircularSegmentEntry(
                                              1,
                                              Colorc.lightCyan,
                                              rankKey: 'spacer',
                                            ),
                                            //reward
                                            CircularSegmentEntry(
                                              ((bloc.recordLi[3].$4 /
                                                      bloc.sumAllActions) *
                                                  96),
                                              bloc.recordLi[3].$1,
                                              rankKey: 'remaining',
                                            ),
                                          ],
                                          rankKey: 'progress',
                                        ),
                                      ],
                                      chartType: CircularChartType.Pie,
                                      edgeStyle: SegmentEdgeStyle.round,
                                      percentageValues: true,
                                    ),
                                  ),
                                  //contaner :
                                  Align(
                                    alignment: Alignment.center,
                                    child: Container(
                                      width: 180,
                                      height: 180,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Colorc.lightCyan,
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.center,
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        //title in circular
                                        Text(
                                          'المجموع',
                                          style: TextStyle(
                                            fontFamily: Fontc.marheySmallTitle,
                                            color:
                                                Colorc.green.withOpacity(0.8),
                                            fontSize: Sic.s18,
                                          ),
                                        ),
                                        //spacer
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        //money
                                        Text(
                                          '${bloc.sum().toStringAsFixed(1)} ر.س',
                                          style: TextStyle(
                                            fontFamily: Fontc.marheySmallTitle,
                                            color: Colorc.darkGrey
                                                .withOpacity(0.8),
                                            fontSize: Sic.s28,
                                          ),
                                        ),
                                        //spacer
                                        const SizedBox(
                                          height: 10,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            //spacing :
                            const SizedBox(
                              height: 20,
                            ),

                            //GridView
                            GridView.builder(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 25),
                              physics: const NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 2,
                                crossAxisSpacing: 13,
                                mainAxisSpacing: 15,
                              ),
                              itemCount: 4,
                              itemBuilder: (BuildContext context, int index) {
                                //contant in  GridView
                                return Compc.recordSumAllRigister(
                                  color: bloc.recordLi[index].$1,
                                  title: bloc.recordLi[index].$2,
                                  discription: bloc.recordLi[index].$3,
                                  money: bloc.recordLi[index].$4.toString(),
                                );
                              },
                            ),
                            //spacing :
                            const SizedBox(
                              height: 20,
                            ),
                          ],
                        ),
                      );
          },
        ),
      ),
    );
  }
}
