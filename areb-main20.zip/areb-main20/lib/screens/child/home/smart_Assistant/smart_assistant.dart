import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';
import 'package:areb/constants/fonts.dart';
import 'package:areb/constants/images.dart';
import 'package:areb/constants/sizes.dart';
import 'package:areb/functions/navigations.dart';
import 'package:areb/functions/size_screen.dart';
import 'package:areb/screens/child/home/smart_Assistant/cubit/smart_assesstant_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class SmartAssistant extends StatefulWidget {
  const SmartAssistant({super.key});

  @override
  State<SmartAssistant> createState() => _SmartAssistantState();
}

class _SmartAssistantState extends State<SmartAssistant> {
  late SmartAssesstantCubit bloc;
  @override
  void initState() {
    super.initState();
    bloc = SmartAssesstantCubit.get(context);
    bloc.getQuistionFromAssestant();
    bloc.quistionAndAnswersPrimary.clear();
    bloc.quistionAndAnswers.clear();
    bloc.quistionHistory.clear();
    bloc.isFinishChat = false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: Align(
        alignment: AlignmentDirectional.bottomStart,
        child: Padding(
          padding: const EdgeInsetsDirectional.only(start: 40),
          child: FloatingActionButton(
            backgroundColor: Colorc.purple,
            child: const Icon(
              Icons.refresh_rounded,
              color: Colorc.white,
              size: 33,
            ),
            onPressed: () {
              bloc.resetChatBot();
            },
          ),
        ),
      ),
      extendBody: true,
      backgroundColor: Colorc.white,
      body: SafeArea(
        child: BlocConsumer<SmartAssesstantCubit, SmartAssesstantState>(
          listener: (context, state) {},
          builder: (context, state) {
            return state is GetQuistionFromAssestantLoading
                ? Compc.loading(color: Colorc.purple)
                : state is GetQuistionFromAssestantError
                    ? Compc.noInternet(() {
                        bloc.getQuistionFromAssestant();
                      })
                    : Padding(
                        padding: const EdgeInsetsDirectional.symmetric(
                          horizontal: 15,
                          vertical: 10,
                        ),
                        child: RefreshIndicator(
                          onRefresh: () async {
                            bloc.getQuistionFromAssestant();
                          },
                          child: SizedBox(
                            height: sizeScreen.height,
                            child: SingleChildScrollView(
                              controller: bloc.scrollController,
                              physics: const BouncingScrollPhysics(
                                parent: AlwaysScrollableScrollPhysics(),
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  //
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      //image
                                      Image.asset(
                                        Imagec.assistant,
                                        width: 100,
                                      ),
                                      // text
                                      Text(
                                        'مساعدك \nالذكي',
                                        style: TextStyle(
                                          fontFamily: Fontc.marheySmallTitle,
                                          color:
                                              Colorc.darkGrey.withOpacity(0.8),
                                          fontSize: Sic.s33 - 2,
                                        ),
                                        maxLines: 2,
                                      ),
                                      //spacer :
                                      const Spacer(),
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(top: 6.0),
                                        child: IconButton(
                                          onPressed: () {
                                            Navc.pop(context: context);
                                          },
                                          icon: Icon(
                                            Icons.arrow_forward_ios_rounded,
                                            color: Colorc.darkGrey,
                                            size: Sic.s30,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),

                                  //history List
                                  ListView.builder(
                                    itemCount: bloc.quistionHistory.length,
                                    shrinkWrap: true,
                                    physics:
                                        const NeverScrollableScrollPhysics(),
                                    padding: const EdgeInsets.only(top: 20),
                                    itemBuilder: (context, index) {
                                      // int x = (index / 2).round();
                                      return bloc.quistionHistory[index].$2 ==
                                              '***'
                                          ? Column(
                                              children: [
                                                const SizedBox(
                                                  height: 30,
                                                ),
                                                Padding(
                                                  padding: const EdgeInsets
                                                      .symmetric(
                                                    horizontal: 50,
                                                  ),
                                                  child: Divider(
                                                    color: Colorc.purple
                                                        .withOpacity(0.4),
                                                  ),
                                                ),
                                                const SizedBox(
                                                  height: 30,
                                                ),
                                              ],
                                            )
                                          : Compc.cardChat(
                                              smartAssistant: bloc
                                                  .quistionHistory[index].$1,
                                              text: bloc
                                                  .quistionHistory[index].$2,
                                            );
                                    },
                                  ),

                                  //assestant list
                                  bloc.quistionAndAnswersPrimary.isEmpty
                                      ? SizedBox(
                                          height: sizeScreen.height - 150,
                                          child: Center(
                                            child: Compc.empty(),
                                          ),
                                        )
                                      : state is AssestantThinkink
                                          ? Compc.assetantLoading(
                                              smartAssistant: true,
                                            )
                                          : ListView.builder(
                                              itemCount: bloc
                                                  .quistionAndAnswers.length,
                                              shrinkWrap: true,
                                              physics:
                                                  const NeverScrollableScrollPhysics(),
                                              itemBuilder: (context, index) {
                                                // int x = (index / 2).round();
                                                return Compc.cardChat(
                                                  onTap: () {
                                                    bloc.selectQuistionOrResult(
                                                        index);
                                                  },
                                                  smartAssistant: true,
                                                  text: bloc.quistionAndAnswers[
                                                      index]["question"],
                                                );
                                              },
                                            ),

                                  const SizedBox(
                                    height: 200,
                                  )
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
          },
        ),
      ),
    );
  }
}
