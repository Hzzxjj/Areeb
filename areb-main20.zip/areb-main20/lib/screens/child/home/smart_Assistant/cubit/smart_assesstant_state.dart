part of 'smart_assesstant_cubit.dart';

@immutable
sealed class SmartAssesstantState {}

final class SmartAssesstantInitial extends SmartAssesstantState {}

final class AssestantThinkink extends SmartAssesstantState {}

final class GetQuistionFromAssestantLoading extends SmartAssesstantState {}

final class GetQuistionFromAssestantSuccess extends SmartAssesstantState {}

final class GetQuistionFromAssestantError extends SmartAssesstantState {
  final String error;
  GetQuistionFromAssestantError(this.error);
}
