import 'package:areb/shared/dio/dio.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/material.dart';

part 'smart_assesstant_state.dart';

class SmartAssesstantCubit extends Cubit<SmartAssesstantState> {
  static SmartAssesstantCubit get(context) => BlocProvider.of(context);
  List quistionAndAnswers = [];
  List quistionAndAnswersPrimary = [];
  List<(bool, String)> quistionHistory = [];
  bool isFinishChat = false;
  ScrollController scrollController = ScrollController();
  SmartAssesstantCubit() : super(SmartAssesstantInitial());

  void getQuistionFromAssestant() {
    emit(GetQuistionFromAssestantLoading());
    Dioc.getQuistionFromAssestant().then((value) {
      if (value.data['message'] == 'successful') {
        quistionAndAnswers = value.data['questions'];
        quistionAndAnswersPrimary = value.data['questions'];

        emit(GetQuistionFromAssestantSuccess());
      } else {
        emit(GetQuistionFromAssestantError('error'));
      }
    }).catchError((e) {
      emit(GetQuistionFromAssestantError(e.toString()));
    });
  }

  void selectQuistionOrResult(index) async {
    quistionHistory
        .add((false, quistionAndAnswers[index]["question"].toString()));
    emit(AssestantThinkink());

    await Future.delayed(const Duration(seconds: 1));

    if (quistionAndAnswers[index]['questions'].isEmpty) {
      quistionHistory
          .add((true, quistionAndAnswers[index]["answer"].toString()));
      quistionHistory.add((true, '***'));
      quistionAndAnswers = quistionAndAnswersPrimary;

      isFinishChat = true;
    } else {
      quistionAndAnswers = quistionAndAnswers[index]['questions'];
    }

    emit(GetQuistionFromAssestantSuccess());
    await Future.delayed(const Duration(milliseconds: 250));
    scrollController.animateTo(
      scrollController.position.maxScrollExtent + 15,
      duration: const Duration(milliseconds: 500),
      curve: Curves.fastOutSlowIn,
    );
    // scrollController.animateTo(
    //   isFinishChat == true && quistionHistory.length > 10
    //       ? scrollController.position.maxScrollExtent + 125
    //       : scrollController.position.maxScrollExtent,
    //   duration: const Duration(milliseconds: 500),
    //   curve: Curves.fastOutSlowIn,
    // );
    isFinishChat = false;
  }

  void resetChatBot() {
    quistionHistory = [];
    quistionAndAnswers = [];

    quistionAndAnswers = quistionAndAnswersPrimary;
    isFinishChat = false;
    emit(GetQuistionFromAssestantSuccess());
  }
}
