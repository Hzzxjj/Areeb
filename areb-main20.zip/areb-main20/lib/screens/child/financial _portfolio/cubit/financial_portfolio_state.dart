part of 'financial_portfolio_cubit.dart';

@immutable
sealed class FinancialPortfolioState {}

final class FinancialPortfolioInitial extends FinancialPortfolioState {}

final class RequiestALoanSuccess extends FinancialPortfolioState {
  final String message;
  RequiestALoanSuccess(this.message);
}

final class RequiestALoanLoading extends FinancialPortfolioState {}

final class RequiestALoanError extends FinancialPortfolioState {
  final String error;

  RequiestALoanError(this.error);
}
