import 'package:areb/functions/message.dart';
import 'package:areb/functions/run_dialog.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/screens/child/dialogs/take_photo_currency/take_photo.dart';
import 'package:areb/screens/child/personal_account_child/cubit/child_account_cubit.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/material.dart';

part 'financial_portfolio_state.dart';

class FinancialPortfolioCubit extends Cubit<FinancialPortfolioState> {
  final TextEditingController loanCauseController = TextEditingController();

  final TextEditingController ammountController = TextEditingController();
  FinancialPortfolioCubit() : super(FinancialPortfolioInitial());

  void onTapRequistAloan(context) {
    if (loanCauseController.text.isEmpty || ammountController.text.isEmpty) {
      Messagec.showSnackBar(
          context: context,
          snackbar: Snackc.errorSnackBar('يجب ملئ الحقول أعلاه ...'));
    } else {
      emit(RequiestALoanLoading());

      Dioc.requiestALoan(
        cause: loanCauseController.text,
        ammount: ammountController.text,
      ).then(
        (value) {
          if (value.data['message'] == 'successful') {
            loanCauseController.clear();
            ammountController.clear();
            ChildAccountCubit.get(context).getUserData(context);
            emit(RequiestALoanSuccess(value.data['body']));
          } else {
            emit(RequiestALoanError(value.data['body']));
          }
        },
      ).catchError((e) {
        emit(RequiestALoanError(e.toString()));
      });
    }
  }

  void onTapTakePhoto(context) {
    RunDialogc.animationDialog(
      child: const TakePhotoDialog(),
      context: context,
      barrierDismissible: true,
    );
  }
}
