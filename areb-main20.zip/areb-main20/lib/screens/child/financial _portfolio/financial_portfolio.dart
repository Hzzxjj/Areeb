import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';
import 'package:areb/constants/fonts.dart';
import 'package:areb/constants/images.dart';
import 'package:areb/constants/radius.dart';
import 'package:areb/constants/shadow.dart';
import 'package:areb/constants/sizes.dart';
import 'package:areb/functions/message.dart';
import 'package:areb/functions/size_screen.dart';
import 'package:areb/functions/snackbar.dart';
import 'package:areb/screens/child/financial%20_portfolio/cubit/financial_portfolio_cubit.dart';
import 'package:areb/screens/child/personal_account_child/cubit/child_account_cubit.dart';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class FinancialPortfolio extends StatefulWidget {
  const FinancialPortfolio({super.key});

  @override
  State<FinancialPortfolio> createState() => _FinancialPortfolioState();
}

class _FinancialPortfolioState extends State<FinancialPortfolio> {
  late ChildAccountCubit childAccoutBloc;
  late FinancialPortfolioCubit bloc;
  @override
  void initState() {
    super.initState();
    childAccoutBloc = BlocProvider.of(context);
    bloc = BlocProvider.of(context);
    if (childAccoutBloc.getDataonce == false) {
      childAccoutBloc.getUserData(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: BlocListener<FinancialPortfolioCubit, FinancialPortfolioState>(
        listener: (context, state) {
          state is RequiestALoanError
              ? Messagec.showSnackBar(
                  context: context, snackbar: Snackc.errorSnackBar(state.error))
              : null;
          state is RequiestALoanSuccess
              ? Messagec.showSnackBar(
                  context: context,
                  snackbar: Snackc.talkSnackBar(state.message))
              : null;
        },
        child: BlocConsumer<ChildAccountCubit, ChildAccountState>(
          listener: (context, state) {},
          builder: (context, state) {
            return SafeArea(
              child: state is GetUserAccountDetailsChildLoading
                  ? SizedBox(
                      child: Compc.loading(),
                    )
                  : state is GetUserAccountDetailsChildError
                      ? Compc.noInternet(() {
                          childAccoutBloc.getUserData(context);
                        })
                      : RefreshIndicator(
                          onRefresh: () async {
                            childAccoutBloc.getUserData(context);
                          },
                          child: SizedBox(
                            height: sizeScreen.height,
                            child: SingleChildScrollView(
                              physics: const BouncingScrollPhysics(
                                  parent: AlwaysScrollableScrollPhysics()),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.start,
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  //app bar
                                  Compc.appbar(
                                    context,
                                    title: 'المحفظة المالية',
                                    fontsize: Sic.s40,
                                    withBackArrow: false,
                                    withDivider: true,
                                  ),

                                  Align(
                                    alignment: AlignmentDirectional.topCenter,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        //Spacer :
                                        const SizedBox(
                                          height: 30,
                                        ),
                                        //balance
                                        Text(
                                          'رصيدك الحالي:',
                                          style: TextStyle(
                                            fontSize: Sic.s20,
                                            fontFamily: Fontc.hayahBigTitle,
                                            fontWeight: FontWeight.bold,
                                            color: Colorc.lightGreen2,
                                          ),
                                        ), //Spacer :
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        Text(
                                          '${childAccoutBloc.user.money} ر.س',
                                          style: TextStyle(
                                            fontSize: Sic.s40,
                                            fontFamily: Fontc.hayahBigTitle,
                                            // fontWeight: FontWeight.bold,
                                            color: Colorc.black,
                                          ),
                                        ),
                                        //Spacer :
                                        const SizedBox(
                                          height: 20,
                                        ),
                                        Compc.buttonWithIconinAccount(
                                          icon: Icons.camera_alt_outlined,
                                          text: 'التقط صورة لاضافة مالك',
                                          point: false,
                                          height: 70,
                                          onTap: () {
                                            bloc.onTapTakePhoto(context);
                                          },
                                          width: 300.0,
                                          coloricon: Colorc.black,
                                          fontSize: Sic.s24,
                                          fontFamily: Fontc.hayahBigTitle,
                                          // fontWeight: FontWeight.bold,
                                          sizeicon: 40.0,
                                        ),
                                        const SizedBox(
                                          height: 40,
                                        ),
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                            vertical: 8,
                                          ),
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(
                                              Radc.r20,
                                            ),
                                            color: Colorc.lightGreen,
                                            boxShadow: [
                                              Shadc.button,
                                            ],
                                          ),
                                          height: 310,
                                          width: 320,
                                          child: Column(
                                            children: [
                                              //child image :
                                              Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Image.asset(
                                                    Imagec.childThink,
                                                    height: 70,
                                                  ),
                                                  const SizedBox(
                                                    width: 20,
                                                  ),
                                                  Text(
                                                    'طلب مساعدة مالية من الوالدين',
                                                    style: TextStyle(
                                                      fontSize: Sic.s20,
                                                      fontFamily:
                                                          Fontc.hayahBigTitle,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      color: Colorc.black,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              //spacing :
                                              const SizedBox(
                                                height: 8,
                                              ),
                                              Compc.formFieldAddMoneyChildren(
                                                  vertical: 0,
                                                  horizontalPadding: 20,
                                                  controller:
                                                      bloc.loanCauseController,
                                                  validator: null,
                                                  keyboardType:
                                                      TextInputType.name,
                                                  textInputAction:
                                                      TextInputAction.next,
                                                  hintText: 'سبب المساعدة المالية'),
                                              const SizedBox(
                                                height: 25,
                                              ),
                                              Compc.formFieldAddMoneyChildren(
                                                  vertical: 0,
                                                  controller:
                                                      bloc.ammountController,
                                                  horizontalPadding: 20,
                                                  validator: null,
                                                  keyboardType:
                                                      TextInputType.number,
                                                  textInputAction:
                                                      TextInputAction.next,
                                                  hintText: 'كمية المال'),
                                              const SizedBox(
                                                height: 25,
                                              ),
                                              BlocBuilder<
                                                  FinancialPortfolioCubit,
                                                  FinancialPortfolioState>(
                                                builder: (context, statee) {
                                                  return statee
                                                          is RequiestALoanLoading
                                                      ? Compc.loading(
                                                          color: Colorc.purple)
                                                      : Compc
                                                          .buttonWithIconinAccount(
                                                          icon: Icons.abc,
                                                          point: false,
                                                          icons: false,
                                                          fontFamily: Fontc
                                                              .hayahBigTitle,
                                                          width: 170,
                                                          height: 45,
                                                          fontSize: Sic.s24 + 2,
                                                          onTap: () {
                                                            bloc.onTapRequistAloan(
                                                                context);
                                                          },
                                                          text: 'طلب المساعدة',
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                        );
                                                },
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
            );
          },
        ),
      ),
    );
  }
}
