import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';
import 'package:areb/constants/radius.dart';
import 'package:areb/constants/shadow.dart';
import 'package:areb/screens/child/bottom_nav_bar/cubit/bottom_nav_bar_child_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class BottomNavBarChild extends StatefulWidget {
  const BottomNavBarChild({super.key});

  @override
  State<BottomNavBarChild> createState() => _BottomNavBarChildState();
}

class _BottomNavBarChildState extends State<BottomNavBarChild> {
  late BottomNavBarChildCubit bloc;
  @override
  void initState() {
    super.initState();
    bloc = BottomNavBarChildCubit.get(context);
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<BottomNavBarChildCubit, BottomNavBarChildState>(
      builder: (context, state) {
        return Container(
          margin: const EdgeInsetsDirectional.fromSTEB(25, 5, 25, 16),
          height: 60,
          decoration: BoxDecoration(
            color: Colorc.cyan,
            borderRadius: BorderRadius.circular(Radc.r24),
            boxShadow: [
              Shadc.button,
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              //account:
              Compc.bottomNavBarIcon(
                icon: Icons.account_circle_rounded,
                onTap: () {
                  bloc.onTapBottomNavBarIcon(0);
                  // Add your onTap logic here
                },
                isSelected: bloc.bottomNavIndex == 0,
              ),
              //money:
              Compc.bottomNavBarIcon(
                icon: Icons.monetization_on,
                onTap: () {
                  bloc.onTapBottomNavBarIcon(1);
                  // Add your onTap logic here
                },
                isSelected: bloc.bottomNavIndex == 1,
              ),
              //task:
              Compc.bottomNavBarIcon(
                icon: Icons.list,
                onTap: () {
                  bloc.onTapBottomNavBarIcon(2);
                  // Add your onTap logic here
                },
                isSelected: bloc.bottomNavIndex == 2,
              ),

              //home:
              Compc.bottomNavBarIcon(
                icon: Icons.home,
                onTap: () {
                  bloc.onTapBottomNavBarIcon(3);
                  // Add your onTap logic here
                },
                isSelected: bloc.bottomNavIndex == 3,
              )
            ],
          ),
        );
      },
    );
  }
}
