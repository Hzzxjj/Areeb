part of 'bottom_nav_bar_child_cubit.dart';

@immutable
final class BottomNavBarChildInitial extends BottomNavBarChildState {}

sealed class BottomNavBarChildState {}

final class ChangeScreen extends BottomNavBarChildState {}

final class NoInternet extends BottomNavBarChildState {}

final class Internet extends BottomNavBarChildState {}
