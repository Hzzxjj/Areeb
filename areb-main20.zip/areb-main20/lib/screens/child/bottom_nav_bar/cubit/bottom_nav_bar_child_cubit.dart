import 'package:areb/screens/child/financial%20_portfolio/financial_portfolio.dart';
import 'package:areb/screens/child/home/home/home.dart';
import 'package:areb/screens/child/personal_account_child/personal_account_child.dart';
import 'package:areb/screens/child/tasks_child/tasks_child.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
part 'bottom_nav_bar_child_state.dart';

class BottomNavBarChildCubit extends Cubit<BottomNavBarChildState> {
  static BottomNavBarChildCubit get(context) => BlocProvider.of(context);
  final PageController? pageController = PageController(initialPage: 3);
  BottomNavBarChildCubit() : super(BottomNavBarChildInitial());
  List<Widget> pages = [
    const PersonalAccountChild(),
    const FinancialPortfolio(),
    const TasksChild(),
    const HomeChild(),
  ];
  int bottomNavIndex = 3;

  void onPageChange(int v) {
    bottomNavIndex = v;
    emit(
      ChangeScreen(),
    );
  }

  void onTapBottomNavBarIcon(int index) {
    pageController!.animateToPage(
      index,
      duration: const Duration(milliseconds: 800),
      curve: Curves.fastOutSlowIn,
    );
  }
}
