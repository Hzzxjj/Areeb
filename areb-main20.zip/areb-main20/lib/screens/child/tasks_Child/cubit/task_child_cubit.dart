import 'package:areb/functions/messaging.dart';
import 'package:areb/functions/run_dialog.dart';
import 'package:areb/shared/dio/dio.dart';
import 'package:areb/shared/models/task/task.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/material.dart';

part 'task_child_state.dart';

class TaskChildCubit extends Cubit<TaskChildState> {
  TaskChildCubit() : super(TaskChildInitial());
  static TaskChildCubit get(context) => BlocProvider.of(context);
  bool getDataOnce = false;
  List<TaskModel> tasks = [];
  void getTasks() {
    emit(GetTasksLoading());
    Dioc.getTasks().then((value) {
      if (value.data['message'] == 'successful') {
        getDataOnce = true;
        tasks = List<TaskModel>.from(
            value.data['tasks'].map((e) => TaskModel.fromMap(e)));
        emit(GetTasksSuccess());
      } else {
        emit(GetTasksError('error'));
      }
    }).catchError((e) {
      emit(GetTasksError(e.toString()));
    });
  }

  void onTapNoti(context, String note) {
    RunDialogc.animationDialog(
        child: Dialogc.doneTask(context, note), context: context);
  }
}
