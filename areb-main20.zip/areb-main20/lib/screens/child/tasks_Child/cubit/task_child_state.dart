part of 'task_child_cubit.dart';

@immutable
sealed class TaskChildState {}

final class TaskChildInitial extends TaskChildState {}

final class GetTasksLoading extends TaskChildState {}

final class GetTasksSuccess extends TaskChildState {}

final class GetTasksError extends TaskChildState {
  final String error;
  GetTasksError(this.error);
}
