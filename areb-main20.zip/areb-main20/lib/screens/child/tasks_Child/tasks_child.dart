import 'package:areb/components/comp.dart';
import 'package:areb/constants/sizes.dart';
import 'package:areb/functions/size_screen.dart';
import 'package:areb/screens/child/tasks_child/cubit/task_child_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class TasksChild extends StatefulWidget {
  const TasksChild({super.key});

  @override
  State<TasksChild> createState() => _TasksChildState();
}

class _TasksChildState extends State<TasksChild> {
  late TaskChildCubit bloc;
  @override
  void initState() {
    super.initState();
    bloc = BlocProvider.of(context);
    if (bloc.getDataOnce == false) {
      bloc.getTasks();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: SafeArea(
        child: BlocConsumer<TaskChildCubit, TaskChildState>(
          listener: (context, state) {},
          builder: (context, state) {
            return state is GetTasksLoading
                ? SizedBox(
                    child: Compc.loading(),
                  )
                : state is GetTasksError
                    ? Compc.noInternet(() {
                        bloc.getTasks();
                      })
                    : RefreshIndicator(
                        onRefresh: () async {
                          bloc.getTasks();
                        },
                        child: SizedBox(
                          height: sizeScreen.height,
                          child: SingleChildScrollView(
                            physics: const BouncingScrollPhysics(
                              parent: AlwaysScrollableScrollPhysics(),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.start,
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                //app bar
                                Compc.appbar(
                                  context,
                                  title: 'المهام',
                                  fontsize: Sic.s40,
                                  withBackArrow: false,
                                  withDivider: true,
                                ),

                                bloc.tasks.isEmpty
                                    ? SizedBox(
                                        height: sizeScreen.height - 180,
                                        child: Compc.dontHave(
                                            'لا يوجد أي مهام لك !'),
                                      )
                                    : ListView.builder(
                                        itemCount: bloc.tasks.length,
                                        physics:
                                            const NeverScrollableScrollPhysics(),
                                        scrollDirection: Axis.vertical,
                                        shrinkWrap: true,
                                        itemBuilder: (context, index) {
                                          return Compc.tasksCardChild(
                                              tasksTitle:
                                                  bloc.tasks[index].task,
                                              money: bloc.tasks[index].reward
                                                  .toString(),
                                              note: bloc.tasks[index].note,
                                              onTapNoti: () {
                                                bloc.onTapNoti(context,
                                                    bloc.tasks[index].note);
                                              });
                                        },
                                      ),
                              ],
                            ),
                          ),
                        ),
                      );
          },
        ),
      ),
    );
  }
}
