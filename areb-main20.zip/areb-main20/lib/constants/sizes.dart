abstract class Sic {
  static double s10 = 10;
  static double s12 = 12;
  static double s15 = 15;
  static double s18 = 18;
  static double s20 = 20;
  static double s22 = 22;
  static double s24 = 24;
  static double s28 = 28;
  static double s30 = 30;
  static double s33 = 33;
  static double s36 = 36;
  static double s40 = 40;
  static double s50 = 50;
  static double s60 = 60;
}
