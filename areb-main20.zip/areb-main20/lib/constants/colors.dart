import 'package:flutter/material.dart';

abstract class Colorc {
  static const Color white = Colors.white;
  static const Color black = Colors.black;
  static Color deepCyan = Colors.cyan[900]!;
  static Color red = const Color.fromARGB(255, 226, 62, 50);
  static Color cyan = const Color(0xff4ad8ee);
  static Color lightCyan = const Color(0xffeef9fd);
  static Color purple = const Color(0xff9597ea);
  static Color mediumPurple = const Color.fromARGB(255, 166, 227, 255);
  static Color green = const Color(0xff4cab97);
  static Color darkGrey = const Color(0xff728083);
  static Color grey = const Color(0xffbebebe);
  static Color blue = const Color.fromARGB(255, 92, 168, 255);

  static Color lightGreen = const Color(0xffb8d3ce);
  static Color lightGreen2 = const Color(0xff84a9a1);
  static Color lightGreen3 = const Color.fromARGB(255, 88, 182, 90);

  static Color pink = const Color(0xfff0aaac);
  static Color lightPurple = const Color(0xffdac6f7);
  static Color yellow = const Color(0xfff6e69b);
  static Color mediumGreen = const Color(0xffa2eec8);
  static Color mediumpurple = const Color(0xff999BFD);
  static Color lightRed = const Color(0xffff9899);
//999BFD 84a9a1 ff9899

  static Color trans = Colors.transparent;
}
