abstract class Radc {
  static double r02 = 2;

  static double r05 = 5;
  static double r10 = 10;
  static double r15 = 15;
  static double r18 = 18;
  static double r20 = 20;
  static double r24 = 24;
  static double r28 = 28;
  static double r30 = 30;
  static double r33 = 33;
  static double r36 = 36;
  static double r40 = 40;
  static double r50 = 50;
}
