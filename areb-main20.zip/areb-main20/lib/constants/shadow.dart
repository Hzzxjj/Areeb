import 'package:areb/constants/colors.dart';
import 'package:flutter/material.dart';

abstract class Shadc {
  static BoxShadow button = BoxShadow(
    color: Colorc.darkGrey.withOpacity(0.5),
    offset: const Offset(0, 3),
    blurRadius: 1,
  );
}
