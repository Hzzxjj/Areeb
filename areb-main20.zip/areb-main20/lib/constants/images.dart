abstract class Imagec {
  static const String logoWithBack = 'assets/images/Logo.png';
  static const String child = 'assets/images/stand.png';
  static const String logoWithoutText = 'assets/images/noLogo.png';
  static const String childCry = 'assets/images/cry.png';
  static const String childThink = 'assets/images/think.png';
  static const String assistant = 'assets/images/assistant.png';
  static const String currencyExample = 'assets/images/cr.jpg';
  static const String group = 'assets/images/group.png';
}
