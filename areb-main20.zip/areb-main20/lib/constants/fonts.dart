abstract class Fontc {
  // static const String robotoBigTitle = 'Roboto';
  // static const String sairaSmallTitle = 'Saira';
  static const String hayahBigTitle = 'Hayah';
  // static const String aGASmallTitle = 'AGA';
  static const String marheySmallTitle = 'Marhey';
}
