import 'package:areb/constants/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';

class RunDialogc {
  static void animationDialog(
      {required Widget child,
      required context,
      bool barrierDismissible = true}) {
    showGeneralDialog(
      transitionDuration: const Duration(milliseconds: 200),
      barrierDismissible: barrierDismissible,
      barrierLabel: '',
      context: context,
      pageBuilder: (context, animation, secondaryAnimation) => AnimationLimiter(
        child: AnimationConfiguration.synchronized(
          duration: const Duration(milliseconds: 200),
          child: ScaleAnimation(
            scale: animation.value,
            child: Dialog(
              backgroundColor: Colorc.trans,
              surfaceTintColor: Colorc.trans,
              // insetAnimationDuration: Duration(milliseconds: 800),
              // insetAnimationCurve: Curves.fastOutSlowIn,
              child: child,
            ),
          ),
        ),
      ),
    );
  }
}
