import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';
import 'package:areb/constants/fonts.dart';
import 'package:areb/constants/images.dart';
import 'package:areb/constants/radius.dart';
import 'package:areb/constants/sizes.dart';
import 'package:areb/functions/navigations.dart';
import 'package:areb/functions/run_dialog.dart';
import 'package:flutter/material.dart';

abstract class Dialogc {
  //say فخور بك :
  static Widget fackorBik(context) {
    return Dialog(
      child: Container(
        width: 200,
        height: 450,
        decoration: BoxDecoration(
          color: Colorc.lightCyan,
          borderRadius: BorderRadius.circular(
            Radc.r18,
          ),
        ),
        child: UnconstrainedBox(
          child: Column(
            children: [
              //spacing :
              const SizedBox(
                height: 30,
              ),
              //image with border:
              CircleAvatar(
                backgroundColor: Colorc.grey.withOpacity(0.24),
                radius: 68,
                child: const Image(
                  width: 125,
                  fit: BoxFit.cover,
                  image: AssetImage(
                    Imagec.logoWithoutText,
                  ),
                ),
              ),

              //spacing :
              const SizedBox(
                height: 15,
              ),
              //title:
              Center(
                child: Text(
                  ' فخور بك!',
                  style: TextStyle(
                    color: Colorc.purple,
                    fontSize: Sic.s40,
                    // fontFamily: Fontc.hayahBigTitle,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              //spacing :
              const SizedBox(
                height: 20,
              ),
              //disc:
              Center(
                child: Text(
                  'تذكر أن كل جهد تبذله ينتج عنه\n نتائج إيجابيّة',
                  style: TextStyle(
                    color: Colorc.darkGrey,
                    fontSize: Sic.s28,
                    fontFamily: Fontc.hayahBigTitle,
                    fontWeight: FontWeight.w500,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              //spacing :
              const SizedBox(
                height: 30,
              ),
              //done button:
              Compc.doneButton(context: context),
            ],
          ),
        ),
      ),
    );
  }

//say goodjob:
  static Widget goodJob(context) {
    return Dialog(
      child: Container(
        width: 200,
        height: 450,
        decoration: BoxDecoration(
          color: Colorc.lightCyan,
          borderRadius: BorderRadius.circular(
            Radc.r18,
          ),
        ),
        child: UnconstrainedBox(
          child: Column(
            children: [
              //spacing :
              const SizedBox(
                height: 40,
              ),
              //image with border:
              CircleAvatar(
                backgroundColor: Colorc.grey.withOpacity(0.24),
                radius: 68,
                child: const Image(
                  width: 125,
                  fit: BoxFit.cover,
                  image: AssetImage(
                    Imagec.logoWithoutText,
                  ),
                ),
              ),

              //spacing :
              const SizedBox(
                height: 15,
              ),
              //title:
              Center(
                child: Text(
                  ' أحسنت!',
                  style: TextStyle(
                    color: Colorc.purple,
                    fontSize: Sic.s40,
                    // fontFamily: Fontc.hayahBigTitle,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              //spacing :
              const SizedBox(
                height: 20,
              ),
              //disc:
              Center(
                child: Text(
                  ' بارك الله فيك',
                  style: TextStyle(
                    color: Colorc.darkGrey,
                    fontSize: Sic.s28,
                    fontFamily: Fontc.hayahBigTitle,
                    fontWeight: FontWeight.w500,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              //spacing :
              const SizedBox(
                height: 50,
              ),
              //done button:
              Compc.doneButton(context: context),
            ],
          ),
        ),
      ),
    );
  }

//error repeat again:
//say goodjob:
  static Widget errorRepeat(context) {
    return Dialog(
      child: Container(
        width: 200,
        height: 450,
        decoration: BoxDecoration(
          color: Colorc.lightCyan,
          borderRadius: BorderRadius.circular(
            Radc.r18,
          ),
        ),
        child: UnconstrainedBox(
          child: Column(
            children: [
              //spacing :
              const SizedBox(
                height: 10,
              ),

              //title:
              Center(
                child: Text(
                  'حصل خطأ\n أعد المحاولة!',
                  style: TextStyle(
                    color: Colorc.red,
                    fontSize: Sic.s40,
                    // fontFamily: Fontc.hayahBigTitle,
                    fontWeight: FontWeight.w500,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              //spacing :
              const SizedBox(
                height: 15,
              ),
              //image child crying:
              const Image(
                width: 97,
                fit: BoxFit.cover,
                image: AssetImage(
                  Imagec.childCry,
                ),
              ),
              //spacing :
              const SizedBox(
                height: 30,
              ),
              //done button:
              Compc.doneButton(context: context),
            ],
          ),
        ),
      ),
    );
  }

//Add money :
  static addMoney(context) {
    return Container(
      width: double.infinity,
      height: 500,
      decoration: BoxDecoration(
        color: Colorc.white,
        borderRadius: BorderRadius.circular(
          Radc.r18,
        ),
      ),
      child: UnconstrainedBox(
        child: Column(
          children: [
            Container(
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(100),
                  color: Colorc.lightCyan),
              height: 120,
              width: 120,
              child: Icon(
                Icons.thumb_up_rounded,
                size: 50,
                color: Colorc.purple,
              ),
            ),
            //spacing :
            const SizedBox(
              height: 20,
            ),

            //title:
            Center(
              child: Text(
                'تم تقديم\n المال بنجاح',
                style: TextStyle(
                  color: Colorc.black,
                  fontSize: Sic.s28 + 2,
                  // fontFamily: Fontc.hayahBigTitle,
                  fontWeight: FontWeight.w500,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            Center(
              child: Text(
                ' انت تساعد ابنك على الاستقلال المالي \nوتطوير قدراته الادارية بنجاح',
                style: TextStyle(
                  color: Colorc.darkGrey,
                  fontSize: Sic.s24 + 1,
                  fontFamily: Fontc.hayahBigTitle,
                  // fontWeight: FontWeight.w500,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            //spacing :
            const SizedBox(
              height: 35,
            ),
            //image child crying:

            //done button:
            Compc.doneButton(
              context: context,
              textColor: Colorc.black,
              backColor: Colorc.cyan,
            ),
          ],
        ),
      ),
    );
  }

//done :
  static doneTask(context, String note) {
    return Container(
      width: double.infinity,
      height: 500,
      padding: const EdgeInsets.symmetric(
        horizontal: 15,
      ),
      decoration: BoxDecoration(
        color: Colorc.white,
        borderRadius: BorderRadius.circular(
          Radc.r18,
        ),
      ),
      child: Center(
        child: SingleChildScrollView(
          child: Column(
            children: [
              //spacing :
              const SizedBox(
                height: 15,
              ),
              Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100),
                    color: Colorc.lightCyan),
                height: 120,
                width: 120,
                child: Icon(
                  Icons.thumb_up_rounded,
                  size: 50,
                  color: Colorc.purple,
                ),
              ),
              //spacing :
              const SizedBox(
                height: 20,
              ),

              //title:
              Center(
                child: Text(
                  'أحسنت تم إنجاز\n المهمة بنجاح',
                  style: TextStyle(
                    color: Colorc.black,
                    fontSize: Sic.s28 + 2,
                    // fontFamily: Fontc.hayahBigTitle,
                    fontWeight: FontWeight.w500,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              Center(
                child: Text(
                  note,
                  style: TextStyle(
                    color: Colorc.darkGrey,
                    fontSize: Sic.s24 + 1,
                    fontFamily: Fontc.hayahBigTitle,
                    // fontWeight: FontWeight.w500,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              //spacing :
              const SizedBox(
                height: 35,
              ),
              //image child crying:

              //done button:
              Compc.buttonWithIconBlacktext(
                onTap: () {
                  Navc.pop(context: context);
                },
                text: 'حسنا',
                icon: Icons.done,
              ),
              const SizedBox(
                height: 15,
              ),
            ],
          ),
        ),
      ),
    );
  }

  static loading(context) {
    RunDialogc.animationDialog(
      barrierDismissible: false,
      child: PopScope(
        canPop: false,
        child: Scaffold(
          backgroundColor: Colorc.trans,
          body: Dialog(
            backgroundColor: Colorc.trans,
            surfaceTintColor: Colorc.trans,
            child: Compc.loading(),
          ),
        ),
      ),
      context: context,
    );
  }
}
