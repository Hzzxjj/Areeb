//firebase message recive:

import 'package:areb/functions/toast.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

void configureFCMListeners(context) {
  FirebaseMessaging.onMessage.listen(
    (RemoteMessage message) {
      // WidgetsBinding.instance.addPostFrameCallback((_) {

      Toastc.notification(
        context: context,
        title: message.notification!.title!,
        body: message.notification!.body!,
        onTap: () {
          Toastc.dismis();
          // Navc.push(
          //   context: context,
          //   screenToPush: NotificationC(
          //     notification: notificationData,
          //   ),
          //   type: PageTransitionType.topToBottom,
          // );
        },
      );
    },
  );
  FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {});
}

Future<void> subscribeWithEmailAndUser(String id, String role) async {
  await firebaseMessaging.subscribeToTopic(id);
  await firebaseMessaging.subscribeToTopic('users');
  await firebaseMessaging.subscribeToTopic(role);
}

Future<void> signOutSubsicibtion(String id, String role) async {
  firebaseMessaging.unsubscribeFromTopic(id);
  firebaseMessaging.unsubscribeFromTopic('users');
  firebaseMessaging.unsubscribeFromTopic(role);
}

FirebaseMessaging firebaseMessaging = FirebaseMessaging.instance;

Future<NotificationSettings> permisionNotifiation() async {
  await firebaseMessaging.getNotificationSettings();
  NotificationSettings settings = await firebaseMessaging.requestPermission(
    alert: true,
    announcement: false,
    badge: true,
    carPlay: false,
    criticalAlert: false,
    provisional: false,
    sound: true,
  );
  if (settings.authorizationStatus == AuthorizationStatus.authorized) {
  } else if (settings.authorizationStatus == AuthorizationStatus.provisional) {
  } else {}

  await firebaseMessaging.setForegroundNotificationPresentationOptions(
    alert: true, // Required to display a heads up notification
    badge: true,
    sound: true,
  );
  return settings;
}

Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // If you're going to use other Firebase services in the background, such as Firestore,
  // make sure you call `initializeApp` before using other Firebase services.
  await Firebase.initializeApp();

  // print("Handling a background message: ${message.messageId}");
}
