import 'package:flutter/material.dart';

class Messagec {
  static showSnackBar({
    required context,
    required SnackBar snackbar,
  }) {
    ScaffoldMessenger.of(context).removeCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(snackbar);
  }
}
