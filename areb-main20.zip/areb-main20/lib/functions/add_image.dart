//custom function :
import 'dart:io';

import 'package:image_picker/image_picker.dart';

abstract class AddImage {
//to select pick from show dialog simple:
  static XFile? image;

  static File? imageSelected;

  //from gallery :
  static Future<void> imagePickerFromGallery(context) async {
    image = await ImagePicker()
        .pickImage(
      source: ImageSource.gallery,
      imageQuality: 40,
      maxHeight: 700,
      maxWidth: 700,
    )
        .then(
      (value) {
        if (value != null) {
          imageSelected = File(value.path);
        }
        return image;
      },
    );
  }

  //from camera :
  static Future<void> imagePickerFromCamera(context) async {
    image = await ImagePicker()
        .pickImage(
      source: ImageSource.camera,
      imageQuality: 50,
      maxHeight: 1300,
      maxWidth: 1300,
    )
        .then(
      (value) {
        if (value != null) {
          imageSelected = File(value.path);
        } else {
          imageSelected = null;
        }
        return value;
      },
    );
  }
}
