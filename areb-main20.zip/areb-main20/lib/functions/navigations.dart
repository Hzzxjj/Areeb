import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';

abstract class Navc {
  //push without repleacment :
  static Future<dynamic> push({
    required context,
    required Widget screenToPush,
    PageTransitionType type = PageTransitionType.bottomToTop,
    Curve curve = Curves.linear,
    Widget? childCurrent,
    Alignment? alignment,
    Duration duration = const Duration(milliseconds: 500),
    Duration reverseDuration = const Duration(milliseconds: 500),
  }) {
    return Navigator.push(
      context,
      PageTransition(
        alignment: alignment,
        child: screenToPush,
        type: type,
        curve: curve,
        ctx: context,
        childCurrent: childCurrent,
        duration: duration,
        reverseDuration: reverseDuration,

        // reverseDuration: const Duration(milliseconds: 400),
      ),
    );
  }

//push without animation:
  static Future<dynamic> pushHero({
    required context,
    required Widget screenToPush,
  }) {
    return Navigator.push(
      context,
      PageRouteBuilder(
        transitionDuration: const Duration(seconds: 2),
        pageBuilder: (___, _, __) => screenToPush,
      ),
    );
  }

//push with replacment :
  static Future<dynamic> pushReplacment({
    required context,
    required Widget screenToPush,
    PageTransitionType type = PageTransitionType.bottomToTop,
    Curve curve = Curves.linear,
    Widget? childCurrent,
    Alignment? alignment,
    Duration duration = const Duration(milliseconds: 800),
  }) async {
    return await Navigator.pushAndRemoveUntil(
      context,
      PageTransition(
        alignment: alignment,
        child: screenToPush,
        type: type,
        curve: curve,
        ctx: context,
        childCurrent: childCurrent,
        duration: duration,
        // reverseDuration: const Duration(milliseconds: 400),
      ),
      // result: false,
      (Route<dynamic> route) => false,
    );
  }

  //pop :
  static void pop({required context}) {
    return Navigator.pop(context);
  }

//to set transition diricional :
  static PageTransitionType setDirectionOfStartAndEndLtR(context, addChildren) {
    dynamic page;
    Directionality.of(context) == TextDirection.ltr
        ? page = PageTransitionType.leftToRightWithFade
        : page = PageTransitionType.rightToLeftWithFade;
    return page;
  }

  //to set transition diricional :
  static PageTransitionType setDirectionOfStartAndEndRtL(context) {
    dynamic page;
    Directionality.of(context) == TextDirection.rtl
        ? page = PageTransitionType.leftToRightWithFade
        : page = PageTransitionType.rightToLeftWithFade;
    return page;
  }
}
