import 'package:areb/components/comp.dart';
import 'package:areb/constants/colors.dart';
import 'package:areb/constants/sizes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_styled_toast/flutter_styled_toast.dart';

abstract class Toastc {
  /*
  static ToastFuture error({
    required String text,
    required context,
    Color? backColor,
    int durationMilli = 4000,
  }) {
    Color backcolor = backColor ?? Colorc.black;
    return showToastWidget(
      Container(
        width: double.infinity,
        height: 125,
        decoration: BoxDecoration(
          color: backcolor.withOpacity(0.9),
          borderRadius: BorderRadius.circular(Radc.r15),
        ),
        margin: const EdgeInsets.symmetric(horizontal: 20),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Compc.tapAnimation(
              child: Compc.text(
                label: text,
                color: Colorc.white,
                // maxLises: 3,
                // size: Sic.s18 - 1,
              ),
            ),
            const SizedBox(
              height: 15,
            ),
            Compc.tapAnimation(
              onTap: () {
                ToastManager().dismissAll(showAnim: true);
                // print('object');
              },
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                decoration: BoxDecoration(
                  color: Colorc.white.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(Radc.r15),
                ),
                child: Compc.text(
                  label: textc.close,
                  color: Colorc.white,
                  // size: Sic.s15,
                ),
              ),
            ),
          ],
        ),
      ),
      context: context,
      // onDismiss: () {},
      isIgnoring: false,

      // alignment: Alignment.center,
      // backgroundColor: Colorc.black.withOpacity(0.7),
      // borderRadius: BorderRadius.circular(Radc.r15),
      position: const StyledToastPosition(
        align: Alignment.center,
      ),
      duration: Duration(milliseconds: durationMilli),
      animation: StyledToastAnimation.sizeFade,
    );
  }
*/

  static ToastFuture notification({
    required context,
    required String title,
    required String body,
    required void Function()? onTap,
  }) {
    return showToastWidget(
      Compc.tapAnimation(
        onTap: onTap,
        child: Dismissible(
          key: const Key('dis'),
          direction: DismissDirection.horizontal,
          onDismissed: (v) {
            dismis();
          },
          child: Container(
            clipBehavior: Clip.antiAlias,
            width: double.infinity,
            height: 90,
            // alignment: Alignment.topCenter,
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 15),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            decoration: BoxDecoration(
              color: Colorc.purple.withOpacity(0.98),
              borderRadius: BorderRadius.circular(
                15,
              ),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                //title:
                Text(
                  title,
                  style: TextStyle(
                    color: Colorc.white,
                    fontSize: Sic.s22,
                  ),
                ),
                //spacing :
                const SizedBox(
                  height: 5,
                ),
                //body
                Text(
                  body,
                  style: TextStyle(
                    color: Colorc.white,
                    fontSize: Sic.s18,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      context: context,
      isIgnoring: false,
      textDirection: TextDirection.rtl,
      position: const StyledToastPosition(
        align: Alignment.topCenter,
      ),
      duration: const Duration(seconds: 15),
      animation: StyledToastAnimation.fadeScale,
      reverseAnimation: StyledToastAnimation.fade,
    );
  }

/*
  static ToastFuture note({
    required context,
    required String text,
  }) {
    return showToastWidget(
      Container(
        clipBehavior: Clip.antiAlias,
        width: double.infinity,
        height: 50,
        // alignment: Alignment.topCenter,
        margin: const EdgeInsets.symmetric(horizontal: 80, vertical: 35),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        decoration: BoxDecoration(
          color: Colorc.mediumpink.withOpacity(0.9),
          borderRadius: BorderRadius.circular(
            Radc.r10,
          ),
        ),
        child: Center(
          child: Compc.text(
            text: text,
            color: Colorc.white,
            size: Sic.s15,
            shadows: [Shadc.smoth(color: Colorc.trans)],
          ),
        ),
      ),
      context: context,
      position: const StyledToastPosition(
        align: Alignment.bottomCenter,
      ),
    );
  }
*/
  static dismis() {
    ToastManager().dismissAll(showAnim: true);
  }
/*
  static ToastFuture dimisError(context) {
    return Toastc.note(
      context: context,
      text: textc.wrong,
    );
  }
  */
}
