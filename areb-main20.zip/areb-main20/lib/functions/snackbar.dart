import 'package:areb/constants/colors.dart';
import 'package:areb/constants/fonts.dart';
import 'package:areb/constants/sizes.dart';
import 'package:flutter/material.dart';

abstract class Snackc {
  //snackbar error
  static SnackBar errorSnackBar(String text) {
    return SnackBar(
      content: Center(
        child: Text(
          text,
          style: TextStyle(
            color: Colorc.white,
            fontSize: Sic.s30,
            fontFamily: Fontc.hayahBigTitle,
          ),
          textAlign: TextAlign.center,
        ),
      ),
      backgroundColor: Colorc.red,
    );
  }

//warning
  static SnackBar warningSnackBar(String text,
      {int millisecendDuration = 1000}) {
    return SnackBar(
      duration: Duration(
        milliseconds: millisecendDuration,
      ),
      content: Center(
        child: Text(
          text,
          style: TextStyle(
            color: Colorc.white,
            fontSize: Sic.s30,
            fontFamily: Fontc.hayahBigTitle,
          ),
          textAlign: TextAlign.center,
        ),
      ),
      backgroundColor: Colorc.purple,
    );
  }

  //talck
  static SnackBar talkSnackBar(String text, {int millisecendDuration = 1000}) {
    return SnackBar(
      duration: Duration(
        milliseconds: millisecendDuration,
      ),
      content: Center(
        child: Text(
          text,
          style: TextStyle(
            color: Colorc.white,
            fontSize: Sic.s30,
            fontFamily: Fontc.hayahBigTitle,
          ),
          textAlign: TextAlign.center,
        ),
      ),
      backgroundColor: Colorc.darkGrey,
    );
  }
}
