package com.example.areb

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
